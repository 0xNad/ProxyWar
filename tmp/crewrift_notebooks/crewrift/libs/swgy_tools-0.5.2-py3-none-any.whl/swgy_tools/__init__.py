"""swgy-tools: CLI tools and scripts for capturing and analysing CrewRift play.

Built on top of ``swgy-base`` (the sprite_v1 parser / world model). This is a
separate distribution on purpose: a policy that only needs ``swgy-base`` should
not pull in the capture/analysis dependencies.

Contents:
    capture    -- record a live sprite_v1 stream to a .spv1 container
                  (console script: ``swgy-capture``)
    navmesh    -- build nav-mesh geometry + bake visibility from the game art
                  (console scripts: ``swgy-navmesh``, ``swgy-navmesh-sight``)
    navviz     -- render a built nav-mesh over the map (console: ``swgy-navmesh-viz``)
    navbench   -- faithful engine-movement port + paired nav benchmark
                  (console: ``swgy-nav-bench``)
    imaging    -- tiny numpy+zlib PNG primitives (no Pillow)
    replayfile -- read a .replay offline: roster, config, duration -- no game build
                  (console script: ``swgy-replay-info``)
    plotstyle  -- the validated dark palette + the Croatoan basemap, shared by the
                  matplotlib renderers
    spatial    -- per-tick positions / kills / bodies / sightings / meetings / tasks,
                  labelled heatmaps, and a kill cam that draws WHO COULD SEE the killer
                  (console: ``swgy-spatial``, ``swgy-spatial-render``, ``swgy-kill-plot``)
    route      -- what movement costs a crew policy: per-leg ticks lost against an
                  engine-faithful perfect follower, task order vs the exactly-optimal
                  tour, and a whole-game ribbon coloured by who could see you
                  (console: ``swgy-route``)
    tasks      -- per-crew task assignment + completion order from CrewRift
                  replays; text/CSV/JSON, plus a matplotlib swimlane + numbered
                  Croatoan reference map
                  (console scripts: ``swgy-task-report``, ``swgy-task-viz``)
    assets/    -- vendored Croatoan basemap PNG (the task-viz reference map)
    scripts/   -- ops helpers (e.g. run-crewrift.sh: launch a local game + bots)

A ``.replay`` holds only inputs and per-tick hashes -- no roles, no tasks, no
positions -- so anything about game *state* comes from re-simulating it with the
game repo's ``expand_replay``. ``spatial`` consumes that tool's JSONL and expects
you to have run it; ``tasks`` will shell out to it for you.
"""

__version__ = "0.5.2"
