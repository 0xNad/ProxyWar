"""Paired navigation ablation on the engine-faithful sim.

Drives the navigation stack (``find_path`` + ``NavState`` follower) through the
byte-faithful engine movement port (:mod:`.enginesim`) over a fixed set of task
tours, measuring **travel ticks** to bring the player's collision point within
``REACH_RADIUS`` of each station (a param-independent metric, so tuning a knob
can't game it). Each candidate nav change is paired against the BASELINE on the
same tours, for both **crew** (walk only) and **imposter** (vents allowed).

A change counts as a real improvement at **alpha = 0.05** only when its 95% CI
of the per-set ticks saved excludes 0 (lower bound > 0).

Console entry ``swgy-nav-bench``:
    swgy-nav-bench --gen              # (re)write the 100x8 task-set fixture
    swgy-nav-bench --workers 16       # run the ablation, print CIs

The fixture (``task_sets_100.json``) is generated once and committed so every
variant -- and reruns -- see identical inputs (true pairing).
"""

from __future__ import annotations

import argparse
import json
import random
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass
from importlib.resources import files
from pathlib import Path

import numpy as np

from swgy_base.nav import NavState, find_path, load_default_mesh
from swgy_base.nav.model import NavEdge, NavMesh
from swgy_base.nav.params import NavParams

from .enginesim import VENT_COOLDOWN, VENT_RANGE, Engine, Player

# --- experiment constants -------------------------------------------------
SEED = 679961
N_SETS = 100
TASKS_PER_SET = 8
N_STATIONS = 41
SPAWN_XY = (137, 342)  # Croatoan home/Bridge center (sim.nim homePosition)
MAX_TICKS_PER_LEG = 1500  # safety cap; a failed leg fails the whole tour
REACH_RADIUS = 12.0  # px; a station is "reached" when the collision point is this close
BASELINE_VENT_COST = 10.0  # planner cost of one vent hop on the reference imposter mesh
FIXTURE = "task_sets_100.json"

# Visiting order is fixed per (set, role) with these params, identical across a
# role's variants -- so the comparison isolates routing/following, not selection.
ORDER_PARAMS = NavParams()
BASELINE = "baseline"


@dataclass(frozen=True)
class Variant:
    name: str
    params: NavParams
    vent_cost: float = BASELINE_VENT_COST  # imposter mesh vent-hop cost
    roles: tuple[str, ...] = ("crew", "imposter")


# Candidate nav changes to test for speed (each paired vs BASELINE).
VARIANTS: list[Variant] = [
    Variant("baseline", NavParams()),
    Variant("diagonal_bias", NavParams(diagonal_bias=1.0)),
    Variant("deadband_3", NavParams(axis_deadband=3.0)),
    Variant("deadband_8", NavParams(axis_deadband=8.0)),
    Variant("arrival_8", NavParams(arrival_radius=8.0)),
    Variant("vent_cost_5", NavParams(), vent_cost=5.0, roles=("imposter",)),
    Variant("vent_cost_20", NavParams(), vent_cost=20.0, roles=("imposter",)),
]

# Folded-in prior result: lookahead/string-pulling was removed from the library
# after the 100-set ablation found it slower AND prone to deadlock (kept here as
# documented evidence rather than rerun, since it is no longer a NavParams knob).
KNOWN_FINDINGS = [
    "lookahead (removed): crew -12.8% (CI [-158,-45], 63/100 tours deadlocked); "
    "imposter -12.2% (CI [-99,-59], 28/100). Decisively slower -- do not revive.",
]


# --- task-set fixture -----------------------------------------------------


def _fixture_path() -> Path:
    return Path(str(files("swgy_tools.navbench") / FIXTURE))


def generate_sets() -> dict:
    """Deterministically sample 100 sets of 8 unique task-station indices."""
    rng = random.Random(SEED)
    sets = [sorted(rng.sample(range(N_STATIONS), TASKS_PER_SET)) for _ in range(N_SETS)]
    return {"seed": SEED, "n_stations": N_STATIONS, "tasks_per_set": TASKS_PER_SET, "sets": sets}


def load_sets() -> list[list[int]]:
    return json.loads(_fixture_path().read_text())["sets"]


# --- mesh + vents ---------------------------------------------------------

# Croatoan vent groups: ordered vent-rect centers per group; the engine cycles
# groupIndex -> groupIndex+1 (wrap to 1) -- sim.nim tryVent, data/croatoan.resources.
VENT_GROUPS: list[list[tuple[int, int]]] = [
    [(552, 289), (323, 115), (614, 118)],  # vent1
    [(552, 385), (510, 521), (354, 571)],  # vent2
    [(501, 341), (229, 345)],  # vent3
    [(740, 341), (929, 486), (929, 118)],  # vent4
]


def vent_node_cycles(mesh: NavMesh) -> list[list[int]]:
    """Each vent group's centers snapped to mesh nodes, in cycle order."""
    cycles = []
    for centers in VENT_GROUPS:
        ids = [mesh.nearest_node(cx, cy) for cx, cy in centers]
        ids = [n for n in ids if n is not None]
        if len(ids) >= 2:
            cycles.append(ids)
    return cycles


def build_vent_edges(cycles: list[list[int]], cost: float) -> list[NavEdge]:
    """Directed cyclic vent edges (node[i] -> node[i+1]) at the given hop cost."""
    edges: list[NavEdge] = []
    for ids in cycles:
        for i, src in enumerate(ids):
            dst = ids[(i + 1) % len(ids)]
            if src != dst:
                edges.append(
                    NavEdge(src=src, dst=dst, weight=cost, directed=True, tags=frozenset({"vent"}))
                )
    return edges


@dataclass
class Maps:
    crew: NavMesh
    imposters: dict[float, NavMesh]  # by vent_cost
    vent_pairs: set[tuple[int, int]]
    spawn: tuple[int, int]


def build_maps(vent_costs: tuple[float, ...]) -> Maps:
    mesh = load_default_mesh()
    cycles = vent_node_cycles(mesh)
    imposters = {}
    for cost in vent_costs:
        edges = build_vent_edges(cycles, cost)
        imposters[cost] = NavMesh(
            mesh.grid, mesh.nodes, list(mesh.edges) + edges, mesh.meta, mesh.tasks
        )
    vent_pairs = {(e.src, e.dst) for e in build_vent_edges(cycles, 0.0)}
    spawn_id = mesh.nearest_node(*SPAWN_XY)
    spawn = (mesh.node(spawn_id).x, mesh.node(spawn_id).y)
    return Maps(crew=mesh, imposters=imposters, vent_pairs=vent_pairs, spawn=spawn)


# --- driving a tour through the engine sim --------------------------------


def _tour_order(mesh: NavMesh, spawn: tuple[int, int], station_nodes: list[int]) -> list[int]:
    """Greedy nearest-neighbour visiting order, by ORDER_PARAMS plan cost."""
    remaining = list(station_nodes)
    order: list[int] = []
    cur: int | tuple[int, int] = spawn
    while remaining:
        best, best_cost = remaining[0], float("inf")
        for node in remaining:
            plan = find_path(mesh, cur, node, ORDER_PARAMS)
            c = plan.cost if plan is not None else float("inf")
            if c < best_cost:
                best, best_cost = node, c
        order.append(best)
        remaining.remove(best)
        cur = best
    return order


_MAX_REPLANS = 8


def _vent_pending(plan, vent_pairs: set[tuple[int, int]], imposter: bool) -> list[tuple[int, int]]:
    if not imposter:
        return []
    return [
        (i, i + 1)
        for i in range(len(plan.nodes) - 1)
        if (plan.nodes[i], plan.nodes[i + 1]) in vent_pairs
    ]


def drive_leg(
    eng: Engine,
    p: Player,
    mesh: NavMesh,
    goal: int,
    params: NavParams = NavParams(),
    vent_pairs: set[tuple[int, int]] | None = None,
    imposter: bool = False,
) -> int | None:
    """Tick the follower until the collision point is within REACH_RADIUS of the
    goal node; return travel ticks or None. Replans on stuck (as a live policy).

    Public because it is the honest oracle for "how long *should* this leg take":
    it pays the engine's real acceleration, friction and wall-sliding costs, so a
    comparison against a real player measures decision quality, not physics.
    """
    vent_pairs = vent_pairs or set()
    gx, gy = mesh.node(goal).x, mesh.node(goal).y
    r2 = REACH_RADIUS * REACH_RADIUS
    plan = find_path(mesh, (p.x, p.y), goal, params)
    if plan is None or len(plan) == 0:
        return None
    state = NavState(plan=plan, params=params, grid=mesh.grid)
    pending = _vent_pending(plan, vent_pairs, imposter)
    vi = 0
    replans = 0

    for tick in range(1, MAX_TICKS_PER_LEG + 1):
        if (p.x - gx) ** 2 + (p.y - gy) ** 2 <= r2:
            return tick - 1
        state.update((p.x, p.y))
        if state.needs_replan:
            if replans >= _MAX_REPLANS:
                return None
            replans += 1
            plan = find_path(mesh, (p.x, p.y), goal, params)
            if plan is None or len(plan) == 0:
                return None
            state.set_plan(plan)
            pending = _vent_pending(plan, vent_pairs, imposter)
            vi = 0
            continue

        if vi < len(pending):  # vent: within range of the entrance -> press B
            a_idx, b_idx = pending[vi]
            ax, ay = plan.waypoints[a_idx]
            if abs(p.x - ax) <= VENT_RANGE and abs(p.y - ay) <= VENT_RANGE:
                if p.vent_cooldown == 0:
                    bx, by = plan.waypoints[b_idx]
                    p.x, p.y = bx, by
                    p.velX = p.velY = p.carryX = p.carryY = 0
                    p.vent_cooldown = VENT_COOLDOWN
                    state.cursor = max(state.cursor, b_idx + 1)
                    vi += 1
                    continue
                eng.step(p, 0, 0)
                continue

        dx, dy = state.heading((p.x, p.y), collision=(p.x, p.y))
        eng.step(p, dx, dy)
    return None


def run_tour(
    mesh: NavMesh,
    order: list[int],
    params: NavParams,
    vent_pairs: set[tuple[int, int]],
    spawn: tuple[int, int],
    imposter: bool,
) -> int | None:
    eng = Engine(mesh.grid)
    p = Player(x=spawn[0], y=spawn[1])
    total = 0
    for goal in order:
        ticks = drive_leg(eng, p, mesh, goal, params, vent_pairs, imposter)
        if ticks is None:
            return None
        total += ticks
    return total


# --- worker (one task-set -> ticks per role:variant) ----------------------

_MAPS: Maps | None = None


def _vent_costs() -> tuple[float, ...]:
    return tuple(sorted({BASELINE_VENT_COST, *(v.vent_cost for v in VARIANTS)}))


def _init_worker() -> None:
    global _MAPS
    _MAPS = build_maps(_vent_costs())


def _run_set(task_indices: list[int]) -> dict:
    assert _MAPS is not None
    m = _MAPS
    nodes = [m.crew.task_node(m.crew.tasks[i]) for i in task_indices]
    nodes = [n for n in nodes if n is not None]
    crew_order = _tour_order(m.crew, m.spawn, nodes)
    imp_order = _tour_order(m.imposters[BASELINE_VENT_COST], m.spawn, nodes)
    out: dict[str, int | None] = {}
    for v in VARIANTS:
        for role in v.roles:
            if role == "crew":
                out[f"crew:{v.name}"] = run_tour(
                    m.crew, crew_order, v.params, m.vent_pairs, m.spawn, imposter=False
                )
            else:
                out[f"imposter:{v.name}"] = run_tour(
                    m.imposters[v.vent_cost],
                    imp_order,
                    v.params,
                    m.vent_pairs,
                    m.spawn,
                    imposter=True,
                )
    return out


# --- statistics (alpha = 0.05) --------------------------------------------

_T_975 = {99: 1.9842}  # Student-t two-sided 95% critical value by df


def _paired_stats(base: list[float], cand: list[float], rng: np.random.Generator) -> dict:
    b = np.array(base, dtype=float)
    c = np.array(cand, dtype=float)
    d = b - c  # positive == candidate is faster (fewer ticks)
    n = len(d)
    mean = float(d.mean())
    se = float(d.std(ddof=1)) / np.sqrt(n) if n > 1 else float("inf")
    t = _T_975.get(n - 1, 1.984)
    t_ci = (mean - t * se, mean + t * se)
    boot = rng.choice(d, size=(10_000, n), replace=True).mean(axis=1)
    boot_ci = tuple(float(x) for x in np.percentile(boot, [2.5, 97.5]))
    return {
        "n": n,
        "mean_before": float(b.mean()),
        "mean_after": float(c.mean()),
        "mean_improvement": mean,
        "pct_improvement": float((d / b).mean() * 100.0) if n else 0.0,
        "t_ci": t_ci,
        "boot_ci": boot_ci,
        "win_rate": float((d > 0).mean() * 100.0) if n else 0.0,
    }


def _verdict(s: dict) -> str:
    lo, hi = s["t_ci"]
    if lo > 0:
        return "FASTER (sig)"
    if hi < 0:
        return "slower (sig)"
    return "ns"


def run_benchmark(workers: int) -> dict:
    sets = load_sets()
    if workers > 1:
        with ProcessPoolExecutor(max_workers=workers, initializer=_init_worker) as ex:
            results = list(ex.map(_run_set, sets))
    else:
        _init_worker()
        results = [_run_set(s) for s in sets]

    rng = np.random.default_rng(SEED)
    out: dict = {"n_sets": len(sets), "roles": {}}
    for role in ("crew", "imposter"):
        candidates: dict = {}
        for v in VARIANTS:
            if v.name == BASELINE or role not in v.roles:
                continue
            bk, ck = f"{role}:{BASELINE}", f"{role}:{v.name}"
            paired = [(r[bk], r[ck]) for r in results if r[bk] is not None and r[ck] is not None]
            stats = _paired_stats([x for x, _ in paired], [y for _, y in paired], rng)
            stats["fails"] = len(results) - len(paired)
            stats["verdict"] = _verdict(stats)
            candidates[v.name] = stats
        out["roles"][role] = candidates
    return out


def format_report(out: dict) -> str:
    lines = [
        f"Nav ablation — {out['n_sets']} task-sets (8 stations), engine-faithful sim, "
        f"reach=center within {REACH_RADIUS:.0f}px",
        "Each candidate paired vs BASELINE. Δ = baseline − candidate travel ticks "
        "(positive ⇒ faster).",
        "Significant at alpha=0.05 when the 95% CI excludes 0.",
        "",
    ]
    for role in ("crew", "imposter"):
        lines.append(f"  {role}:")
        for name, s in out["roles"][role].items():
            lo, hi = s["t_ci"]
            lines.append(
                f"    {name:14s} base={s['mean_before']:6.1f} cand={s['mean_after']:6.1f} "
                f"Δ={s['mean_improvement']:+6.1f} ({s['pct_improvement']:+.1f}%) "
                f"95%CI[{lo:+.1f},{hi:+.1f}] win{s['win_rate']:3.0f}% fail{s['fails']:2d}  "
                f"-> {s['verdict']}"
            )
        lines.append("")
    lines.append("Folded-in prior findings:")
    lines += [f"  - {f}" for f in KNOWN_FINDINGS]
    return "\n".join(lines)


def main() -> None:
    ap = argparse.ArgumentParser(description="Paired CrewRift nav ablation benchmark.")
    ap.add_argument("--gen", action="store_true", help="(re)write the committed task-set fixture")
    ap.add_argument("--workers", type=int, default=1, help="parallel worker processes")
    ap.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    args = ap.parse_args()

    if args.gen:
        path = _fixture_path()
        path.write_text(json.dumps(generate_sets(), indent=2) + "\n")
        print(f"wrote {N_SETS} task-sets -> {path}")
        return

    out = run_benchmark(args.workers)
    print(json.dumps(out, indent=2) if args.json else format_report(out))


if __name__ == "__main__":
    main()
