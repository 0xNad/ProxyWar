"""Byte-faithful Python port of the CrewRift engine's player-movement step.

Ported from the CrewRift engine source ``sim.nim`` (read-only):
``applyInput`` (per-axis accel/friction, sim.nim:3012-3046), the slide-direction
preferences (sim.nim:3048-3077), ``applyMomentumAxis`` carry sub-stepping
(sim.nim:2657-2689) and ``trySlideMove``/``trySlideOffset``/``canSlide*``
(sim.nim:2579-2655), and ``canOccupy`` 1x1 collision against the **walk layer**
(sim.nim:1688-1698) -- which is exactly :class:`swgy_base.nav.model.NavGrid`.

Everything is integer fixed-point like the engine: velocity is in units where
``MOTION_SCALE`` units == 1 pixel/tick, position is integer pixels, and a per-axis
``carry`` accumulates sub-pixel motion. Nim's ``div`` truncates toward zero, so we
use :func:`_tdiv` for the friction divide (Python ``//`` floors -- wrong for
negative velocity).
"""

from __future__ import annotations

from dataclasses import dataclass

from swgy_base.nav.model import NavGrid

# --- engine constants (sim.nim:29-39, 54) ---------------------------------
MOTION_SCALE = 256
ACCEL = 76
FRICTION_NUM = 144
FRICTION_DEN = 256
MAX_SPEED = 704
STOP_THRESHOLD = 8
SLIDE_MAX_SCAN = 3
COLLISION_W = 1
COLLISION_H = 1
VENT_RANGE = 16
VENT_COOLDOWN = 30

# Terminal speeds in px/tick (MAX_SPEED / MOTION_SCALE), exposed for tests/sanity.
TERMINAL_PX = MAX_SPEED / MOTION_SCALE  # 2.75, cardinal per-axis


def _tdiv(a: int, b: int) -> int:
    """Integer division truncating toward zero, matching Nim's ``div``."""
    q = abs(a) // abs(b)
    return q if (a < 0) == (b < 0) else -q


def _sign(v: int) -> int:
    return (v > 0) - (v < 0)


def _clamp(v: int, lo: int, hi: int) -> int:
    return lo if v < lo else hi if v > hi else v


@dataclass
class Player:
    """Mutable player kinematic state (integer fixed-point, like the engine)."""

    x: int
    y: int
    velX: int = 0
    velY: int = 0
    carryX: int = 0
    carryY: int = 0
    vent_cooldown: int = 0

    @property
    def pos(self) -> tuple[int, int]:
        return (self.x, self.y)

    @property
    def center(self) -> tuple[int, int]:
        # sim.nim uses player.x + CollisionW div 2 as the gameplay center.
        return (self.x + COLLISION_W // 2, self.y + COLLISION_H // 2)

    @property
    def speed_px(self) -> float:
        return (self.velX * self.velX + self.velY * self.velY) ** 0.5 / MOTION_SCALE


class Engine:
    """The movement half of the CrewRift sim over a fixed walk grid."""

    def __init__(self, grid: NavGrid) -> None:
        self.grid = grid

    # --- collision (sim.nim:1688-1698) ------------------------------------

    def can_occupy(self, x: int, y: int) -> bool:
        for dy in range(COLLISION_H):
            for dx in range(COLLISION_W):
                if not self.grid.is_walkable(x + dx, y + dy):
                    return False
        return True

    # --- the per-tick step ------------------------------------------------

    def step(self, p: Player, inputX: int, inputY: int) -> None:
        """Advance ``p`` one tick under held input ``inputX``/``inputY`` in {-1,0,1}."""
        if p.vent_cooldown > 0:
            p.vent_cooldown -= 1
        self._apply_input(p, inputX, inputY)
        preferred_slide_y = inputY if inputY != 0 else _sign(p.velY)
        preferred_slide_x = inputX if inputX != 0 else _sign(p.velX)
        self._apply_momentum_axis(p, preferred_slide_y, horizontal=True)
        self._apply_momentum_axis(p, preferred_slide_x, horizontal=False)

    def _apply_input(self, p: Player, inputX: int, inputY: int) -> None:
        if inputX != 0:
            p.velX = _clamp(p.velX + inputX * ACCEL, -MAX_SPEED, MAX_SPEED)
        else:
            p.velX = _tdiv(p.velX * FRICTION_NUM, FRICTION_DEN)
            if abs(p.velX) < STOP_THRESHOLD:
                p.velX = 0
        if inputY != 0:
            p.velY = _clamp(p.velY + inputY * ACCEL, -MAX_SPEED, MAX_SPEED)
        else:
            p.velY = _tdiv(p.velY * FRICTION_NUM, FRICTION_DEN)
            if abs(p.velY) < STOP_THRESHOLD:
                p.velY = 0

    def _apply_momentum_axis(self, p: Player, preferred_slide: int, *, horizontal: bool) -> None:
        velocity = p.velX if horizontal else p.velY
        carry = (p.carryX if horizontal else p.carryY) + velocity
        while abs(carry) >= MOTION_SCALE:
            step = -1 if carry < 0 else 1
            nx = p.x + step if horizontal else p.x
            ny = p.y if horizontal else p.y + step
            if self.can_occupy(nx, ny):
                if horizontal:
                    p.x = nx
                else:
                    p.y = ny
                carry -= step * MOTION_SCALE
            else:
                radius = self._slide_scan_radius(carry, velocity)
                if self._try_slide_move(p, step, radius, preferred_slide, horizontal):
                    carry -= step * MOTION_SCALE
                else:
                    carry = 0
                    break
        if horizontal:
            p.carryX = carry
        else:
            p.carryY = carry

    def _slide_scan_radius(self, carry: int, velocity: int) -> int:
        pending = abs(carry) // MOTION_SCALE
        speed = (abs(velocity) + MOTION_SCALE - 1) // MOTION_SCALE
        return _clamp(max(1, max(pending, speed)), 1, SLIDE_MAX_SCAN)

    def _try_slide_move(
        self, p: Player, step: int, radius: int, preferred_slide: int, horizontal: bool
    ) -> bool:
        if radius <= 0:
            return False
        preferred = _sign(preferred_slide)
        for distance in range(1, radius + 1):
            if preferred != 0:
                if self._try_slide_offset(p, step, preferred * distance, horizontal):
                    return True
                if self._try_slide_offset(p, step, -preferred * distance, horizontal):
                    return True
            else:
                if self._try_slide_offset(p, step, -distance, horizontal):
                    return True
                if self._try_slide_offset(p, step, distance, horizontal):
                    return True
        return False

    def _try_slide_offset(self, p: Player, step: int, offset: int, horizontal: bool) -> bool:
        if horizontal:
            if not self._can_slide_horizontal(p.x, p.y, step, offset):
                return False
            p.x += step
            p.y += offset
        else:
            if not self._can_slide_vertical(p.x, p.y, step, offset):
                return False
            p.x += offset
            p.y += step
        return True

    def _can_slide_horizontal(self, x: int, y: int, step: int, offset: int) -> bool:
        if offset == 0:
            return False
        slide_step = _sign(offset)
        for i in range(1, abs(offset) + 1):
            if not self.can_occupy(x, y + slide_step * i):
                return False
        return self.can_occupy(x + step, y + offset)

    def _can_slide_vertical(self, x: int, y: int, step: int, offset: int) -> bool:
        if offset == 0:
            return False
        slide_step = _sign(offset)
        for i in range(1, abs(offset) + 1):
            if not self.can_occupy(x + slide_step * i, y):
                return False
        return self.can_occupy(x + offset, y + step)
