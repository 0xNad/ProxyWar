"""Faithful engine-movement port + paired nav benchmark (analysis-only).

This subpackage re-implements the CrewRift engine's *player movement* step
(``enginesim``) byte-for-byte from the CrewRift engine source (``sim.nim``)
so a navigation policy can be measured against real engine physics + collision,
then runs a paired before/after benchmark (``bench``) over a fixed set of task
tours, for both crew (walk-only) and imposter (vents allowed). It lives in
swgy-tools because it is offline analysis; the policy runtime never imports it.
"""
