#!/usr/bin/env python3
"""Record a raw sprite_v1 stream from a live CrewRift game to disk.

Connects to a game as a player slot (the egocentric stream a policy will
actually see), reads binary sprite_v1 frames, and writes each one as a
length-prefixed record so it can be replayed frame-by-frame later.

Installed as the ``swgy-capture`` console script:

    uv run swgy-capture --slot 0 --token token-0 \
        --host 127.0.0.1 --port 18080 --decode --out captures/croatoan-slot0.spv1

URL resolution order: --url, then $COWORLD_PLAYER_WS_URL (mirror
$COGAMES_ENGINE_WS_URL), else constructed as
``ws://<host>:<port><path>?slot=<N>&token=<T>`` (path default ``/player``).

Capture container format:
    header  : b"SPV1CAP\\0" + u16 version (little-endian)
    record* : u64 monotonic_ns + u32 payload_len + payload bytes
"""

from __future__ import annotations

import argparse
import os
import struct
import sys
import time
from pathlib import Path
from urllib.parse import quote

from swgy_base.protocol import SceneGraph
from websockets.sync.client import connect

CAPTURE_MAGIC = b"SPV1CAP\x00"
CAPTURE_VERSION = 1
RECORD_HEADER = struct.Struct("<QI")  # monotonic_ns, payload_len


def resolve_url(args: argparse.Namespace) -> str:
    if args.url:
        return args.url
    env = os.environ.get("COWORLD_PLAYER_WS_URL") or os.environ.get("COGAMES_ENGINE_WS_URL")
    if env:
        return env
    query = f"slot={args.slot}"
    if args.token:
        query += f"&token={quote(args.token)}"
    if args.name:
        query += f"&name={quote(args.name)}"
    return f"ws://{args.host}:{args.port}{args.path}?{query}"


def connect_with_retry(url: str, timeout: float):
    deadline = time.time() + timeout
    last_error: Exception | None = None
    while time.time() < deadline:
        try:
            return connect(url, open_timeout=1.0, ping_interval=None, max_size=None)
        except Exception as exc:  # noqa: BLE001 -- retry on any connect failure
            last_error = exc
            time.sleep(0.05)
    raise RuntimeError(f"failed to connect to {url}") from last_error


def summarize(scene: SceneGraph) -> str:
    labels = sorted({s.label for s in scene.sprites.values() if s.label})
    sample = ", ".join(labels[:6])
    return (
        f"frame {scene.frame_count}: {len(scene.sprites)} sprites, "
        f"{len(scene.objects)} objects | {sample}"
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--url", help="full ws:// URL (overrides host/port/slot/token)")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=18080)
    parser.add_argument(
        "--path", default="/player", help="ws path (try /sprite_player if rejected)"
    )
    parser.add_argument("--slot", type=int, default=0)
    parser.add_argument("--token", default="", help="slot auth token")
    parser.add_argument("--name", default="", help="optional join name")
    parser.add_argument("--out", help="output .spv1 path (default captures/crewrift-<slot>.spv1)")
    parser.add_argument(
        "--decode", action="store_true", help="parse each frame and print a summary"
    )
    parser.add_argument("--connect-timeout", type=float, default=15.0)
    parser.add_argument(
        "--max-frames", type=int, default=0, help="stop after N frames (0 = unlimited)"
    )
    args = parser.parse_args()

    url = resolve_url(args)
    out_path = Path(args.out) if args.out else Path("captures") / f"crewrift-{args.slot}.spv1"
    out_path.parent.mkdir(parents=True, exist_ok=True)

    print(f"connecting to {url}", file=sys.stderr)
    ws = connect_with_retry(url, args.connect_timeout)
    print(f"connected; recording to {out_path}", file=sys.stderr)

    scene = SceneGraph() if args.decode else None
    frames = 0
    bytes_written = 0
    try:
        with out_path.open("wb") as out:
            out.write(CAPTURE_MAGIC + struct.pack("<H", CAPTURE_VERSION))
            while True:
                try:
                    payload = ws.recv(timeout=1.0)
                except TimeoutError:
                    continue
                if not isinstance(payload, (bytes, bytearray)):
                    # Text frames aren't part of sprite_v1; note and skip.
                    print(f"(text frame: {payload!r})", file=sys.stderr)
                    continue
                payload = bytes(payload)
                out.write(RECORD_HEADER.pack(time.monotonic_ns(), len(payload)))
                out.write(payload)
                out.flush()  # whole records hit disk even on a hard SIGTERM
                frames += 1
                bytes_written += len(payload)
                if scene is not None:
                    scene.apply_packet(payload)
                    print(summarize(scene), file=sys.stderr)
                if args.max_frames and frames >= args.max_frames:
                    break
    except KeyboardInterrupt:
        print("\ninterrupted", file=sys.stderr)
    finally:
        try:
            ws.close()
        except Exception:  # noqa: BLE001
            pass
    print(f"recorded {frames} frames, {bytes_written} bytes -> {out_path}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
