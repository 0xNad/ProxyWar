"""Shared look for the matplotlib renderers: the validated palette and the basemap.

Three renderers now draw Croatoan (``tasks/render``, ``spatial/render``,
``spatial/killplot``). This module holds only what is genuinely identical between them
-- the colours, the basemap, and the world->pixel axes setup. It deliberately does not
try to unify their axes styling: one wants spines off with ticks kept, one wants the
axes hidden entirely, one wants equal aspect. Those are three different things, and
reconciling them behind flags would be the abstraction ``docs/python-guidelines/
abstraction.md`` warns about. Four lines each, in each renderer.

**The palette was validated as a set** (worst adjacent CVD dE 20.7 on the ``SURFACE``
dark step). Adding a fifth hue means re-running the validator, not eyeballing it.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")  # headless: render to file, never to a window

import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

MAP_PNG = Path(__file__).resolve().parent / "assets" / "croatoan_map.png"

# Chrome
PAGE = "#0d0d0d"
SURFACE = "#1a1a19"
INK = "#ffffff"
SECONDARY = "#c3c2b7"
MUTED = "#898781"
GRID = "#2c2c2a"

# Categorical, validated as a set on SURFACE. The meanings are shared across the
# tools on purpose: a red cross is a death in the swimlanes and on the map.
ALIVE = "#3987e5"  # blue   -- crew, alive, doing a task
GHOST = "#199e70"  # aqua   -- dead but still acting
DEATH = "#d03b3b"  # red    -- the kill (status: critical)
MEETING = "#c98500"  # amber -- a meeting; also the imposter/antagonist track

# Markers are drawn over the basemap, whose luminance varies per pixel, so a dark edge
# is what keeps them legible on a bright corridor. Not decoration -- the mitigation.
EDGE = "#0b0b0b"

# Map-landmark markers, shared by every renderer and notebook that draws the ship:
# task stations are cyan squares, vents are magenta diamonds. One source of truth --
# two notebooks once hand-picked near-identical values (#33e0ff vs #3cd2eb) and the
# mismatch read as a slip.
TASK_MARK = "#3cd2eb"
VENT_MARK = "#ff50eb"


def basemap(dim: float = 0.55) -> np.ndarray | None:
    """The vendored Croatoan map, desaturated and dimmed so overlays read on top.

    ``dim`` is pinned low by default: markers in the validated palette lose contrast
    against a bright basemap, and the palette was validated against a dark surface.
    """
    if not MAP_PNG.exists():
        return None
    img = plt.imread(str(MAP_PNG))[:, :, :3].astype(np.float32)
    if img.max() > 1.0:
        img /= 255.0
    gray = img @ np.array([0.299, 0.587, 0.114], np.float32)
    return np.repeat(gray[:, :, None], 3, axis=2) * dim


def croatoan_axes(ax, map_w: int, map_h: int, *, dim: float = 0.55) -> None:
    """Draw the basemap and set up world coords on ``ax``.

    Croatoan's world coordinates are 1:1 with the map image and **y points down**, so
    the extent is ``[0, w, h, 0]`` and the y-limits are inverted.
    """
    bg = basemap(dim)
    if bg is not None:
        ax.imshow(bg, extent=[0, map_w, map_h, 0], interpolation="bilinear", zorder=0)
    ax.set_xlim(0, map_w)
    ax.set_ylim(map_h, 0)
    ax.set_facecolor(SURFACE)
