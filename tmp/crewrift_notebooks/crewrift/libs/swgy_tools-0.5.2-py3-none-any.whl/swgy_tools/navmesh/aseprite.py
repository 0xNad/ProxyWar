"""Minimal Aseprite reader: extract one layer as a walkability mask or RGBA.

The CrewRift engine derives walkability from the **walk layer** (layer 1) of
``data/croatoan.aseprite`` -- a pixel is walkable iff that layer's alpha > 0
(``src/crewrift/sim.nim``: ``walkMask[i] = walkImage[x,y].a > 0``). The server
never streams this collision layer to clients, so an offline read of the source
art is the only ground truth. ``walk_mask`` returns that boolean layer;
``layer_rgba`` returns a visible layer's color (the map art, for visualization).
This is a focused port of the layer-extraction path in the engine's
``aseprite.nim``. zlib (stdlib) + numpy only.
"""

from __future__ import annotations

import struct
import zlib
from pathlib import Path

import numpy as np

_HEADER_MAGIC = 0xA5E0
_FRAME_MAGIC = 0xF1FA
_CHUNK_CEL = 0x2005
_HEADER_BYTES = 128
WALK_LAYER = 1  # sim.nim: result.walkLayer = 1
WALL_LAYER = 2  # sim.nim: result.wallLayer = 2 (line-of-sight occluders)

# colorDepth -> bytes per pixel
_BPP = {8: 1, 16: 2, 32: 4}


class _Header:
    __slots__ = ("frame_count", "width", "height", "depth", "transparent_index")


def _parse_header(data: bytes) -> _Header:
    if len(data) < _HEADER_BYTES:
        raise ValueError("aseprite file too small")
    (_size, magic, frame_count, width, height, depth) = struct.unpack_from("<IHHHHH", data, 0)
    if magic != _HEADER_MAGIC:
        raise ValueError(f"bad aseprite magic {magic:#06x}")
    if depth not in _BPP:
        raise ValueError(f"unsupported color depth {depth}")
    (transparent_index,) = struct.unpack_from("<B", data, 28)
    h = _Header()
    h.frame_count, h.width, h.height, h.depth = frame_count, width, height, depth
    h.transparent_index = transparent_index
    return h


def _decode_cel(data: bytes, pos: int, chunk_end: int, hdr: _Header):
    """Return ``(layer, cx, cy, pixels[ch, cw, bpp])`` for an image cel, or None."""
    cel_layer, cx, cy, _opacity, cel_type, _zindex = struct.unpack_from("<HhhBHh", data, pos)
    pos += 16  # layer(2)+x(2)+y(2)+opacity(1)+type(2)+zindex(2)+reserved(5)
    if cel_type not in (0, 2):  # raw or compressed image only
        return None
    cw, ch = struct.unpack_from("<HH", data, pos)
    pos += 4
    bpp = _BPP[hdr.depth]
    if cel_type == 0:  # raw
        raw = data[pos : pos + cw * ch * bpp]
    else:  # compressed (zlib)
        raw = zlib.decompress(data[pos:chunk_end])
    if len(raw) != cw * ch * bpp:
        raise ValueError("aseprite cel size mismatch")
    pixels = np.frombuffer(raw, dtype=np.uint8).reshape(ch, cw, bpp)
    return cel_layer, cx, cy, pixels


def _iter_first_frame_cels(data: bytes, hdr: _Header):
    """Yield ``(layer, cx, cy, pixels)`` for each image cel in the first frame."""
    if hdr.frame_count == 0:
        raise ValueError("aseprite has no frames")
    pos = _HEADER_BYTES
    frame_bytes, frame_magic = struct.unpack_from("<IH", data, pos)
    if frame_magic != _FRAME_MAGIC:
        raise ValueError(f"bad frame magic {frame_magic:#06x}")
    old_count, _dur, _pad, new_count = struct.unpack_from("<HHHI", data, pos + 6)
    chunk_count = new_count if new_count != 0 else old_count
    frame_end = pos + frame_bytes
    cpos = pos + 16  # frame header is 16 bytes
    for _ in range(chunk_count):
        if cpos + 6 > frame_end:
            break
        chunk_size, chunk_type = struct.unpack_from("<IH", data, cpos)
        chunk_end = cpos + chunk_size
        if chunk_type == _CHUNK_CEL:
            cel = _decode_cel(data, cpos + 6, chunk_end, hdr)
            if cel is not None:
                yield cel
        cpos = chunk_end


def _cel_alpha(hdr: _Header, pixels: np.ndarray) -> np.ndarray:
    """``(ch, cw)`` bool 'has alpha' for decoded cel pixels, per color depth."""
    if hdr.depth == 32:  # RGBA: alpha is byte 3
        return pixels[:, :, 3] > 0
    if hdr.depth == 16:  # grayscale: (value, alpha)
        return pixels[:, :, 1] > 0
    # indexed (8bpp): transparent index => alpha 0, else opaque
    return pixels[:, :, 0] != hdr.transparent_index


def _blit(dst: np.ndarray, src: np.ndarray, cx: int, cy: int, combine: bool = False) -> None:
    """Place ``src`` onto ``dst`` at ``(cx, cy)``, clipped. ``combine`` ORs (masks)."""
    h, w = dst.shape[:2]
    ch, cw = src.shape[:2]
    x0, y0 = max(0, cx), max(0, cy)
    x1, y1 = min(w, cx + cw), min(h, cy + ch)
    if x1 <= x0 or y1 <= y0:
        return
    sub = src[y0 - cy : y1 - cy, x0 - cx : x1 - cx]
    if combine:
        dst[y0:y1, x0:x1] |= sub
    else:
        dst[y0:y1, x0:x1] = sub


def walk_mask(path: str | Path, layer_index: int = WALK_LAYER) -> np.ndarray:
    """Return a ``(height, width)`` bool walkability mask from an aseprite layer."""
    data = Path(path).read_bytes()
    hdr = _parse_header(data)
    mask = np.zeros((hdr.height, hdr.width), dtype=bool)
    for layer, cx, cy, pixels in _iter_first_frame_cels(data, hdr):
        if layer == layer_index:
            _blit(mask, _cel_alpha(hdr, pixels), cx, cy, combine=True)
    return mask


def layer_rgba(path: str | Path, layer_index: int = 0) -> np.ndarray:
    """Return a ``(height, width, 4)`` uint8 RGBA composite of one visible layer.

    For the map art (the visible layer, index 0). Only RGBA (32bpp) sources are
    supported -- the Croatoan art is RGBA; indexed/grayscale would need a palette.
    Pixels outside the layer's cel stay transparent (alpha 0).
    """
    data = Path(path).read_bytes()
    hdr = _parse_header(data)
    if hdr.depth != 32:
        raise ValueError(f"layer_rgba needs a 32bpp RGBA aseprite, got depth {hdr.depth}")
    canvas = np.zeros((hdr.height, hdr.width, 4), dtype=np.uint8)
    for layer, cx, cy, pixels in _iter_first_frame_cels(data, hdr):
        if layer == layer_index:
            _blit(canvas, pixels, cx, cy)
    return canvas
