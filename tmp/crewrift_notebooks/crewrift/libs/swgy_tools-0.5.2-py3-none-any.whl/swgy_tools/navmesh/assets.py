"""Locate the Croatoan source assets a nav build reads.

Walkability comes from the **walk layer** of ``croatoan.aseprite`` and room tags
from ``croatoan.resources`` -- both authored game source (the server never
streams the collision layer, so the rendered map sprite can't supply true
walkability). This module just resolves their paths in the checked-out game
data dir; the build is offline, Python-only, no Docker or live capture.

The data dir is resolved in priority order: an explicit ``--data-dir``, then the
``CREWRIFT_DATA_DIR`` environment variable, then ``./data`` in the current
directory.
"""

from __future__ import annotations

import os
from pathlib import Path

ENV_VAR = "CREWRIFT_DATA_DIR"
ASEPRITE_NAME = "croatoan.aseprite"
RESOURCES_NAME = "croatoan.resources"


def _candidate_dirs(explicit: str | None) -> list[Path]:
    if explicit:
        return [Path(explicit)]
    env = os.environ.get(ENV_VAR)
    return [Path(env)] if env else [Path("data")]


def find_data_dir(explicit: str | None = None) -> Path:
    """Return the game ``data/`` dir holding the Croatoan assets.

    Resolution order: ``explicit`` -> ``$CREWRIFT_DATA_DIR`` -> ``./data``.
    """
    candidates = _candidate_dirs(explicit)
    for d in candidates:
        if (d / ASEPRITE_NAME).exists():
            return d
    raise FileNotFoundError(
        f"{ASEPRITE_NAME} not found in {[str(c) for c in candidates]}; "
        f"pass --data-dir (or set ${ENV_VAR}) to the crewrift game data/ dir "
        "holding croatoan.aseprite + croatoan.resources"
    )


def aseprite_path(data_dir: Path, override: str | None = None) -> Path:
    return Path(override) if override else data_dir / ASEPRITE_NAME


def resources_path(data_dir: Path, override: str | None = None) -> Path:
    return Path(override) if override else data_dir / RESOURCES_NAME
