"""Nav-mesh builder for Croatoan (console script: ``swgy-navmesh``).

Pulls/caches the map assets, builds a *simple* walkability grid + waypoint
graph of configurable density, and emits a self-described JSON interchange.
swgy-base ingests the interchange and owns the canonical binary format -- this
tool imports ``swgy_base.protocol`` (to decode the map sprite) but **never**
``swgy_base.nav``.

Modules:
    resources   -- parse croatoan.resources room rectangles
    walkgrid    -- RGBA map sprite -> walkable mask -> packed bits
    build       -- lattice nodes + line-of-sight edges + room tags
    assets      -- pull/cache the map sprite + croatoan.resources
    interchange -- emit the JSON interchange
    cli         -- orchestrate (main)
"""
