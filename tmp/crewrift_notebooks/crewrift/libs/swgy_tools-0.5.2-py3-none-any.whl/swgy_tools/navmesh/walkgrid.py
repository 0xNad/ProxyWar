"""Pack a walkability mask into LSB-first bits (``walks.bin`` layout).

The mask itself is produced by ``aseprite.walk_mask`` (the engine's walk layer),
not from rendered pixel color -- collision is authored, not visual.
"""

from __future__ import annotations

import numpy as np


def pack_bits(mask: np.ndarray) -> bytes:
    """Pack a 2-D bool mask into LSB-first bits, row-major."""
    return np.packbits(mask.astype(bool).reshape(-1), bitorder="little").tobytes()
