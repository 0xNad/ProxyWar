"""Parse ``croatoan.resources`` and classify rects into rooms / vents / tasks.

CSS-like named blocks (``/* name */`` then ``left/top/width/height`` px). The
engine classifies each block by name (``src/crewrift/sim.nim``): vents start with
"vent" (but not the "vents" container), tasks are named "task", rooms are any
other named rect except the "rooms"/"vents"/"tasks" container boxes. We mirror
that so nav nodes get correct ``room:<name>`` / ``vent`` / ``task`` tags.
Coordinates are 1:1 with map-sprite pixels and world coords (sim.nim mapIndex).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

_CONTAINERS = {"rooms", "vents", "tasks"}


@dataclass(frozen=True)
class Rect:
    name: str
    x: int
    y: int
    w: int
    h: int

    def contains(self, x: int, y: int) -> bool:
        return self.x <= x < self.x + self.w and self.y <= y < self.y + self.h

    @property
    def center(self) -> tuple[int, int]:
        return self.x + self.w // 2, self.y + self.h // 2


def _key(name: str) -> str:
    return name.strip().lower()


def _is_vent(name: str) -> bool:
    k = _key(name)
    return k.startswith("vent") and k != "vents"


def _is_task(name: str) -> bool:
    return _key(name) == "task"


def _is_room(name: str) -> bool:
    k = _key(name)
    return len(k) > 0 and k not in _CONTAINERS and not k.startswith("vent") and k != "task"


def _vent_group(name: str) -> str:
    """Compact vent group id = last alphanumeric char of the key (sim.nim)."""
    k = _key(name)
    for ch in reversed(k):
        if ch.isalnum():
            return ch
    return "v"


def _parse_px(value: str) -> int:
    v = value.strip().rstrip(";").strip()
    if v.lower().endswith("px"):
        v = v[:-2].strip()
    return int(round(float(v)))


def parse_rects(text: str) -> list[Rect]:
    """Return every named rectangle with a full left/top/width/height."""
    rects: list[Rect] = []
    name = ""
    vals: dict[str, int] = {}

    def flush() -> None:
        if name and {"left", "top", "width", "height"} <= vals.keys():
            rects.append(Rect(name, vals["left"], vals["top"], vals["width"], vals["height"]))

    for line in text.splitlines():
        t = line.strip()
        if t.startswith("/*") and t.endswith("*/"):
            flush()
            name, vals = t[2:-2].strip(), {}
            continue
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        key = key.strip().lower()
        if key in ("left", "top", "width", "height"):
            try:
                vals[key] = _parse_px(value)
            except ValueError:
                pass
    flush()
    return rects


@dataclass
class Resources:
    rooms: list[Rect] = field(default_factory=list)
    vents: list[Rect] = field(default_factory=list)
    tasks: list[Rect] = field(default_factory=list)

    def tags_at(self, x: int, y: int) -> set[str]:
        """All semantic tags for a node at (x, y).

        A point gets the ``room:`` tag of the FIRST room rect that contains it
        (file order). That is unambiguous only while the room rects don't overlap
        -- see :meth:`overlapping_rooms`, which the builder checks so a source
        edit that introduces an overlap can't silently mis-tag nodes by order.
        """
        tags: set[str] = set()
        room = next((r for r in self.rooms if r.contains(x, y)), None)
        tags.add(f"room:{room.name}" if room else "corridor")
        if any(v.contains(x, y) for v in self.vents):
            tags.add("vent")
        if any(t.contains(x, y) for t in self.tasks):
            tags.add("task")
        return tags

    def overlapping_rooms(self) -> list[tuple[str, str, int]]:
        """Room-rect pairs that overlap, each with the overlap area (px^2).

        ``tags_at`` assigns a node to the first containing room rect, so an
        overlap makes the ``room:`` tag depend on rect order rather than geometry
        -- untrustworthy. The authored Croatoan rooms don't overlap; the builder
        warns if that ever stops being true. Empty list == clean, partitioned rooms.
        """
        out: list[tuple[str, str, int]] = []
        rs = self.rooms
        for i in range(len(rs)):
            a = rs[i]
            for b in rs[i + 1 :]:
                iw = min(a.x + a.w, b.x + b.w) - max(a.x, b.x)
                ih = min(a.y + a.h, b.y + b.h) - max(a.y, b.y)
                if iw > 0 and ih > 0:
                    out.append((a.name, b.name, iw * ih))
        return out

    def vent_seeds(self) -> list[tuple[int, int, frozenset[str]]]:
        """One seed node per vent center, tagged vent + vent:<group>."""
        return [
            (v.center[0], v.center[1], frozenset({"vent", f"vent:{_vent_group(v.name)}"}))
            for v in self.vents
        ]

    def task_seeds(self, mask) -> list[tuple[int, int, frozenset[str]]]:
        """One seed node per task station (walkable pixel nearest its center).

        Task stations are 14x14; a coarse lattice rarely drops a node inside one,
        so without seeding several stations collapse onto a shared nearest node
        and a few px of error creep in. Seeding guarantees every station has its
        own node (tagged ``task``) so completing a task means standing ON it.
        """
        h, w = mask.shape
        seeds: list[tuple[int, int, frozenset[str]]] = []
        for t in self.tasks:
            cx, cy = t.center
            pt: tuple[int, int] | None = None
            if 0 <= cx < w and 0 <= cy < h and mask[cy, cx]:
                pt = (cx, cy)
            else:  # nearest walkable to center within the task rect
                best: tuple[int, int, int] | None = None
                for yy in range(max(0, t.y), min(h, t.y + t.h)):
                    for xx in range(max(0, t.x), min(w, t.x + t.w)):
                        if mask[yy, xx]:
                            d = (xx - cx) ** 2 + (yy - cy) ** 2
                            if best is None or d < best[0]:
                                best = (d, xx, yy)
                if best is not None:
                    pt = (best[1], best[2])
            if pt is not None:
                seeds.append((pt[0], pt[1], frozenset({"task"})))
        return seeds

    def room_seeds(self, mask) -> list[tuple[int, int, frozenset[str]]]:
        """One seed node per room: a walkable pixel nearest the room center.

        Small or oddly-shaped rooms can fall between lattice points (or have no
        clearance-passing cell), leaving them with no node at all. Seeding a
        guaranteed walkable point per room keeps every room represented (and the
        connectivity pass then bridges it). ``mask`` is the walkability array.
        """
        h, w = mask.shape
        seeds: list[tuple[int, int, frozenset[str]]] = []
        for r in self.rooms:
            cx, cy = r.center
            pt: tuple[int, int] | None = None
            if 0 <= cx < w and 0 <= cy < h and mask[cy, cx]:
                pt = (cx, cy)
            else:  # nearest walkable to center within the room rect
                best: tuple[int, int, int] | None = None
                for yy in range(max(0, r.y), min(h, r.y + r.h)):
                    for xx in range(max(0, r.x), min(w, r.x + r.w)):
                        if mask[yy, xx]:
                            d = (xx - cx) ** 2 + (yy - cy) ** 2
                            if best is None or d < best[0]:
                                best = (d, xx, yy)
                if best is not None:
                    pt = (best[1], best[2])
            if pt is not None:
                seeds.append((pt[0], pt[1], frozenset({f"room:{r.name}"})))
        return seeds

    def task_stations(self) -> list[dict]:
        """One station per task rect: id, center (x, y), containing room, name."""
        stations = []
        for i, t in enumerate(self.tasks):
            cx, cy = t.center
            room = next((r.name for r in self.rooms if r.contains(cx, cy)), None)
            stations.append(
                {"id": i, "x": cx, "y": cy, "room": room, "name": t.name or f"Task {i}"}
            )
        return stations

    def vent_stations(self) -> list[dict]:
        """One station per vent rect: id, exact center (x, y), containing room, group.

        ``group`` is ``vent:<n>`` (the engine's teleport-connectivity cluster). Centres
        are exact rect centres -- the same the engine streams as ``WorldState.vents`` --
        unlike the grid-snapped ``vent``-tagged nav nodes.
        """
        stations = []
        for i, v in enumerate(self.vents):
            cx, cy = v.center
            room = next((r.name for r in self.rooms if r.contains(cx, cy)), None)
            stations.append(
                {"id": i, "x": cx, "y": cy, "room": room, "group": f"vent:{_vent_group(v.name)}"}
            )
        return stations


def load_resources(path: str | Path) -> Resources:
    p = Path(path)
    rects = parse_rects(p.read_text()) if p.exists() else []
    return Resources(
        rooms=[r for r in rects if _is_room(r.name)],
        vents=[r for r in rects if _is_vent(r.name)],
        tasks=[r for r in rects if _is_task(r.name)],
    )
