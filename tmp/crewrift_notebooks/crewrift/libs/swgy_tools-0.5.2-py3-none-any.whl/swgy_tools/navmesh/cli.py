"""``swgy-navmesh``: build a Croatoan nav-mesh interchange from game source.

Walkability is read from the **walk layer** of ``croatoan.aseprite`` (the
engine's true collision mask, which the server never streams); room tags come
from ``croatoan.resources``. Offline, Python-only -- no Docker, no live capture.

    uv run swgy-navmesh --grid 14 --out tmp/croatoan.navmesh.json --debug-image tmp/nav.bmp

Then compile to the canonical asset with swgy-base (the format owner):

    uv run python -m swgy_base.nav compile tmp/croatoan.navmesh.json \
        assets/croatoan.walk assets/croatoan.graph
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np

from ..imaging import draw_line, write_png
from . import assets
from .aseprite import WALK_LAYER, walk_mask
from .build import BuildParams, build_graph
from .interchange import build_interchange, write_interchange
from .resources import Resources, load_resources


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Build a Croatoan nav-mesh interchange.")
    p.add_argument("--grid", type=int, default=14, help="node lattice spacing, px (density)")
    p.add_argument("--edge-max", type=int, default=30, help="longest edge, px")
    p.add_argument("--node-clear", type=int, default=0, help="clearance box radius around nodes")
    p.add_argument("--edge-clear", type=int, default=0, help="corridor band radius on edges")
    p.add_argument(
        "--data-dir", help="crewrift game data/ dir (default: $CREWRIFT_DATA_DIR, else ./data)"
    )
    p.add_argument("--aseprite", help="path to croatoan.aseprite (overrides --data-dir)")
    p.add_argument("--resources", help="path to croatoan.resources (overrides --data-dir)")
    p.add_argument(
        "--walk-layer", type=int, default=WALK_LAYER, help="aseprite walkability layer index"
    )
    p.add_argument("--no-resources", action="store_true", help="skip room tags")
    p.add_argument("--out", default="tmp/croatoan.navmesh.json")
    p.add_argument("--debug-image", help="write a PNG of the grid + nodes/edges")
    args = p.parse_args(argv)

    data_dir = assets.find_data_dir(args.data_dir)
    ase = assets.aseprite_path(data_dir, args.aseprite)
    mask = walk_mask(ase, args.walk_layer)
    res = (
        Resources()
        if args.no_resources
        else load_resources(assets.resources_path(data_dir, args.resources))
    )
    print(
        f"walk layer {ase.name}#{args.walk_layer}: {mask.shape[1]}x{mask.shape[0]}, "
        f"{int(mask.sum())} walkable px; "
        f"{len(res.rooms)} rooms, {len(res.vents)} vents, {len(res.tasks)} tasks",
        file=sys.stderr,
    )
    # Room tags assume non-overlapping room rects (tags_at is first-match-wins). Warn loudly
    # rather than silently mis-tag the overlap by file order if a source edit breaks that.
    for a, b, area in res.overlapping_rooms():
        print(
            f"WARNING: room rects overlap: {a!r} & {b!r} ({area}px^2) -- room tags in the "
            f"overlap depend on file order; fix croatoan.resources so rooms don't overlap",
            file=sys.stderr,
        )

    params = BuildParams(args.grid, args.edge_max, args.node_clear, args.edge_clear)
    seeds = res.vent_seeds() + res.room_seeds(mask) + res.task_seeds(mask)
    nodes, edges = build_graph(mask, params, tagger=res.tags_at, seeds=seeds)
    tasks = res.task_stations()
    vents = res.vent_stations()
    print(
        f"built {len(nodes)} nodes, {len(edges)} edges, {len(tasks)} task stations, "
        f"{len(vents)} vents at grid={args.grid}",
        file=sys.stderr,
    )

    obj = build_interchange(
        mask,
        nodes,
        edges,
        params,
        tasks=tasks,
        vents=vents,
        source=f"aseprite:{ase.name}#layer{args.walk_layer}",
        provenance={"aseprite": str(ase), "rooms": len(res.rooms), "vents": len(res.vents)},
    )
    write_interchange(obj, args.out)
    print(f"wrote interchange -> {args.out}", file=sys.stderr)

    if args.debug_image:
        _write_debug_bmp(mask, nodes, edges, Path(args.debug_image))
        print(f"wrote debug image -> {args.debug_image}", file=sys.stderr)
    return 0


def _write_debug_bmp(mask: np.ndarray, nodes: list[dict], edges: list[dict], path: Path) -> None:
    img = np.where(mask[:, :, None], np.uint8(60), np.uint8(20)) * np.ones((1, 1, 3), np.uint8)
    coords = {n["id"]: (n["x"], n["y"]) for n in nodes}
    for e in edges:  # dim yellow edges
        draw_line(img, *coords[e["src"]], *coords[e["dst"]], (90, 90, 0))
    for n in nodes:  # vents magenta, tasks cyan, others green
        x, y = n["x"], n["y"]
        tags = n["tags"]
        color = (
            (255, 0, 200) if "vent" in tags else (0, 200, 220) if "task" in tags else (0, 220, 0)
        )
        img[max(0, y - 1) : y + 2, max(0, x - 1) : x + 2] = color
    write_png(img, path)


if __name__ == "__main__":
    raise SystemExit(main())
