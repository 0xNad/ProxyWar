"""``swgy-navmesh-sight``: bake engine line-of-sight visibility onto a nav-mesh.

Reads a geometry interchange (from ``swgy-navmesh``) plus the Croatoan aseprite
**wall** (layer 2) and **walk** (layer 1) layers, computes per-node
``exposure``/``witnesses`` under the engine's line-of-sight (see
``swgy_tools.navmesh.visibility``), and writes an enriched interchange. Offline,
Python-only; slots between the geometry build and the canonical compile:

    uv run swgy-navmesh     --out tmp/croatoan.navmesh.json
    uv run swgy-navmesh-sight --in tmp/croatoan.navmesh.json --out tmp/croatoan.vis.json
    uv run python -m swgy_base.nav compile tmp/croatoan.vis.json \\
        assets/croatoan.walk assets/croatoan.graph

Like the geometry builder, this stays independent of ``swgy_base.nav`` -- the
interchange JSON is the boundary.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import base64


from . import assets
from .aseprite import WALK_LAYER, WALL_LAYER, walk_mask
from .interchange import INTERCHANGE_FORMAT
from .visibility import enrich_nodes, visibility_matrix
from .walkgrid import pack_bits


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Bake LOS visibility coefficients onto a nav-mesh interchange."
    )
    p.add_argument(
        "--in",
        dest="in_path",
        default="tmp/croatoan.navmesh.json",
        help="geometry interchange JSON (from swgy-navmesh)",
    )
    p.add_argument("--out", default="tmp/croatoan.vis.json", help="enriched interchange JSON")
    p.add_argument(
        "--data-dir", help="crewrift game data/ dir (default: $CREWRIFT_DATA_DIR, else ./data)"
    )
    p.add_argument("--aseprite", help="path to croatoan.aseprite (overrides --data-dir)")
    p.add_argument(
        "--wall-layer", type=int, default=WALL_LAYER, help="aseprite wall/occluder layer index"
    )
    p.add_argument(
        "--walk-layer", type=int, default=WALK_LAYER, help="aseprite walkability layer index"
    )
    p.add_argument(
        "--workers",
        type=int,
        default=os.cpu_count() or 1,
        help="parallel worker processes (default: CPU count)",
    )
    args = p.parse_args(argv)

    obj = json.loads(Path(args.in_path).read_text())
    if obj.get("format") != INTERCHANGE_FORMAT:
        print(
            f"not a nav interchange: {args.in_path} (format={obj.get('format')!r})", file=sys.stderr
        )
        return 2

    data_dir = assets.find_data_dir(args.data_dir)
    ase = assets.aseprite_path(data_dir, args.aseprite)
    wall = walk_mask(ase, args.wall_layer)
    walk = walk_mask(ase, args.walk_layer)
    if int(wall.sum()) == 0:
        print(
            f"wall layer {ase.name}#{args.wall_layer} is empty -- wrong --wall-layer?",
            file=sys.stderr,
        )
        return 2
    print(
        f"wall layer #{args.wall_layer}: {int(wall.sum())} occluder px; "
        f"walk layer #{args.walk_layer}: {int(walk.sum())} px; "
        f"{len(obj['nodes'])} nodes; {args.workers} worker(s)",
        file=sys.stderr,
    )

    enriched, stats = enrich_nodes(obj["nodes"], wall, walk, workers=args.workers)
    obj["nodes"] = enriched

    # Pairwise sightline matrix [n,n] (engine LOS), packed LSB-first like the
    # walk grid. The surrogate gym needs node->node visibility, not just the
    # per-node exposure/witness scalars enrich_nodes adds.
    coords = [(int(n["x"]), int(n["y"])) for n in enriched]
    vis = visibility_matrix(coords, wall, workers=args.workers)
    obj["vis_shape"] = list(vis.shape)
    obj["vis_bits_b64"] = base64.b64encode(pack_bits(vis)).decode("ascii")

    prov = obj.setdefault("provenance", {})
    prov["visibility"] = {
        "wall_layer": args.wall_layer,
        "aseprite": str(ase),
        "vis_pairs": int(vis.sum()),
        **stats,
    }

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(obj))

    exps = [n["exposure"] for n in enriched]
    wits = [n["witnesses"] for n in enriched]
    print(
        f"baked visibility on {len(enriched)} nodes "
        f"(exposure {min(exps):.3f}..{max(exps):.3f}, "
        f"witnesses {min(wits)}..{max(wits)}) -> {args.out}",
        file=sys.stderr,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
