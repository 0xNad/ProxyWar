"""``swgy-navmesh-viz``: render a generated nav-mesh over the Croatoan map (PNG).

Loads a built mesh -- canonical ``.walk``/``.graph`` or an interchange JSON --
via swgy-base (the format owner) and superimposes its nodes, edges, and task
stations on the actual map art (the visible layer of ``croatoan.aseprite``).
With no game source on hand, it falls back to the walk grid as the backdrop, so
the vendored ``assets/croatoan.{walk,graph}`` render anywhere.

    uv run swgy-navmesh-viz --out tmp/croatoan.nav.png
    uv run swgy-navmesh-viz --mesh-json tmp/croatoan.navmesh.json --scale 2
    uv run swgy-navmesh-viz --no-map --walk-overlay        # no game art needed

Unlike the nav-mesh *builder* (the ``navmesh`` package, kept independent of
``swgy_base.nav`` so the interchange JSON stays the boundary), this is a
*consumer* of the nav model, so it lives outside that package and depends on it.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np

from swgy_base import nav

from . import imaging
from .navmesh import assets
from .navmesh.aseprite import layer_rgba

# Overlay palette, (r, g, b).
_VOID = (18, 22, 34)  # off-map / transparent backdrop
_WALK_TINT = (40, 90, 60)  # optional walkable-area wash
_EDGE = (70, 92, 120)  # ordinary corridor edge
_EDGE_DOOR = (210, 150, 40)  # door edge
_EDGE_VENT = (190, 40, 150)  # vent edge
_NODE = (60, 205, 90)  # ordinary node
_NODE_VENT = (235, 70, 205)  # vent node
_NODE_TASK = (60, 200, 225)  # task-tagged node
_TASK = (255, 140, 30)  # task station marker
_NODE_NOVIS = (120, 120, 120)  # node lacking visibility data (color-by mode)


def _heat_rgb(t: np.ndarray) -> np.ndarray:
    """Map ``t`` in ``[0, 1]`` to an RdYlGn ramp: 0=red (hidden), 1=green (open).

    Accepts a scalar or array; returns ``(..., 3)`` uint8 (exposure -> color).
    """
    t = np.clip(np.asarray(t, dtype=np.float32), 0.0, 1.0)
    r = np.where(t < 0.5, 255.0, 255.0 - 510.0 * (t - 0.5))
    g = np.where(t < 0.5, 510.0 * t, 255.0)
    b = np.zeros_like(t)
    return np.clip(np.stack([r, g, b], axis=-1), 0, 255).astype(np.uint8)


def _exposure_field(mesh: nav.NavMesh, radius: int) -> tuple[np.ndarray, np.ndarray]:
    """Gaussian-splat node ``exposure`` into a smooth ``(H, W)`` field.

    Returns ``(field, covered)``: ``field`` is the weight-normalised exposure and
    ``covered`` marks pixels any node reached. Nodes without exposure are skipped.
    """
    w, h = mesh.bounds
    ax = np.arange(-radius, radius + 1)
    xx, yy = np.meshgrid(ax, ax)
    sigma = max(radius / 2.0, 1.0)
    kernel = np.exp(-(xx**2 + yy**2) / (2.0 * sigma**2)).astype(np.float32)

    val = np.zeros((h, w), np.float32)
    wgt = np.zeros((h, w), np.float32)
    for n in mesh.nodes:
        if n.exposure is None:
            continue
        x0, y0 = n.x - radius, n.y - radius
        kx0, ky0 = max(0, -x0), max(0, -y0)
        ix0, iy0 = max(0, x0), max(0, y0)
        ix1, iy1 = min(w, x0 + kernel.shape[1]), min(h, y0 + kernel.shape[0])
        if ix1 <= ix0 or iy1 <= iy0:
            continue
        k = kernel[ky0 : ky0 + (iy1 - iy0), kx0 : kx0 + (ix1 - ix0)]
        val[iy0:iy1, ix0:ix1] += k * float(n.exposure)
        wgt[iy0:iy1, ix0:ix1] += k

    covered = wgt > 0
    field = np.zeros((h, w), np.float32)
    field[covered] = val[covered] / wgt[covered]
    return field, covered


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Render a nav-mesh superimposed on the Croatoan map as a PNG."
    )
    p.add_argument("--walk", default="assets/croatoan.walk", help="canonical .walk file")
    p.add_argument("--graph", default="assets/croatoan.graph", help="canonical .graph file")
    p.add_argument("--mesh-json", help="interchange JSON (overrides --walk/--graph)")
    p.add_argument("--data-dir", help="crewrift game data/ dir (map art source)")
    p.add_argument("--aseprite", help="path to croatoan.aseprite (overrides --data-dir)")
    p.add_argument("--map-layer", type=int, default=0, help="aseprite visible-layer index")
    p.add_argument("--no-map", action="store_true", help="use the walk grid as the backdrop")
    p.add_argument("--dim", type=float, default=0.5, help="darken the map backdrop, 0..1")
    p.add_argument("--walk-overlay", action="store_true", help="wash walkable pixels green")
    p.add_argument("--no-edges", action="store_true", help="skip drawing edges")
    p.add_argument("--node-radius", type=int, default=2, help="node disc radius, px")
    p.add_argument("--scale", type=int, default=1, help="integer upscale factor")
    p.add_argument(
        "--color-by",
        choices=("type", "visibility"),
        default="type",
        help="node color: by tag type (default) or by exposure (RdYlGn)",
    )
    p.add_argument(
        "--heat",
        action="store_true",
        help="splat node exposure into a smooth heatmap over walkable area",
    )
    p.add_argument("--heat-radius", type=int, default=24, help="exposure splat radius, px")
    p.add_argument("--heat-alpha", type=float, default=0.65, help="heatmap blend strength, 0..1")
    p.add_argument("--out", default="tmp/croatoan.nav.png")
    args = p.parse_args(argv)

    mesh = _load_mesh(args)
    print(
        f"mesh: {len(mesh.nodes)} nodes, {len(mesh.edges)} edges, "
        f"{len(mesh.tasks)} tasks, grid {mesh.bounds[0]}x{mesh.bounds[1]}",
        file=sys.stderr,
    )

    n_vis = sum(1 for n in mesh.nodes if n.exposure is not None)
    if (args.heat or args.color_by == "visibility") and n_vis == 0:
        print(
            "mesh has no visibility data; run swgy-navmesh-sight before --heat/--color-by "
            "visibility (rendering without it)",
            file=sys.stderr,
        )

    img = _backdrop(mesh, args)
    if args.heat and n_vis:
        _apply_heat(img, mesh, args)
    _draw_overlay(img, mesh, args)
    img = imaging.upscale(img, args.scale)
    imaging.write_png(img, Path(args.out))
    print(f"wrote {img.shape[1]}x{img.shape[0]} -> {args.out}", file=sys.stderr)
    return 0


def _load_mesh(args) -> nav.NavMesh:
    if args.mesh_json:
        return nav.mesh_from_interchange(args.mesh_json)
    return nav.load_mesh(args.walk, args.graph)


def _backdrop(mesh: nav.NavMesh, args) -> np.ndarray:
    """The base image: dimmed map art if available, else the walk grid."""
    if not args.no_map:
        try:
            data_dir = assets.find_data_dir(args.data_dir)
            ase = assets.aseprite_path(data_dir, args.aseprite)
            rgba = layer_rgba(ase, args.map_layer)
            opaque = rgba[:, :, 3:4] > 0
            rgb = np.where(opaque, rgba[:, :, :3], np.array(_VOID, np.uint8))
            dim = min(max(args.dim, 0.0), 1.0)
            return np.ascontiguousarray((rgb.astype(np.float32) * (1.0 - dim)).astype(np.uint8))
        except (FileNotFoundError, ValueError) as exc:
            print(f"map art unavailable ({exc}); using walk-grid backdrop", file=sys.stderr)

    mask = mesh.grid.to_mask()
    return np.where(
        mask[:, :, None], np.array((40, 46, 42), np.uint8), np.array(_VOID, np.uint8)
    ).astype(np.uint8)


def _apply_heat(img: np.ndarray, mesh: nav.NavMesh, args) -> None:
    """Blend a smooth exposure heatmap over the walkable area, in place."""
    field, covered = _exposure_field(mesh, args.heat_radius)
    walk = mesh.grid.to_mask()
    sel = covered & walk if walk.shape == covered.shape else covered
    if not sel.any():
        return
    heat = _heat_rgb(field)
    a = min(max(args.heat_alpha, 0.0), 1.0)
    base = img[sel].astype(np.float32)
    img[sel] = (base * (1.0 - a) + heat[sel].astype(np.float32) * a).astype(np.uint8)


def _draw_overlay(img: np.ndarray, mesh: nav.NavMesh, args) -> None:
    if args.walk_overlay:
        mask = mesh.grid.to_mask()
        if mask.shape == img.shape[:2]:
            tint = np.array(_WALK_TINT, np.float32)
            img[mask] = (img[mask].astype(np.float32) * 0.6 + tint * 0.4).astype(np.uint8)
        else:
            print("walk overlay skipped (grid/map size mismatch)", file=sys.stderr)

    coords = {n.id: (n.x, n.y) for n in mesh.nodes}

    if not args.no_edges:
        for e in mesh.edges:
            a, b = coords.get(e.src), coords.get(e.dst)
            if a is None or b is None:
                continue
            color = _EDGE_VENT if "vent" in e.tags else _EDGE_DOOR if "door" in e.tags else _EDGE
            imaging.draw_line(img, a[0], a[1], b[0], b[1], color)

    r = args.node_radius
    for n in mesh.nodes:
        if args.color_by == "visibility":
            color = (
                _NODE_NOVIS if n.exposure is None else tuple(int(c) for c in _heat_rgb(n.exposure))
            )
        else:
            color = _NODE_VENT if "vent" in n.tags else _NODE_TASK if "task" in n.tags else _NODE
        imaging.draw_disc(img, n.x, n.y, r, color)

    for t in mesh.tasks:  # task stations: a bright ring + center, drawn on top
        imaging.draw_ring(img, t.x, t.y, r + 3, _TASK, width=2)
        imaging.draw_disc(img, t.x, t.y, 1, _TASK)


if __name__ == "__main__":
    raise SystemExit(main())
