"""Whole-game trajectory, coloured by how exposed you were -- and how you recovered.

The arrow encoding used by the kill cam is right for a 30-second window and wrong for a
whole game: at one arrow per half-second a game needs ~541 of them. So a whole-game view
drops arrows entirely and draws a **line coloured by how many other players could see
you at that tick** (from ``visibility.csv``, the engine's own raycast).

That is the question that actually matters for a crew policy. Task completion turns out
not to be the differentiator -- routing is near-optimal, ordering is near-optimal, and
crew who are *murdered* finish MORE of their list (84%) than crew who survive (77%),
because a ghost keeps working and cannot be interrupted. What kills a crew policy's
score is losing the game, and what loses the game is being alone with an imposter.

Blue = nobody can see you (alone: free to work, free to be murdered).
Amber = several people can see you (safe, and useless to an imposter).
"""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from matplotlib.collections import LineCollection  # noqa: E402
from matplotlib.colors import LinearSegmentedColormap, Normalize  # noqa: E402

from ..plotstyle import (  # noqa: E402
    ALIVE,
    DEATH,
    GHOST,
    INK,
    MEETING,
    MUTED,
    PAGE,
    SECONDARY,
    croatoan_axes,
)

# A one-hue-to-one-hue ramp between two already-validated categorical steps: alone
# (blue) -> watched (amber). Sequential, so it reads as a magnitude, and it introduces
# no new hue into the package's palette.
SEEN_CMAP = LinearSegmentedColormap.from_list("seen", [ALIVE, MEETING])


def viewers_per_tick(sightings: list[dict], slot: int, ticks: np.ndarray) -> np.ndarray:
    """How many *other* players had line of sight to ``slot`` at each tick."""
    counts = np.zeros(len(ticks), dtype=np.int16)
    for s in sightings:
        if s["target_slot"] != slot or s["target_kind"] != "player":
            continue
        if s["observer_slot"] == slot:
            continue
        counts += ((ticks >= s["tick_start"]) & (ticks <= s["tick_end"])).astype(np.int16)
    return counts


def plot_ribbon(
    ax,
    positions: dict[str, np.ndarray],
    sightings: list[dict],
    slot: int,
    *,
    death_tick: int | None = None,
    ghost: bool = False,
    map_w: int = 1235,
    map_h: int = 659,
):
    """Draw one player's game as a line coloured by how many players could see them.

    Only the **living** trajectory is coloured that way, and by default it is the only
    one drawn. A ghost is a different animal: it walks **through walls** (so its path
    cuts straight across solid geometry, which looks like a rendering bug and is not),
    and nobody can see it, so "how exposed was I" is a meaningless question once you
    are dead. ``ghost=True`` draws it, dashed and in the ghost hue, clearly apart.
    """
    sel = positions["slot"] == slot
    t = positions["tick"][sel]
    x, y = positions["x"][sel], positions["y"][sel]
    alive = positions["alive"][sel].astype(bool)
    order = np.argsort(t)
    t, x, y, alive = t[order], x[order], y[order], alive[order]
    if len(t) < 2:
        return ax

    seen = viewers_per_tick(sightings, slot, t)
    stride = int(np.diff(np.unique(t)).min()) if len(np.unique(t)) > 1 else 1

    croatoan_axes(ax, map_w, map_h)
    ax.set_xticks([])
    ax.set_yticks([])
    for s in ax.spines.values():
        s.set_visible(False)

    pts = np.column_stack([x, y]).reshape(-1, 1, 2)
    segs = np.concatenate([pts[:-1], pts[1:]], axis=1)
    # A meeting is a hole in the tick series (teleport to the Bridge). Never draw a line
    # across it -- nobody walked that.
    contiguous = np.diff(t) <= max(1, stride)
    both_alive = alive[:-1] & alive[1:]
    both_dead = ~alive[:-1] & ~alive[1:]

    live_seg = contiguous & both_alive
    lc = LineCollection(
        segs[live_seg],
        cmap=SEEN_CMAP,
        norm=Normalize(0, max(3, int(seen[alive].max(initial=0)))),
        lw=1.7,
        alpha=0.9,
        zorder=4,
    )
    lc.set_array(seen[:-1][live_seg])
    ax.add_collection(lc)

    if ghost and both_dead.any():
        ax.add_collection(
            LineCollection(
                segs[contiguous & both_dead],
                colors=GHOST,
                lw=1.0,
                alpha=0.5,
                linestyles="dashed",
                zorder=3,
            )
        )

    ax.scatter(
        [x[0]],
        [y[0]],
        marker="o",
        s=110,
        facecolors="none",
        edgecolors=SECONDARY,
        linewidths=1.6,
        zorder=6,
    )
    if death_tick is not None and death_tick >= 0:
        i = int(np.searchsorted(t, death_tick))
        if i < len(t):
            ax.scatter([x[i]], [y[i]], marker="x", c=DEATH, s=150, linewidths=2.8, zorder=8)
    return ax, lc, seen[alive]  # exposure stats are about the LIVING trajectory only


def render_ribbon(
    positions,
    sightings,
    slot: int,
    policy: str,
    episode_id: str,
    out: str | Path,
    *,
    death_tick: int | None = None,
    ghost: bool = False,
    dpi: int = 150,
) -> Path:
    """Own a figure, draw the ribbon, write a PNG."""
    fig, ax = plt.subplots(figsize=(13, 7.6), facecolor=PAGE)
    res = plot_ribbon(ax, positions, sightings, slot, death_tick=death_tick, ghost=ghost)
    if not isinstance(res, tuple):
        raise ValueError(f"no positions for slot {slot} in {episode_id}")
    ax, lc, seen = res

    # `seen` is the LIVING trajectory only: nobody can see a ghost, so counting its ticks
    # as "alone" would inflate the number with time that carries no risk at all.
    alone = float((seen == 0).mean()) if len(seen) else 0.0
    murdered = death_tick is not None and death_tick >= 0
    ax.set_title(
        f"{policy}  ·  {episode_id[:8]}  ·  alone {100 * alone:.0f}% of the time ALIVE"
        + ("  ·  murdered" if murdered else "  ·  survived"),
        color=INK,
        fontsize=12,
        loc="left",
        pad=10,
    )
    if ghost and murdered:
        ax.plot(
            [],
            [],
            color=GHOST,
            ls="dashed",
            lw=1.2,
            label="as a ghost (walks through walls; nobody can see it)",
        )
        ax.legend(loc="lower right", frameon=False, fontsize=8, labelcolor=SECONDARY)
    cb = fig.colorbar(lc, ax=ax, fraction=0.028, pad=0.012)
    cb.set_label("other players who could see you", color=SECONDARY, fontsize=8)
    cb.ax.tick_params(colors=MUTED, labelsize=7)
    cb.outline.set_visible(False)

    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out, dpi=dpi, facecolor=PAGE, bbox_inches="tight", pad_inches=0.12)
    plt.close(fig)
    return out
