"""``swgy-route``: what a crew policy's movement is actually costing it.

Reads a ``swgy-spatial`` build (made from ``expand_replay --snapshot-every 1``).

    swgy-route legs   <build>            # per-leg detour + ticks lost vs a perfect follower
    swgy-route tour   <build>            # the order it did its tasks vs the optimal order
    swgy-route ribbon <build> --episode E --slot N   # a whole game, coloured by who could see you

What this found on the league corpus, and it is worth knowing before you tune anything:
routing is already near-optimal (a median leg loses ~4 ticks to a perfect follower) and so
is task *ordering* (median 1.00x the optimal tour). The whole 8-task workload is ~1,240
ticks of a ~6,000-tick game; meetings eat ~4,000. And crew who are murdered finish MORE of
their list (84%) than crew who survive (77%), because a ghost keeps working. Crew task
optimisation is a solved problem. The score is decided by surviving and by voting.
"""

from __future__ import annotations

import argparse
import csv
import statistics as st
import sys
from pathlib import Path

from swgy_base.nav import load_default_mesh

from ..spatial.build import (
    load_assignments,
    load_episode_positions,
    load_kills,
    load_meetings,
    load_sightings,
    load_tasks,
)
from .legs import extract_legs
from .tour import tours

LEG_COLS = [
    "episode_id",
    "slot",
    "policy",
    "from_task",
    "to_task",
    "room",
    "actual_px",
    "mesh_px",
    "detour",
    "actual_ticks",
    "oracle_ticks",
    "ticks_lost",
    "vent_hops",
]
TOUR_COLS = [
    "episode_id",
    "slot",
    "policy",
    "n_stations",
    "actual_cost",
    "optimal_cost",
    "excess_px",
    "ratio",
    "visited",
    "optimal",
]


def _episodes(data_dir: str, limit: int | None) -> list[str]:
    eps = sorted({r["episode_id"] for r in load_tasks(data_dir)})
    return eps[:limit] if limit else eps


def _cmd_legs(args) -> int:
    mesh = load_default_mesh()
    task_xy = {t.id: (t.x, t.y) for t in mesh.tasks}
    legs = []
    for ep in _episodes(args.data_dir, args.limit):
        legs += extract_legs(
            mesh,
            ep,
            load_episode_positions(args.data_dir, ep),
            load_tasks(args.data_dir, ep),
            load_meetings(args.data_dir, ep),
            task_xy,
        )
    if not legs:
        raise SystemExit("no uninterrupted task-to-task legs found in this build.")

    if args.out:
        with Path(args.out).open("w") as fh:
            w = csv.DictWriter(fh, fieldnames=LEG_COLS)
            w.writeheader()
            for x in legs:
                w.writerow(
                    {
                        "episode_id": x.episode_id,
                        "slot": x.slot,
                        "policy": x.policy,
                        "from_task": x.from_task,
                        "to_task": x.to_task,
                        "room": x.room,
                        "actual_px": round(x.actual_px, 1),
                        "mesh_px": round(x.mesh_px, 1),
                        "detour": round(x.detour, 3),
                        "actual_ticks": x.actual_ticks,
                        "oracle_ticks": x.oracle_ticks,
                        "ticks_lost": x.ticks_lost,
                        "vent_hops": x.vent_hops,
                    }
                )
        print(f"wrote {len(legs)} legs -> {args.out}", file=sys.stderr)

    lost = [x.ticks_lost for x in legs if x.ticks_lost is not None]
    print(f"{len(legs)} crew legs\n")
    print("  ticks lost vs a PERFECT FOLLOWER (same mesh, same physics, standing start):")
    print(f"    median {st.median(lost):.0f}   mean {st.mean(lost):.0f}   total {sum(lost):,}")
    print(f"  detour vs the mesh path: median {st.median([x.detour for x in legs]):.2f}")
    print("    (a mesh path is a polyline through grid nodes; a player cuts the corners,")
    print("     so a ratio just under 1.0 is honest -- not a teleport)")
    vents = sum(x.vent_hops for x in legs)
    print(f"  vent hops on crew legs: {vents}   (must be 0 -- crew cannot vent)")
    return 0


def _cmd_tour(args) -> int:
    mesh = load_default_mesh()
    task_xy = {t.id: (t.x, t.y) for t in mesh.tasks}
    eps = set(_episodes(args.data_dir, args.limit))
    rows = [r for r in load_tasks(args.data_dir) if r["episode_id"] in eps]
    ts = tours(mesh, rows, task_xy)
    if not ts:
        raise SystemExit("no crew completed enough stations to have an order worth scoring.")

    if args.out:
        with Path(args.out).open("w") as fh:
            w = csv.DictWriter(fh, fieldnames=TOUR_COLS)
            w.writeheader()
            for t in ts:
                w.writerow(
                    {
                        "episode_id": t.episode_id,
                        "slot": t.slot,
                        "policy": t.policy,
                        "n_stations": len(t.visited),
                        "actual_cost": round(t.actual_cost, 1),
                        "optimal_cost": round(t.optimal_cost, 1),
                        "excess_px": round(t.excess, 1),
                        "ratio": round(t.ratio, 3),
                        "visited": " ".join(map(str, t.visited)),
                        "optimal": " ".join(map(str, t.optimal)),
                    }
                )
        print(f"wrote {len(ts)} tours -> {args.out}", file=sys.stderr)

    r = [t.ratio for t in ts]
    print(f"{len(ts)} crew tours\n")
    print(
        f"  actual / optimal walking distance: median {st.median(r):.2f}x   "
        f"p90 {sorted(r)[int(0.9 * len(r))]:.2f}x"
    )
    print(f"  excess px purely from task ORDER: median {st.median([t.excess for t in ts]):.0f}")
    bad = [t for t in ts if t.optimal_cost > t.actual_cost + 1e-6]
    print(f"  invariant (optimal <= actual): {len(bad)} violations")
    return 0


def _cmd_ribbon(args) -> int:
    from .ribbon import render_ribbon

    ep = args.episode
    if not ep:
        raise SystemExit("--episode is required for `ribbon` (it draws one game).")
    pos = load_episode_positions(args.data_dir, ep)
    sights = load_sightings(args.data_dir, ep)
    assigns = {r["slot"]: r["policy"] for r in load_assignments(args.data_dir, ep)}
    deaths = {k["victim_slot"]: k["tick"] for k in load_kills(args.data_dir, ep)}

    slot = args.slot if args.slot is not None else next(iter(sorted(assigns)), 0)
    out = render_ribbon(
        pos,
        sights,
        slot,
        assigns.get(slot, f"slot {slot}"),
        ep,
        args.out or "tmp/ribbon.png",
        death_tick=deaths.get(slot),
        ghost=args.ghost,
        dpi=args.dpi,
    )
    print(f"slot {slot} ({assigns.get(slot, '?')}) -> {out}", file=sys.stderr)
    return 0


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="swgy-route", description=__doc__.splitlines()[0])
    sub = p.add_subparsers(dest="cmd", required=True)

    for name, fn, helptext in (
        ("legs", _cmd_legs, "per-leg detour + ticks lost against a perfect follower"),
        ("tour", _cmd_tour, "the task order it chose vs the exactly-optimal order"),
        ("ribbon", _cmd_ribbon, "one whole game, coloured by how many players could see you"),
    ):
        s = sub.add_parser(name, help=helptext)
        s.add_argument("data_dir", help="a swgy-spatial build (the dir holding spatial/)")
        s.add_argument("-o", "--out", help="output CSV (legs/tour) or PNG (ribbon)")
        s.add_argument("--limit", type=int, help="only the first N episodes")
        s.add_argument("--episode", help="episode id (ribbon)")
        s.add_argument("--slot", type=int, help="crew slot (ribbon)")
        s.add_argument("--dpi", type=int, default=150, help="output resolution (ribbon)")
        s.add_argument(
            "--ghost",
            action="store_true",
            help="also draw the trajectory after death (ribbon). A ghost walks THROUGH "
            "WALLS, so its path cuts across solid geometry -- it is drawn dashed and apart, "
            "and it is excluded from the exposure stats because nobody can see a ghost.",
        )
        s.set_defaults(func=fn)

    args = p.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
