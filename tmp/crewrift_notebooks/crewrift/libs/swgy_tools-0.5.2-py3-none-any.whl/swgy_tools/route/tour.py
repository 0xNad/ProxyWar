"""Task order: what the policy did, versus the optimal tour of the same stations.

A crew member is handed 8 stations and chooses the order to visit them in. The leg
autopsy (:mod:`.legs`) shows the *walking* is already near-optimal -- a median leg
loses ~4 ticks against a perfect follower. So the waste, if there is any, is in the
**choice of which task next**.

With 8 stations that question is exactly solvable. Held-Karp over the pairwise mesh
distances is 2^8 x 8 x 8 ~= 16k operations: there is no excuse for approximating it,
and no excuse for a policy shipping a greedy tour without knowing what it cost.

The comparison is deliberately generous to the policy:

* the optimal tour is an **open** path (start at spawn, end anywhere) -- we do not make
  it return home, because the policy doesn't have to either;
* it is scored over only the stations the policy **actually completed**, so a policy is
  never punished for tasks it never got to; and
* distances are ``NavPlan.cost`` on the same mesh the policy itself would route on.

If it still loses, it lost on ordering.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache

from swgy_base.nav import NavMesh, NavParams, find_path

SPAWN_XY = (137, 342)  # Bridge home: where everyone starts, and where a meeting puts them back


@dataclass
class Tour:
    """One crew member's actual task order against the optimal one."""

    episode_id: str
    slot: int
    policy: str
    visited: list[int]  # stations, in the order the policy actually completed them
    optimal: list[int]  # the same stations, in the cheapest order
    actual_cost: float  # px, walking the policy's order from spawn
    optimal_cost: float  # px, walking the optimal order from spawn

    @property
    def excess(self) -> float:
        """Extra pixels walked purely because of the ORDER. Cannot be negative."""
        return self.actual_cost - self.optimal_cost

    @property
    def ratio(self) -> float:
        return self.actual_cost / self.optimal_cost if self.optimal_cost > 0 else float("nan")


PairCache = dict[tuple[tuple[int, int], tuple[int, int]], float]


def _pairwise(
    mesh: NavMesh, points: list[tuple[int, int]], cache: PairCache | None = None
) -> list[list[float]]:
    """Mesh path cost between every pair of points (symmetric enough to treat as such).

    ``cache`` shares costs *across* calls: every crew member in a build draws from the
    same ~28 stations + spawn, so a corpus run repeats the same few hundred pairs
    thousands of times. One shared dict turns an O(tours) A* bill into O(pairs).
    """
    n = len(points)
    d = [[0.0] * n for _ in range(n)]
    for i in range(n):
        for j in range(i + 1, n):
            key = (min(points[i], points[j]), max(points[i], points[j]))
            cost = cache.get(key) if cache is not None else None
            if cost is None:
                plan = find_path(mesh, points[i], points[j], NavParams())
                cost = float(plan.cost) if plan else float("inf")
                if cache is not None:
                    cache[key] = cost
            d[i][j] = d[j][i] = cost
    return d


def optimal_order(dist: list[list[float]]) -> tuple[list[int], float]:
    """Held-Karp: the cheapest OPEN path from node 0 through every other node.

    Node 0 is the start (spawn). Exact, not greedy -- with <= ~12 stations the exact
    answer is cheap, and an approximate baseline would make the whole comparison
    arguable.
    """
    n = len(dist)
    if n <= 1:
        return [], 0.0
    targets = list(range(1, n))
    m = len(targets)
    INF = float("inf")

    # best[mask][j] = cost of starting at 0, visiting `mask`, ending at targets[j]
    best = [[INF] * m for _ in range(1 << m)]
    prev = [[-1] * m for _ in range(1 << m)]
    for j in range(m):
        best[1 << j][j] = dist[0][targets[j]]

    for mask in range(1 << m):
        for j in range(m):
            if not mask & (1 << j) or best[mask][j] == INF:
                continue
            base = best[mask][j]
            for k in range(m):
                if mask & (1 << k):
                    continue
                nxt = mask | (1 << k)
                cost = base + dist[targets[j]][targets[k]]
                if cost < best[nxt][k]:
                    best[nxt][k] = cost
                    prev[nxt][k] = j

    full = (1 << m) - 1
    end = min(range(m), key=lambda j: best[full][j])
    total = best[full][end]

    order, mask, j = [], full, end
    while j >= 0:
        order.append(targets[j])
        pj = prev[mask][j]
        mask ^= 1 << j
        j = pj
    order.reverse()
    return order, total


def _path_cost(dist: list[list[float]], order: list[int]) -> float:
    """Cost of walking 0 -> order[0] -> order[1] -> ... on the pairwise matrix."""
    total, cur = 0.0, 0
    for nxt in order:
        total += dist[cur][nxt]
        cur = nxt
    return total


def tour_for(
    mesh: NavMesh,
    episode_id: str,
    slot: int,
    policy: str,
    visited: list[int],
    task_xy: dict[int, tuple[int, int]],
    spawn: tuple[int, int] = SPAWN_XY,
    *,
    cache: PairCache | None = None,
) -> Tour | None:
    """Score one crew member's completion order against the optimal order."""
    stations = [t for t in visited if t in task_xy]
    if len(stations) < 3:  # nothing to reorder
        return None

    points = [spawn] + [task_xy[t] for t in stations]
    dist = _pairwise(mesh, points, cache)
    if any(dist[i][j] == float("inf") for i in range(len(points)) for j in range(len(points))):
        return None

    actual_idx = list(range(1, len(points)))  # visited is already in completion order
    opt_idx, opt_cost = optimal_order(dist)
    return Tour(
        episode_id=episode_id,
        slot=slot,
        policy=policy,
        visited=stations,
        optimal=[stations[i - 1] for i in opt_idx],
        actual_cost=_path_cost(dist, actual_idx),
        optimal_cost=opt_cost,
    )


@lru_cache(maxsize=1)
def _mesh_task_xy(mesh: NavMesh) -> dict[int, tuple[int, int]]:
    return {t.id: (t.x, t.y) for t in mesh.tasks}


def tours(mesh: NavMesh, tasks: list[dict], task_xy: dict[int, tuple[int, int]]) -> list[Tour]:
    """Score every crew member in a build's ``tasks.csv``."""
    by: dict[tuple[str, int], list[dict]] = {}
    for row in sorted(tasks, key=lambda r: r["tick"]):
        by.setdefault((row["episode_id"], row["slot"]), []).append(row)

    out = []
    cache: PairCache = {}
    for (ep, slot), rows in by.items():
        t = tour_for(
            mesh, ep, slot, rows[0]["policy"], [r["task"] for r in rows], task_xy, cache=cache
        )
        if t is not None:
            out.append(t)
    return out
