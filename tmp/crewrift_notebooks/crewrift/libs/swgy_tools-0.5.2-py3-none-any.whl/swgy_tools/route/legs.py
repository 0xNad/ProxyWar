"""Task-leg autopsy: how far off optimal is a crew policy's route between tasks?

A **leg** is one crew member going from completing task *N* to completing task *N+1*.
It is the right unit: the median leg is 144 ticks, of which 72 are the completion
*hold*, so about three seconds of actual walking. (A whole game is ~6,500 ticks --
which is why whole-game arrow plots explode and leg plots do not.)

The honest baseline is the **engine oracle**: ticks a perfect follower needs, from
:mod:`swgy_tools.navbench` -- a byte-faithful port of the engine's acceleration,
friction and wall-sliding, walking the same mesh from the same standing start. So
"you took 144 ticks; a perfect follower takes 96" is a real statement about *decision
quality*, with the physics held constant.

**The A\\* path length is NOT a lower bound, and must not be used as one.** The mesh
path is a polyline through grid nodes; a player moving continuously cuts the corners
between them, so the true walkable geodesic is *shorter* than ``plan.cost``. Measured
over real crew legs the ratio has a median of 0.97 -- under 1.0 and entirely honest.
Treating a sub-1.0 ratio as "impossible, therefore a teleport" produced 44 phantom
vent detections among crew, who cannot vent at all. Vents are detected from
``vent_cooldown`` instead, which is the only real signal (the event stream has no vent
event), and crew legs correctly show zero.

Legs a meeting falls inside are excluded: a meeting teleports everyone to the Bridge,
so that is not a walk, and measuring it as one would be a lie.

**What this found:** the median crew leg loses only ~4 ticks against a perfect
follower (~6% of its travel time). Per-leg *pathing* is already near-optimal, so the
waste is not here -- it is in which task the policy picks next. See :mod:`.tour`.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from swgy_base.nav import NavMesh, NavParams, find_path

from ..navbench.bench import drive_leg
from ..navbench.enginesim import Engine, Player


@dataclass
class Leg:
    """One crew member's walk from one completed station to the next."""

    episode_id: str
    slot: int
    policy: str
    from_task: int
    to_task: int
    room: str  # the room the leg ENDED in
    start_tick: int
    arrive_tick: int  # when the hold began -- travel ends here, not at the completion
    end_tick: int  # the completion itself
    actual_px: float
    mesh_px: float  # length of the A* path THROUGH THE MESH GRAPH -- see .detour
    actual_ticks: int
    oracle_ticks: int | None  # None if the oracle could not drive it
    vent_hops: int  # vent_cooldown resets during the leg; crew should always be 0

    @property
    def detour(self) -> float:
        """actual px / the A* path length **through the mesh graph**.

        Read this carefully: the mesh path is a polyline through grid nodes, and a
        player moving continuously cuts the corners between them. So the mesh length
        is an *upper* bound on the true walkable geodesic, and a ratio a little under
        1.0 is ordinary corner-cutting, **not** a teleport. (Measured: median 0.99 over
        real crew legs.) Use it to spot the *big* detours -- 1.3+ is a policy that went
        the wrong way -- and use :attr:`ticks_lost` for the honest efficiency number.
        """
        return self.actual_px / self.mesh_px if self.mesh_px > 0 else float("nan")

    @property
    def ticks_lost(self) -> int | None:
        """Ticks spent beyond what a perfect follower needed. **The headline metric.**

        This one is apples-to-apples: the oracle walks the same mesh with the same
        engine physics from the same standing start, so the difference is decision
        quality rather than discretisation.
        """
        return None if self.oracle_ticks is None else self.actual_ticks - self.oracle_ticks


def oracle_ticks(
    mesh: NavMesh, start: tuple[int, int], goal_node: int, params: NavParams | None = None
) -> int | None:
    """Ticks a *perfect follower* needs to walk from ``start`` to ``goal_node``.

    Delegates to :func:`swgy_tools.navbench.bench.drive_leg`, which drives the
    engine-faithful movement sim (acceleration, friction, wall-sliding, replan-on-stuck)
    along the A* plan. So the gap between this and what a real policy took is decision
    quality, not physics.
    """
    return drive_leg(
        Engine(mesh.grid), Player(x=start[0], y=start[1]), mesh, goal_node, params or NavParams()
    )


def extract_legs(
    mesh: NavMesh,
    episode_id: str,
    positions: dict[str, np.ndarray],
    tasks: list[dict],
    meetings: list[dict],
    task_xy: dict[int, tuple[int, int]],
    *,
    with_oracle: bool = True,
) -> list[Leg]:
    """Every uninterrupted task-to-task leg in one episode."""
    by_slot: dict[int, list[dict]] = {}
    for t in sorted(tasks, key=lambda r: r["tick"]):
        by_slot.setdefault(t["slot"], []).append(t)

    tick, slot, x, y, act, vcd = (
        positions["tick"],
        positions["slot"],
        positions["x"],
        positions["y"],
        positions["active_task"],
        positions["vent_cooldown"],
    )
    out: list[Leg] = []
    for s, done in by_slot.items():
        sel = slot == s
        st, sx, sy, sa, sv = tick[sel], x[sel], y[sel], act[sel], vcd[sel]
        order = np.argsort(st)
        st, sx, sy, sa, sv = st[order], sx[order], sy[order], sa[order], sv[order]

        for a, b in zip(done, done[1:], strict=False):
            t0, t1 = int(a["tick"]), int(b["tick"])
            # A meeting inside the leg means a teleport to the Bridge: not a walk.
            if any(m["start"] < t1 and m["end"] > t0 for m in meetings):
                continue
            span = (st > t0) & (st <= t1)
            if span.sum() < 3:
                continue
            wx, wy, wa, wt, wv = sx[span], sy[span], sa[span], st[span], sv[span]

            # Travel ends when the station latches on: the 72-tick hold is not walking.
            engaged = np.flatnonzero(wa == b["task"])
            stop = int(engaged[0]) if len(engaged) else len(wx) - 1
            if stop < 2:
                continue
            px = float(
                np.sum(
                    np.hypot(
                        np.diff(wx[: stop + 1]).astype(float), np.diff(wy[: stop + 1]).astype(float)
                    )
                )
            )
            arrive = int(wt[stop])
            # The event stream has no vent event at all. A vent_cooldown that JUMPS UP
            # is the engine arming the cooldown, i.e. a hop just happened. Crew cannot
            # vent, so a non-zero count on a crew leg means the leg is not a walk.
            hops = int(np.sum(np.diff(wv[: stop + 1].astype(np.int32)) > 0))

            start_xy = (int(wx[0]), int(wy[0]))
            goal_xy = task_xy.get(b["task"])
            if goal_xy is None:
                continue
            plan = find_path(mesh, start_xy, goal_xy, NavParams())
            if plan is None or plan.cost <= 0:
                continue
            goal_node = mesh.nearest_node(*goal_xy)

            out.append(
                Leg(
                    episode_id=episode_id,
                    slot=s,
                    policy=a["policy"],
                    from_task=int(a["task"]),
                    to_task=int(b["task"]),
                    room=b["room"],
                    start_tick=t0,
                    arrive_tick=arrive,
                    end_tick=t1,
                    actual_px=px,
                    mesh_px=float(plan.cost),
                    actual_ticks=arrive - t0,
                    vent_hops=hops,
                    oracle_ticks=(
                        oracle_ticks(mesh, start_xy, goal_node)
                        if with_oracle and goal_node is not None
                        else None
                    ),
                )
            )
    return out
