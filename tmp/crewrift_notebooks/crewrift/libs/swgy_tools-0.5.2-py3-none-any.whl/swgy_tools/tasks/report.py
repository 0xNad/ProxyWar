"""Render an :class:`EpisodeTasks` as text, CSV rows, or JSON.

Text is for reading one episode. CSV is the long format for the corpus: one row
per (episode, crew slot, *assigned* task) -- so tasks that were never completed
are rows too, which is what makes "which tasks never get done?" answerable.
"""

from __future__ import annotations

import dataclasses
import json

from .eventlog import CrewTasks, EpisodeTasks

CSV_COLUMNS = [
    "episode_id",
    "slot",
    "name",
    "task",
    "task_name",
    "room",
    "completed",
    "order",
    "tick",
    "while_dead",
    "assigned_n",
    "completed_n",
    "starts",
    "death_tick",
    "end_tick",
    "outcome",
]


def csv_rows(ep: EpisodeTasks) -> list[dict]:
    """One row per (crew slot, assigned task); ``order``/``tick`` blank if never done."""
    rows: list[dict] = []
    for member in ep.crew:
        done = {c.task: (i + 1, c) for i, c in enumerate(member.completions)}
        for task in member.assigned:
            order, c = done.get(task, (None, None))
            rows.append(
                {
                    "episode_id": ep.episode_id,
                    "slot": member.slot,
                    "name": member.name,
                    "task": task,
                    "task_name": ep.task_names.get(task, ""),
                    "room": ep.task_rooms.get(task, ""),
                    "completed": int(c is not None),
                    "order": order if order else "",
                    "tick": c.tick if c else "",
                    "while_dead": int(c.while_dead) if c else "",
                    "assigned_n": len(member.assigned),
                    "completed_n": len(member.completions),
                    "starts": member.starts,
                    "death_tick": member.death_tick,
                    "end_tick": ep.end_tick,
                    "outcome": ep.outcome,
                }
            )
    return rows


def json_line(ep: EpisodeTasks) -> str:
    """The whole episode as one JSON object (JSONL for a corpus)."""
    return json.dumps(dataclasses.asdict(ep), separators=(",", ":"))


def _crew_block(ep: EpisodeTasks, member: CrewTasks) -> list[str]:
    n_done, n_assigned = len(member.completions), len(member.assigned)
    died = f"died {member.death_tick}" if member.death_tick >= 0 else "survived"
    abandoned = member.starts - n_done
    out = [f"  slot {member.slot}  {member.name:<20} {n_done}/{n_assigned}  {died}"]
    out.append(f"    assigned  {' '.join(str(t) for t in member.assigned)}")
    for i, c in enumerate(member.completions, start=1):
        ghost = " (while dead)" if c.while_dead else ""
        out.append(f"    {i}. task {c.task:>2}  {c.room:<14} tick {c.tick:>5}{ghost}")
    if member.unfinished:
        never = ", ".join(f"{t} {ep.task_rooms.get(t, '?')}" for t in member.unfinished)
        out.append(f"    never     {never}")
    if abandoned > 0:
        out.append(f"    abandoned {abandoned} started task(s) without finishing")
    return out


def text_report(ep: EpisodeTasks) -> str:
    """The human-readable per-episode report."""
    total_assigned = sum(len(m.assigned) for m in ep.crew)
    total_done = sum(len(m.completions) for m in ep.crew)
    ghosts = sum(1 for m in ep.crew for c in m.completions if c.while_dead)
    pct = (100 * total_done / total_assigned) if total_assigned else 0.0

    head = [
        f"episode {ep.episode_id}   {ep.end_tick} ticks   outcome {ep.outcome}   "
        f"hash {'ok' if ep.hash_ok else f'FAILED at {ep.fail_tick}'}",
        f"crew {len(ep.crew)} ({ep.imposter_count} imposters)   "
        f"tasks {total_done}/{total_assigned} ({pct:.0f}%)"
        + (f"   {ghosts} completed while dead" if ghosts else ""),
        "",
    ]
    body: list[str] = []
    for member in ep.crew:
        body += _crew_block(ep, member)
        body.append("")
    return "\n".join(head + body).rstrip() + "\n"
