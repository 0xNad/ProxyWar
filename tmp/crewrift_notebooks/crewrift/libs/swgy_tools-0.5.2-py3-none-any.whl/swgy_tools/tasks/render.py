"""Render a crew policy's task order over a Croatoan reference map (matplotlib).

Two stacked panels, answering two different questions:

* **Swimlanes** (top) -- one row per game, a marker per task completion placed at the
  tick it happened and labelled with the **task-station number**. Read a lane left to
  right and you have the order; the *gaps* are how long the policy spent between
  tasks. A cross marks the kill and the lane is washed from there on, so work done
  as a ghost is unmistakable.
* **The reference map** (bottom) -- the Croatoan basemap with all task stations
  numbered, so any number in a lane can be looked up. Stations are deliberately
  **not** connected: the crew walks a navmesh, and a straight line between stations
  would draw a path that never happened.

Styled after ``cr-analysis``: dark frame, desaturated basemap, dpi 200.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")  # headless: render to file, never to a window

import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402
from matplotlib.patches import Patch  # noqa: E402

from ..plotstyle import (  # noqa: E402
    ALIVE,
    DEATH,
    GHOST,
    GRID,
    INK,
    MEETING,
    MUTED,
    PAGE,
    SECONDARY,
    SURFACE,
    croatoan_axes,
)
from .eventlog import CrewTasks, EpisodeTasks  # noqa: E402


def _style(ax) -> None:
    ax.set_facecolor(SURFACE)
    for s in ax.spines.values():
        s.set_visible(False)
    ax.tick_params(colors=MUTED, labelsize=8, length=0)


def _lanes(ax, runs: list[tuple[EpisodeTasks, CrewTasks]]) -> None:
    _style(ax)
    n = len(runs)
    # Scale the axis to the last thing that HAPPENS, not to the longest game. One
    # game running to tick 15k while every task lands before 7.5k would squash the
    # whole plot into its left third. Lanes that outlive the axis get a caret, so
    # the crop never reads as "the game ended here".
    last_event = max(
        [c.tick for _, me in runs for c in me.completions]
        + [me.death_tick for _, me in runs]
        + [mt.end for ep, _ in runs for mt in ep.meetings]
        + [0]
    )
    max_tick = max(ep.end_tick for ep, _ in runs)
    x_max = min(max_tick, last_event * 1.05 + 1)
    truncated = 0

    # A burst of quick tasks would stack markers on top of each other and turn the
    # station numbers to mush, so a crowded marker lifts onto the next free row and
    # keeps a stem down to the lane. Its x -- the tick -- is still exact.
    min_sep = x_max * 0.019
    rows = (0.0, 0.30, -0.30)

    for i, (ep, me) in enumerate(runs):
        y = n - 1 - i  # first game at the top

        # the game's span, and the stretch of it spent dead
        end = min(ep.end_tick, x_max)
        ax.hlines(y, 0, end, color=GRID, lw=3, zorder=1, capstyle="round")
        if ep.end_tick > x_max:
            truncated += 1
            ax.plot(x_max, y, marker=5, ms=6, color=MUTED, zorder=5)  # caret: runs on
        if me.death_tick >= 0:
            ax.hlines(y, me.death_tick, end, color=DEATH, lw=3, alpha=0.22, zorder=2)
            ax.plot(me.death_tick, y, marker="x", ms=8, mew=2.2, color=DEATH, zorder=6)

        # A meeting is a SPAN, not an instant: everyone is teleported to the Bridge at
        # the call and no task can be touched until play resumes. Drawn as a band so
        # its width is the time it actually cost. Hatched when the vote ran the clock
        # out rather than ending early -- those are the ones that drag.
        for mt in ep.meetings:
            if mt.start > x_max:
                continue
            ax.fill_between(
                [mt.start, min(mt.end, x_max)],
                y - 0.44,
                y + 0.44,
                color=MEETING,
                alpha=0.20 if mt.timed_out else 0.10,
                hatch="///" if mt.timed_out else None,
                edgecolor=MEETING,
                lw=0,
                zorder=1,
            )
            ax.vlines(mt.start, y - 0.44, y + 0.44, color=MEETING, lw=1.4, alpha=0.9, zorder=2)

        last = dict.fromkeys(rows, -1e18)
        for c in me.completions:
            row = next((r for r in rows if c.tick - last[r] >= min_sep), rows[0])
            last[row] = c.tick
            cy = y + row
            if row:
                ax.plot([c.tick, c.tick], [y, cy], color=GRID, lw=1, zorder=3)
            face, edge = (SURFACE, GHOST) if c.while_dead else (ALIVE, SURFACE)
            ax.plot(c.tick, cy, marker="o", ms=15, mfc=face, mec=edge, mew=1.6, zorder=4)
            ax.annotate(
                str(c.task),
                (c.tick, cy),
                ha="center",
                va="center",
                zorder=5,
                fontsize=7,
                fontweight="bold",
                color=GHOST if c.while_dead else "#ffffff",
            )

    ax.set_yticks(range(n))
    ax.set_yticklabels(
        [
            f"{ep.episode_id[:8]}   {len(me.completions)}/{len(me.assigned)}"
            for ep, me in reversed(runs)
        ],
        fontfamily="monospace",
        fontsize=8,
        color=SECONDARY,
    )
    ax.set_xlim(-x_max * 0.015, x_max * 1.02)
    ax.set_ylim(-0.8, n - 0.2)
    xlabel = "game tick"
    if truncated:
        xlabel += (
            "   (axis cropped at the last event — a task, a kill or the end of a meeting; "
            f"{truncated} games ran on past it)"
        )
    ax.set_xlabel(xlabel, color=MUTED, fontsize=9, labelpad=6)
    ax.grid(axis="x", color=GRID, lw=0.8, zorder=0)
    ax.set_axisbelow(True)

    ax.legend(
        handles=[
            Line2D([], [], marker="o", ls="", ms=9, mfc=ALIVE, mec=SURFACE, label="task completed"),
            Line2D(
                [],
                [],
                marker="o",
                ls="",
                ms=9,
                mfc=SURFACE,
                mec=GHOST,
                mew=1.6,
                label="completed while dead",
            ),
            Line2D([], [], marker="x", ls="", ms=8, mew=2, color=DEATH, label="killed"),
            Patch(facecolor=MEETING, alpha=0.10, label="meeting (teleport to Bridge; no tasks)"),
            Patch(
                facecolor=MEETING,
                alpha=0.20,
                hatch="///",
                edgecolor=MEETING,
                lw=0,
                label="meeting that ran the vote clock out",
            ),
        ],
        loc="lower right",
        bbox_to_anchor=(1.0, 1.005),
        ncol=5,
        frameon=False,
        fontsize=8,
        labelcolor=SECONDARY,
        handletextpad=0.4,
        columnspacing=1.6,
    )


def _refmap(ax, ep: EpisodeTasks, highlight: set[int]) -> None:
    """The Croatoan basemap with every task station numbered. No routes drawn."""
    _style(ax)
    croatoan_axes(ax, ep.map_w, ep.map_h)
    ax.set_xticks([])
    ax.set_yticks([])

    for sid, (sx, sy) in sorted(ep.task_xy.items()):
        on = sid in highlight
        ax.plot(
            sx,
            sy,
            marker="o",
            ms=15,
            mfc=ALIVE if on else SURFACE,
            mec=ALIVE if on else MUTED,
            mew=1.4,
            alpha=1.0 if on else 0.85,
            zorder=3,
        )
        ax.annotate(
            str(sid),
            (sx, sy),
            ha="center",
            va="center",
            zorder=4,
            fontsize=7,
            fontweight="bold" if on else "normal",
            color="#ffffff" if on else SECONDARY,
        )


def render_runs(
    runs: list[tuple[EpisodeTasks, CrewTasks]],
    player: str,
    out: str | Path,
    *,
    dpi: int = 200,
    selection: str = "",
    total_games: int = 0,
    swimlane_only: bool = False,
) -> Path:
    """Render ``player``'s runs: swimlanes above, the numbered reference map below.

    ``swimlane_only`` drops the reference map and renders just the lanes -- the map
    is a constant, so once you know it, repeating it under every chart is noise.

    ``selection``/``total_games`` describe how these runs were chosen out of the
    player's full set. They are printed in the subtitle, because the headline
    figures are computed over the *drawn* games -- and a selection like "best"
    makes "100% of tasks completed" true by construction. Stating the sample is
    the difference between a summary and a misleading one.

    Raises ``ValueError`` if there is nothing to draw, or (unless ``swimlane_only``)
    if the stream carried no ``map_geometry`` and the station numbers have nowhere
    to land.
    """
    if not runs:
        raise ValueError(f"no games to render for {player!r}")
    ep0 = runs[0][0]
    if not swimlane_only and (not ep0.map_w or not ep0.task_xy):
        raise ValueError(
            f"{ep0.episode_id}: the stream carries no map_geometry, so the reference map "
            "cannot be drawn. Regenerate with `expand_replay --format jsonl <replay>`, "
            "or pass --swimlane-only to chart the lanes without it."
        )

    lane_h = 0.46 * len(runs) + 1.6  # room for the stagger rows
    map_h = 0.0 if swimlane_only else 9.2 * (ep0.map_h / ep0.map_w)
    # The header block is a fixed height, so its share of the figure -- and the top
    # margin that clears it -- has to shrink as the figure grows.
    fig_h = lane_h + map_h + 1.1
    fig = plt.figure(figsize=(13.5, fig_h), facecolor=PAGE)
    gs = fig.add_gridspec(
        1 if swimlane_only else 2,
        1,
        height_ratios=[lane_h] if swimlane_only else [lane_h, map_h],
        hspace=0.16,
        left=0.14,
        right=0.975,
        # The header (title + subtitle + the legend that sits above the axes) needs a
        # fixed ~1.15in, so as a figure fraction it has to shrink as the figure grows.
        top=1 - 1.15 / fig_h,
        bottom=0.62 / fig_h if swimlane_only else 0.035,
    )

    done = sum(len(m.completions) for _, m in runs)
    asg = sum(len(m.assigned) for _, m in runs)
    deaths = sum(1 for _, m in runs if m.death_tick >= 0)
    ghosts = sum(1 for _, m in runs for c in m.completions if c.while_dead)

    if total_games and total_games > len(runs):
        scope = f"{len(runs)} of {total_games} games as crew"
        if selection and selection != "id":
            scope += f", picked by '{selection}' — these figures describe the sample, not {player}"
    else:
        scope = f"{len(runs)} games as crew"

    # Anchor the header in inches from the top, not in figure fractions -- the figure
    # height changes with the lane count and with --swimlane-only.
    fig.text(0.014, 1 - 0.16 / fig_h, player, color=INK, fontsize=17, fontweight="bold", va="top")
    fig.text(
        0.014,
        1 - 0.42 / fig_h,
        f"{scope}  ·  {done}/{asg} tasks completed "
        f"({100 * done / asg:.0f}%)  ·  killed in {deaths}  ·  {ghosts} tasks done while dead",
        color=SECONDARY,
        fontsize=9.5,
        va="top",
    )

    _lanes(fig.add_subplot(gs[0]), runs)

    if not swimlane_only:
        ax = fig.add_subplot(gs[1])
        touched = {c.task for _, m in runs for c in m.completions}
        _refmap(ax, ep0, touched)
        ax.set_title(
            "Croatoan task stations — the numbers in the lanes above. "
            f"Filled = a station {player} completed at least once.",
            color=SECONDARY,
            fontsize=9,
            loc="left",
            pad=8,
        )

    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out, dpi=dpi, facecolor=PAGE)
    plt.close(fig)
    return out
