"""``swgy-task-viz``: how a crew policy works its task list, as a picture.

Renders two stacked panels for one policy across a handful of games:

* **Swimlanes** -- one lane per game, one marker per task completion, placed at the
  tick it happened and labelled with the task-station number. Read a lane left to
  right and you have the order the policy did its tasks in; the *gaps* are how long
  it spent between them. Meetings, the kill, and the stretch spent dead are drawn on
  the same timeline, because they are what explain the gaps.
* **A Croatoan reference map** -- every task station, numbered. Look a lane's numbers
  up on it to see where the policy actually went. Stations are deliberately *not*
  joined into a route: the crew walks a navmesh, so a straight line between two
  stations would draw a path that never happened. The map is a constant, so
  ``--swimlane-only`` drops it once you have the station numbers memorised.

Built for a *small* selection -- a couple of dozen games at most -- where every lane
stays readable. For corpus-scale questions use ``swgy-task-report --format csv``.

A ``.replay`` holds no task data (only inputs and per-tick hashes), so replays are
re-simulated with the game's ``expand_replay``, exactly like ``swgy-task-report``.
Point it at ``.jsonl`` you already expanded and no game checkout is needed.
"""

from __future__ import annotations

import argparse
import os
import re
import sys
from concurrent.futures import ThreadPoolExecutor

from .cli import collect_inputs, load_episode
from .eventlog import CrewTasks, EpisodeTasks, TaskLogError
from .expand import ExpandReplayError, find_expand_replay
from .render import render_runs

MAX_LANES = 24

EPILOG = """\
examples:
  # who is even in these replays?  (start here -- --player needs an exact name)
  swgy-task-viz replays/ --list-players

  # one policy, the games it played, newest expand_replay on $PATH
  export CREWRIFT_EXPAND_REPLAY=~/Dev/coworld-crewrift/tools/expand_replay
  swgy-task-viz replays/ --player daveey

  # its ten worst games, to see where it falls apart
  swgy-task-viz replays/ --player "James Boggs" --sort worst --limit 10

  # JSONL you already expanded -- no game checkout needed
  swgy-task-viz expanded/ --glob '*.jsonl' --player daveey -o daveey.png

  # lanes only, no reference map (for when you already know the stations)
  swgy-task-viz replays/ --player daveey --swimlane-only

reading the chart:
  filled dot   a task completed while alive; the number is its station
  hollow ring  a task completed *after* being killed (a ghost still scores)
  red cross    the kill
  orange bar   a meeting: everyone is teleported to the Bridge, which resets
               whatever route the policy was running
"""


def _slug(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-") or "player"


def _sort_key(mode: str):
    if mode == "best":
        return lambda r: -len(r[1].completions)
    if mode == "worst":
        return lambda r: len(r[1].completions)
    if mode == "early-death":
        return lambda r: (r[1].death_tick < 0, r[1].death_tick)
    return lambda r: r[0].episode_id  # "id"


def _load(files, binary, workers) -> tuple[list[EpisodeTasks], int]:
    """Re-simulate/parse every input. Returns the usable episodes and a skip count."""
    episodes: list[EpisodeTasks] = []
    n_skip = 0
    with ThreadPoolExecutor(max_workers=max(1, workers)) as pool:
        futures = [pool.submit(load_episode, f, binary, 0) for f in files]
        for f, future in zip(files, futures, strict=True):
            try:
                ep = future.result()
            except (TaskLogError, ExpandReplayError) as e:
                print(f"skip {f.name}: {e}", file=sys.stderr)
                n_skip += 1
                continue
            if not ep.hash_ok or not ep.started:
                n_skip += 1
                continue
            episodes.append(ep)
    return episodes, n_skip


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        prog="swgy-task-viz",
        description="Chart one crew policy's task order over a numbered Croatoan map.",
        epilog=EPILOG,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument("inputs", nargs="+", help="replay file(s), expand_replay .jsonl, or a directory")
    p.add_argument(
        "--player",
        help="the crew policy to chart, by its exact join name (see --list-players)",
    )
    p.add_argument(
        "--list-players",
        action="store_true",
        help="print the crew names found in the inputs, with how many games each played, and exit",
    )
    p.add_argument(
        "-o",
        "--out",
        help="output PNG (default: tmp/<player>-tasks.png)",
    )
    p.add_argument(
        "--sort",
        choices=("id", "best", "worst", "early-death"),
        default="id",
        help="which games to draw when there are more than --limit, and in what order "
        "(default: id, i.e. no cherry-picking)",
    )
    p.add_argument(
        "--limit",
        type=int,
        default=MAX_LANES,
        help=f"max lanes to draw; past ~{MAX_LANES} they stop being readable (default: {MAX_LANES})",
    )
    p.add_argument(
        "--swimlane-only",
        action="store_true",
        help="draw just the lanes, without the Croatoan reference map underneath "
        "(the map is the same every time -- drop it once you know the station numbers)",
    )
    p.add_argument("--dpi", type=int, default=200, help="output resolution (default: 200)")
    p.add_argument(
        "--expand-replay",
        help="path to the expand_replay binary, needed only for .replay inputs "
        "(or set $CREWRIFT_EXPAND_REPLAY)",
    )
    p.add_argument(
        "--workers",
        type=int,
        default=os.cpu_count() or 1,
        help="parallel re-sims (default: CPU count)",
    )
    p.add_argument("--glob", default="*.replay", help="glob for files inside a directory")
    args = p.parse_args(argv)

    if not args.player and not args.list_players:
        p.error("give --player NAME (or --list-players to see what names are available)")

    files = collect_inputs(args.inputs, args.glob)
    if not files:
        raise SystemExit(
            f"no inputs found: nothing matched {args.glob!r} in {', '.join(args.inputs)}. "
            "Pass replay files directly, or --glob '*.jsonl' for expanded output."
        )

    binary = (
        find_expand_replay(args.expand_replay) if any(f.suffix != ".jsonl" for f in files) else None
    )
    episodes, n_skip = _load(files, binary, args.workers)
    if not episodes:
        raise SystemExit(
            f"none of the {len(files)} inputs held a playable game ({n_skip} skipped)."
        )

    if args.list_players:
        games: dict[str, int] = {}
        for ep in episodes:
            for m in ep.crew:
                games[m.name] = games.get(m.name, 0) + 1
        print(f"crew across {len(episodes)} playable games:")
        for name, n in sorted(games.items(), key=lambda kv: -kv[1]):
            print(f"  {n:>4} games  {name}")
        print("\ncharted with: swgy-task-viz <inputs> --player '<name>'")
        return 0

    runs: list[tuple[EpisodeTasks, CrewTasks]] = []
    seen: set[str] = set()
    for ep in episodes:
        seen.update(m.name for m in ep.crew)
        me = next((m for m in ep.crew if m.name == args.player), None)
        if me is not None:
            runs.append((ep, me))

    if not runs:
        raise SystemExit(
            f"{args.player!r} was never a crew member in these {len(episodes)} games "
            f"(they may have been an imposter throughout, or the name is off).\n"
            f"Crew found: {', '.join(sorted(seen)) or 'none'}.\n"
            "Run with --list-players for the counts."
        )

    total = len(runs)
    runs.sort(key=_sort_key(args.sort))
    if total > args.limit:
        print(
            f"drawing {args.limit} of {total} games (--sort {args.sort}); "
            "raise --limit to see more",
            file=sys.stderr,
        )
        runs = runs[: args.limit]

    out = args.out or f"tmp/{_slug(args.player)}-tasks.png"
    path = render_runs(
        runs,
        args.player,
        out,
        dpi=args.dpi,
        selection=args.sort,
        total_games=total,
        swimlane_only=args.swimlane_only,
    )
    print(f"{len(runs)} games -> {path}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
