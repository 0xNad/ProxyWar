"""Parse ``expand_replay`` JSONL into one episode's per-crew task record.

Each line is an envelope ``{"ts": tick, "player": slot, "key": ..., "value": ...}``.
This module consumes only the rows a task report needs and re-simulates nothing.

The load-bearing row is ``player_manifest``: it is the only one carrying ``role``
and ``assigned_tasks``. It is emitted for ``--format jsonl`` runs of an
expand_replay that has the manifest change; an older binary only emits it under
``--snapshot-every N``. A stream without it cannot answer "who was crew and what
were they given", so that is a hard error rather than an empty report.

Task *stations* are shared: one station is typically on several crew members'
assignment lists, and ``TaskStation.completed`` is a per-player bool array, so a
``completed_task`` row is scoped to (slot, task).
"""

from __future__ import annotations

import json
from collections.abc import Iterable, Iterator
from dataclasses import dataclass, field

CREW = "crew"


class TaskLogError(ValueError):
    """Raised when the JSONL is not usable expand_replay task output."""


@dataclass
class Room:
    """One named room rect on the map, in map pixels (== world coords)."""

    name: str
    x: int
    y: int
    w: int
    h: int


@dataclass
class Meeting:
    """One meeting, from the call to the moment play resumes.

    The sim runs ``MeetingCall -> Voting -> VoteResult -> Playing``. Everyone alive is
    teleported to the Bridge at the call, and nobody can touch a task until play
    resumes -- so a meeting is a *span*, not an instant.

    ``timed_out`` means the Voting phase ran the full ``vote_timer_ticks`` instead of
    ending early because everyone had voted. Those are the meetings that drag.
    """

    start: int  # the MeetingCall tick: the teleport
    end: int  # the tick play resumes (== end_tick if the game ended first)
    kind: str  # "body" (a corpse was reported) | "button" (the emergency button)
    timed_out: bool

    @property
    def ticks(self) -> int:
        return self.end - self.start


@dataclass
class TaskCompletion:
    """One crew member finishing one task station."""

    task: int
    tick: int
    room: str
    task_name: str
    while_dead: bool  # a ghost finishing a task -- it still counts toward the crew win


@dataclass
class CrewTasks:
    """One crew player's assignment and what they did with it."""

    slot: int
    name: str  # the join name == the policy/uploader identity
    label: str  # "colour(name)", the in-sim display label
    color: str
    assigned: list[int]  # station indices, in the order the sim assigned them
    completions: list[TaskCompletion] = field(default_factory=list)  # in completion order
    starts: int = 0  # started_task events: completions + abandoned attempts
    death_tick: int = -1  # -1 == survived to the end

    @property
    def unfinished(self) -> list[int]:
        done = {c.task for c in self.completions}
        return [t for t in self.assigned if t not in done]


@dataclass
class EpisodeTasks:
    """Everything a task report needs from one replay.

    ``started`` is False for an episode whose game never began -- too few players
    joined, so the sim never assigned roles and there are no tasks to report. It
    is a normal outcome in a league corpus, not a parse failure.
    """

    episode_id: str
    hash_ok: bool
    started: bool
    fail_tick: int
    end_tick: int
    outcome: str
    imposter_count: int
    tasks_per_player: int
    task_rooms: dict[int, str] = field(default_factory=dict)  # station index -> room name
    task_names: dict[int, str] = field(default_factory=dict)
    crew: list[CrewTasks] = field(default_factory=list)
    # Meetings, in tick order. A meeting teleports every living player back to the
    # Bridge and blocks tasks until play resumes, so it interrupts whatever route a
    # policy was running -- which is why it belongs on the same timeline as the tasks.
    meetings: list[Meeting] = field(default_factory=list)
    # Croatoan geometry, for plotting a route on the ship (map_geometry row).
    map_w: int = 0
    map_h: int = 0
    rooms: list[Room] = field(default_factory=list)
    task_xy: dict[int, tuple[int, int]] = field(default_factory=dict)  # station -> centre


def iter_rows(lines: Iterable[str]) -> Iterator[dict]:
    """Yield each JSONL row.

    Strict: expand_replay's stdout is pure JSONL by construction (it disables the
    sim's event logging), so a line that will not parse means corruption, not
    noise to skip past.
    """
    for n, line in enumerate(lines, start=1):
        line = line.strip()
        if not line:
            continue
        try:
            yield json.loads(line)
        except json.JSONDecodeError as e:
            raise TaskLogError(f"line {n} is not JSON: {line[:80]!r}") from e


def _meetings(
    phases: list[tuple[int, str]],
    calls: list[tuple[int, str]],
    vote_timer: int,
    end_tick: int,
) -> list[Meeting]:
    """Turn the phase stream into meeting spans.

    The sim's cycle is ``MeetingCall -> Voting -> VoteResult -> Playing``. The
    meeting starts at the call (that is when everyone is teleported to the Bridge)
    and is over when play resumes. A Voting phase that lasted the full
    ``vote_timer_ticks`` ended on the clock, not because everyone voted.
    """
    phases = sorted(phases)
    out: list[Meeting] = []
    for i, (tick, name) in enumerate(phases):
        if name != "MeetingCall":
            continue
        rest = phases[i + 1 :]
        end = next((t for t, p in rest if p == "Playing"), end_tick)
        voting = next((t for t, p in rest if p == "Voting"), -1)
        result = next((t for t, p in rest if p == "VoteResult"), -1)
        timed_out = voting >= 0 and result >= 0 and vote_timer > 0 and result - voting >= vote_timer
        # the vote_called_* row lands inside the span and says what triggered it
        kind = next((k for t, k in calls if tick <= t <= end), "")
        out.append(Meeting(start=tick, end=end, kind=kind, timed_out=timed_out))
    return out


def parse_episode(lines: Iterable[str], *, episode_id: str) -> EpisodeTasks:
    """Parse one episode's expand_replay JSONL into an :class:`EpisodeTasks`.

    Imposters are dropped -- their ``assigned_tasks`` is empty and they cannot
    complete a station.

    An episode whose game never started (too few players joined, so the sim never
    assigned roles) comes back with ``started=False`` and no crew -- that is a
    real league outcome, not an error.

    Raises :class:`TaskLogError` if the stream is not manifest-bearing
    expand_replay output at all, or if a completion violates the sim's invariants
    (a task completed twice, or one that was never assigned).
    """
    crew: dict[int, CrewTasks] = {}
    roles: dict[int, str] = {}
    saw_context = False
    task_rooms: dict[int, str] = {}
    task_names: dict[int, str] = {}
    task_xy: dict[int, tuple[int, int]] = {}
    rooms: list[Room] = []
    calls: list[tuple[int, str]] = []  # (tick, kind) from vote_called_*
    phases: list[tuple[int, str]] = []  # (tick, phase name)
    map_w = map_h = 0
    vote_timer = 0
    starts: dict[int, int] = {}
    deaths: dict[int, int] = {}
    completions: list[tuple[int, int, int, bool]] = []  # (tick, slot, task, while_dead)
    hash_ok, fail_tick, end_tick, outcome = True, -1, 0, "unknown"
    imposter_count = tasks_per_player = 0

    for row in iter_rows(lines):
        key = row.get("key")
        ts = int(row.get("ts", 0))
        slot = int(row.get("player", -1))
        val = row.get("value") or {}
        end_tick = max(end_tick, ts)

        if key == "episode_metadata":
            saw_context = True
            config = val.get("config") or {}
            imposter_count = int(config.get("imposter_count", 0))
            tasks_per_player = int(config.get("tasks_per_player", 0))
            vote_timer = int(config.get("vote_timer_ticks", 0))
        elif key == "map_geometry":
            saw_context = True
            map_w, map_h = int(val.get("width", 0)), int(val.get("height", 0))
            rooms = [
                Room(str(r["name"]), int(r["x"]), int(r["y"]), int(r["w"]), int(r["h"]))
                for r in val.get("rooms", [])
            ]
            # Each task rect ships the room the producer resolved it to; don't re-derive it.
            for i, rect in enumerate(val.get("tasks", [])):
                idx = int(rect.get("id", i))
                task_rooms[idx] = str(rect.get("room", ""))
                task_names[idx] = str(rect.get("name", ""))
                task_xy[idx] = (
                    int(rect["x"]) + int(rect["w"]) // 2,
                    int(rect["y"]) + int(rect["h"]) // 2,
                )
        elif key == "player_manifest":
            roles[slot] = str(val.get("role", ""))
            if roles[slot] == CREW:
                crew[slot] = CrewTasks(
                    slot=slot,
                    name=str(val.get("address", "")),
                    label=str(val.get("label", "")),
                    color=str(val.get("color", "")),
                    assigned=[int(t) for t in val.get("assigned_tasks", [])],
                )
        elif key == "completed_task":
            completions.append((ts, slot, int(val["task"]), bool(val.get("while_dead", False))))
        elif key == "started_task":
            starts[slot] = starts.get(slot, 0) + 1
        elif key == "kill":
            # A murdered player leaves a corpse, and expand_replay suppresses the
            # `died` event for anyone in that tick's bodyVictims -- so `died` fires
            # ONLY for ejections. Take the kill's victim, or every murder reads as
            # "survived" and every ghost task looks like it happened to a live player.
            victim = int(val["victim_slot"])
            deaths[victim] = min(deaths.get(victim, ts), ts)
        elif key == "died":
            deaths[slot] = min(deaths.get(slot, ts), ts)  # ejected (no body)
        elif key == "vote_called_body":
            calls.append((ts, "body"))
        elif key == "vote_called_button":
            calls.append((ts, "button"))
        elif key == "phase":
            phases.append((ts, str(val.get("phase", ""))))
        elif key == "trace_complete":
            hash_ok = bool(val.get("complete", True))
            fail_tick = int(val.get("fail_tick", -1))
            outcome = str(val.get("outcome", "unknown"))
            if hash_ok:
                end_tick = int(val.get("tick_count", end_tick))

    # episode_metadata/map_geometry ride along with the manifest, so their absence
    # means the producer never emits manifests -- a different problem from a game
    # that started but assigned no roles (which cannot happen: minPlayers >= 1 crew).
    if not saw_context:
        raise TaskLogError(
            f"{episode_id}: no episode_metadata/map_geometry rows, so this is not "
            "manifest-bearing expand_replay output. Regenerate with `expand_replay "
            "--format jsonl <replay>`; if your expand_replay predates the manifest "
            "change, pass --snapshot-every N as well."
        )
    started = bool(roles)

    for tick, slot, task, while_dead in sorted(completions):
        if roles.get(slot) != CREW:
            continue
        member = crew[slot]
        if task not in member.assigned:
            raise TaskLogError(
                f"{episode_id}: slot {slot} completed task {task}, which is not in its "
                f"assigned set {member.assigned} -- the stream contradicts the sim."
            )
        if any(c.task == task for c in member.completions):
            raise TaskLogError(
                f"{episode_id}: slot {slot} completed task {task} twice at tick {tick} -- "
                "the sim latches completion per (player, station), so this cannot happen."
            )
        member.completions.append(
            TaskCompletion(
                task=task,
                tick=tick,
                room=task_rooms.get(task, ""),
                task_name=task_names.get(task, ""),
                while_dead=while_dead,
            )
        )

    for slot, member in crew.items():
        member.starts = starts.get(slot, 0)
        member.death_tick = deaths.get(slot, -1)

    return EpisodeTasks(
        episode_id=episode_id,
        hash_ok=hash_ok,
        started=started,
        fail_tick=fail_tick,
        end_tick=end_tick,
        outcome=outcome,
        imposter_count=imposter_count,
        tasks_per_player=tasks_per_player,
        task_rooms=task_rooms,
        task_names=task_names,
        crew=[crew[s] for s in sorted(crew)],
        meetings=_meetings(phases, calls, vote_timer, end_tick),
        map_w=map_w,
        map_h=map_h,
        rooms=rooms,
        task_xy=task_xy,
    )
