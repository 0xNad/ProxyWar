"""Locate and run the game's ``expand_replay`` re-simulator.

A ``.replay`` carries inputs and per-tick hashes, nothing else -- recovering task
assignments means re-running the sim, and only the game engine can do that. This
module shells out to the ``expand_replay`` binary built from the ``coworld-crewrift``
checkout::

    nim c -d:release --opt:speed --out:tools/expand_replay tools/expand_replay.nim

The binary bakes its game directory in at compile time (``GameDir`` is a
``currentSourcePath()`` const) and chdirs there at runtime to load the map, so it
self-locates from any cwd -- but it dies if that checkout is moved or renamed.

Exit-status contract (``expand_replay.nim`` prints its trace rows *then* fails):

    trace_complete + complete=true  , rc 0   -> a clean re-sim
    trace_complete + complete=false , rc 1   -> a hash mismatch; rows up to the
                                                failing tick are still on stdout
    no trace_complete               , rc !=0 -> the run itself broke (bad path,
                                                moved checkout); stderr says why

So a non-zero exit is *not* on its own a failure: never use ``check=True``, and
always read stdout back.
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path

ENV_VAR = "CREWRIFT_EXPAND_REPLAY"
REPLAY_SUFFIXES = (".replay", ".bitreplay")


class ExpandReplayError(RuntimeError):
    """Raised when expand_replay could not be run, or died without a verdict."""


def find_expand_replay(explicit: str | None = None) -> Path:
    """Return the ``expand_replay`` binary. Resolution: ``explicit`` -> ``$CREWRIFT_EXPAND_REPLAY``."""
    candidate = explicit or os.environ.get(ENV_VAR)
    if not candidate:
        raise ExpandReplayError(
            "re-simulating a .replay needs the game's expand_replay binary: pass "
            f"--expand-replay PATH (or set ${ENV_VAR}). Build it with `nim c -d:release "
            "--out:tools/expand_replay tools/expand_replay.nim` in a coworld-crewrift "
            "checkout whose game version matches the replays."
        )
    path = Path(candidate).resolve()
    if not path.is_file() or not os.access(path, os.X_OK):
        raise ExpandReplayError(f"expand_replay is not an executable file: {path}")
    return path


def run_expand_replay(
    binary: Path, replay: Path, *, snapshot_every: int = 0, timeout: float = 900.0
) -> list[str]:
    """Re-simulate one replay and return its JSONL lines.

    ``snapshot_every`` is only needed for an expand_replay predating the manifest
    change, which emitted ``player_manifest`` solely under ``--snapshot-every``.
    It costs a line-of-sight trace per living player per tick, so leave it at 0.

    Raises :class:`ExpandReplayError` if the binary produced no verdict row. A
    hash mismatch is *not* an error here -- it comes back as a ``trace_complete``
    row with ``complete=false`` for the caller to report and skip.
    """
    argv = [str(binary), "--format", "jsonl"]
    if snapshot_every > 0:
        argv += ["--snapshot-every", str(snapshot_every)]
    argv.append(str(replay.resolve()))  # never rely on the binary's default replay path

    proc = subprocess.run(argv, capture_output=True, text=True, timeout=timeout, check=False)
    lines = proc.stdout.splitlines()
    if not any('"trace_complete"' in line for line in lines):
        raise ExpandReplayError(
            f"expand_replay produced no verdict for {replay.name} (rc={proc.returncode}). "
            f"stderr: {proc.stderr.strip() or '(empty)'}"
        )
    return lines
