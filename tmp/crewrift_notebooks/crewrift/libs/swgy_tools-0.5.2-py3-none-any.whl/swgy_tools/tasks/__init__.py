"""Per-crew task assignment and completion order from CrewRift replays.

A ``.replay`` file holds **no task data**. It is an input-only deterministic
replay: a config blob, the players' button presses, and a per-tick state hash
(there to prove a re-sim is bit-exact). Roles, task assignments and task
completions exist only as a product of re-running the sim over those inputs.

So this tool does not parse ``.replay`` itself -- it drives the game repo's
``expand_replay``, which re-simulates and emits the event stream as JSONL::

    expand_replay --format jsonl <replay>

and reads back the four row kinds that matter: ``player_manifest`` (the only row
carrying ``role`` and ``assigned_tasks``), ``completed_task``, ``started_task``
and ``map_geometry``. ``swgy-task-report`` accepts either a ``.replay`` (it shells
out for you) or JSONL you expanded yourself.

Contents:
    expand     -- locate and run the expand_replay binary
    eventlog   -- JSONL -> EpisodeTasks (pure; no subprocess, no game source)
    report     -- text / CSV / JSON renderers
    cli        -- console script: ``swgy-task-report``
"""
