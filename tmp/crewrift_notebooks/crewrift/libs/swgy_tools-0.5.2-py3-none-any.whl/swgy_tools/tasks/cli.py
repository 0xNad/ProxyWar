"""``swgy-task-report``: what each crew member was assigned, and when they did it.

Takes either a ``.replay`` -- which it re-simulates by shelling out to the game's
``expand_replay`` -- or JSONL you expanded yourself::

    uv run swgy-task-report game.replay --expand-replay ~/Dev/coworld-crewrift/tools/expand_replay
    uv run swgy-task-report game.jsonl                       # already expanded; no game repo needed
    uv run swgy-task-report replays/ --format csv -o tasks.csv --workers 8

A ``.replay`` holds no task data (inputs + hashes only), so the re-sim is not
optional -- see :mod:`swgy_tools.tasks`. It is also the slow part: rows are written
and flushed as each episode lands, so a long corpus run that dies partway keeps
everything it already earned.
"""

from __future__ import annotations

import argparse
import csv
import os
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from .eventlog import EpisodeTasks, TaskLogError, parse_episode
from .expand import REPLAY_SUFFIXES, ExpandReplayError, find_expand_replay, run_expand_replay
from .report import CSV_COLUMNS, csv_rows, json_line, text_report

JSONL_SUFFIX = ".jsonl"


def collect_inputs(inputs: list[str], glob: str) -> list[Path]:
    """Expand file/dir args into a sorted list of files."""
    out: list[Path] = []
    for item in inputs:
        p = Path(item)
        out.extend(sorted(p.glob(glob)) if p.is_dir() else [p])
    return out


def load_episode(path: Path, binary: Path | None, snapshot_every: int) -> EpisodeTasks:
    """Parse one input into an :class:`EpisodeTasks`, re-simulating it if it's a replay."""
    if path.suffix in REPLAY_SUFFIXES:
        if binary is None:
            raise ExpandReplayError(
                f"{path.name} is a replay and must be re-simulated, but no expand_replay "
                "was given: pass --expand-replay PATH."
            )
        lines = run_expand_replay(binary, path, snapshot_every=snapshot_every)
    elif path.suffix == JSONL_SUFFIX:
        lines = path.read_text().splitlines()
    else:
        raise ExpandReplayError(
            f"{path.name}: expected a replay ({', '.join(REPLAY_SUFFIXES)}) to re-simulate "
            f"or {JSONL_SUFFIX} expand_replay output to read."
        )
    return parse_episode(lines, episode_id=path.stem)


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Report each crew member's assigned tasks and completion order."
    )
    p.add_argument("inputs", nargs="+", help="replay file(s), expand_replay .jsonl, or a directory")
    p.add_argument(
        "--format", choices=("text", "csv", "json"), default="text", help="output format"
    )
    p.add_argument("-o", "--out", help="output file (default: stdout)")
    p.add_argument(
        "--expand-replay",
        help="path to the expand_replay binary (or set $CREWRIFT_EXPAND_REPLAY); "
        "required for replay inputs, unused for .jsonl",
    )
    p.add_argument(
        "--snapshot-every",
        type=int,
        default=0,
        help="only for an expand_replay predating the manifest change, which emitted "
        "player_manifest solely under --snapshot-every (default: 0, do not pass it)",
    )
    p.add_argument(
        "--workers",
        type=int,
        default=os.cpu_count() or 1,
        help="parallel re-sims (default: CPU count)",
    )
    p.add_argument("--glob", default="*.replay", help="glob for files inside a directory")
    args = p.parse_args(argv)

    files = collect_inputs(args.inputs, args.glob)
    if not files:
        raise SystemExit(f"no inputs found (looked for {args.glob!r} in {args.inputs}).")

    needs_resim = any(f.suffix in REPLAY_SUFFIXES for f in files)
    binary = find_expand_replay(args.expand_replay) if needs_resim else None

    out = Path(args.out).open("w") if args.out else sys.stdout
    writer = None
    if args.format == "csv":
        writer = csv.DictWriter(out, fieldnames=CSV_COLUMNS)
        writer.writeheader()

    n_ok = n_desync = n_unstarted = n_err = 0
    try:
        with ThreadPoolExecutor(max_workers=max(1, args.workers)) as pool:
            # Submit up front to keep the workers fed, but consume in order so the
            # output is deterministic -- and so one bad episode cannot take down a
            # corpus run that may already have hours of re-sim behind it.
            futures = [pool.submit(load_episode, f, binary, args.snapshot_every) for f in files]
            for i, (f, future) in enumerate(zip(files, futures, strict=True), start=1):
                try:
                    ep = future.result()
                except (TaskLogError, ExpandReplayError) as e:
                    print(f"skip {f.name}: {e}", file=sys.stderr)
                    n_err += 1
                    continue

                if not ep.hash_ok:
                    print(
                        f"skip {ep.episode_id}: expand_replay hit a hash mismatch at tick "
                        f"{ep.fail_tick} -- the game build is OUT OF SYNC with this replay's "
                        "recording version; rebuild expand_replay at the matching ref.",
                        file=sys.stderr,
                    )
                    n_desync += 1
                    continue
                if not ep.started:
                    print(
                        f"skip {ep.episode_id}: the game never started (too few players "
                        f"joined), so no roles or tasks were assigned; outcome {ep.outcome}.",
                        file=sys.stderr,
                    )
                    n_unstarted += 1
                    continue

                if args.format == "csv":
                    writer.writerows(csv_rows(ep))
                elif args.format == "json":
                    out.write(json_line(ep) + "\n")
                else:
                    out.write(text_report(ep) + "\n")
                out.flush()  # a corpus re-sim takes hours; never lose finished work
                n_ok += 1
                if len(files) > 1:
                    print(f"[{i}/{len(files)}] {f.name}", file=sys.stderr)
    finally:
        if out is not sys.stdout:
            out.close()

    skipped = f"{n_desync} hash-failed, {n_unstarted} never started, {n_err} errored"
    if not n_ok:
        raise SystemExit(f"no usable episodes ({skipped}).")
    print(f"reported {n_ok} episodes ({skipped})", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
