"""Read a CrewRift ``.replay`` file offline -- roster, config, duration. No game build.

A replay is an **input-only deterministic replay**: a config blob, the players' button
presses, and a per-tick state hash. It holds no roles, no tasks, no positions -- those
only exist once the sim is re-run over it (see :mod:`swgy_tools.tasks`). But the things
it *does* hold are worth having, and nothing else in this package can get at them
without a Nim game build: **which policy played which slot**, the seed, the game config,
and how long the game ran.

The format (little-endian throughout; ``str`` = u16 length + UTF-8)::

    header : magic "CREWRIFT" | u16 formatVersion | str gameName | str gameVersion
             | u64 timestamp_ms | str configJson
    record*: u8 type + body
        0x01 tick-hash     u32 tick + u64 hash
        0x02 input         u32 ms + u8 player + u8 keys
        0x03 join          u32 ms + u8 player + str name + i16 slot + str token
        0x04 leave         u32 ms + u8 player
        0x05 chat          u32 ms + u8 player + str message
        0x06 debug-sprite  u32 ms + u8 player + u32 len + len bytes

Records are **not length-prefixed**, so an unknown type cannot be skipped: the rest of
the stream is unreadable from that point. This reader raises rather than stopping at
it. That is not pedantry -- a reader that silently stops returns a *plausible, wrong*
answer (a duration of 753 for a game that ran 16139 ticks), and the 0x06 record it
would stop at is in every league replay.
"""

from __future__ import annotations

import gzip
import json
import struct
import zlib
from dataclasses import dataclass, field
from pathlib import Path

MAGIC = b"CREWRIFT"

REC_TICK_HASH = 0x01
REC_INPUT = 0x02
REC_JOIN = 0x03
REC_LEAVE = 0x04
REC_CHAT = 0x05
REC_DEBUG_SPRITE = 0x06


class ReplayFormatError(ValueError):
    """Raised when a file is not a readable CrewRift replay."""


@dataclass
class Join:
    """One player joining. ``slot`` is the stable identity; ``player`` is join order."""

    ms: int
    player: int
    name: str  # the join name == the policy/uploader identity
    slot: int
    token: str


@dataclass
class ReplayInfo:
    """Everything a ``.replay`` can tell you without re-simulating it."""

    episode_id: str
    game_name: str
    game_version: str
    format_version: int
    timestamp_ms: int
    config: dict
    roster: dict[int, str] = field(default_factory=dict)  # slot -> policy name
    duration_ticks: int = 0
    n_inputs: int = 0
    n_chats: int = 0
    n_joins: int = 0
    n_leaves: int = 0
    n_debug_sprites: int = 0  # the record cr-analysis's parser silently stopped at
    spectators: list[Join] = field(default_factory=list)  # joins with slot < 0

    @property
    def seed(self) -> int | None:
        return self.config.get("seed")

    @property
    def imposter_count(self) -> int | None:
        return self.config.get("imposterCount")

    @property
    def tasks_per_player(self) -> int | None:
        return self.config.get("tasksPerPlayer")


class _Cursor:
    """A byte cursor. Every read is bounds-checked; a short read is a format error."""

    def __init__(self, buf: bytes, name: str) -> None:
        self.buf = buf
        self.name = name
        self.off = 0

    def _take(self, fmt: str, size: int):
        try:
            value = struct.unpack_from(fmt, self.buf, self.off)[0]
        except struct.error as e:
            raise ReplayFormatError(
                f"{self.name}: truncated at byte {self.off} of {len(self.buf)}"
            ) from e
        self.off += size
        return value

    def u8(self) -> int:
        return self._take("<B", 1)

    def u16(self) -> int:
        return self._take("<H", 2)

    def i16(self) -> int:
        return self._take("<h", 2)

    def u32(self) -> int:
        return self._take("<I", 4)

    def u64(self) -> int:
        return self._take("<Q", 8)

    def s(self) -> str:
        n = self.u16()
        raw = self.buf[self.off : self.off + n]
        if len(raw) != n:
            raise ReplayFormatError(f"{self.name}: truncated string at byte {self.off}")
        self.off += n
        return raw.decode("utf-8", errors="replace")

    def skip(self, n: int) -> None:
        if self.off + n > len(self.buf):
            raise ReplayFormatError(f"{self.name}: truncated payload at byte {self.off}")
        self.off += n


def _decompressed(raw: bytes, name: str) -> bytes:
    """The replay bytes. The codec allows a gzip/zlib wrapper, so unwrap it."""
    if raw.startswith(MAGIC):
        return raw
    if raw[:2] == b"\x1f\x8b":
        raw = gzip.decompress(raw)
    elif raw[:1] == b"\x78":
        raw = zlib.decompress(raw)
    if not raw.startswith(MAGIC):
        raise ReplayFormatError(f"{name}: not a CrewRift replay (no CREWRIFT magic, not gzip/zlib)")
    return raw


def read_replay(path: str | Path) -> ReplayInfo:
    """Parse one ``.replay`` into a :class:`ReplayInfo`.

    Raises :class:`ReplayFormatError` on a file that is not a CrewRift replay, is
    truncated, or carries a record type this reader does not know -- never a partial
    result, because a partial result is indistinguishable from a real one.
    """
    path = Path(path)
    c = _Cursor(_decompressed(path.read_bytes(), path.name), path.name)
    c.off = len(MAGIC)

    format_version = c.u16()
    game_name = c.s()
    game_version = c.s()
    timestamp_ms = c.u64()
    try:
        config = json.loads(c.s())
    except json.JSONDecodeError as e:
        raise ReplayFormatError(f"{path.name}: config is not JSON") from e

    info = ReplayInfo(
        episode_id=path.stem,
        game_name=game_name,
        game_version=game_version,
        format_version=format_version,
        timestamp_ms=timestamp_ms,
        config=config,
    )
    joins: list[Join] = []

    while c.off < len(c.buf):
        start = c.off
        kind = c.u8()
        if kind == REC_TICK_HASH:
            tick = c.u32()
            c.u64()
            info.duration_ticks = max(info.duration_ticks, tick)
        elif kind == REC_INPUT:
            c.u32(), c.u8(), c.u8()
            info.n_inputs += 1
        elif kind == REC_JOIN:
            joins.append(Join(ms=c.u32(), player=c.u8(), name=c.s(), slot=c.i16(), token=c.s()))
            info.n_joins += 1
        elif kind == REC_LEAVE:
            c.u32(), c.u8()
            info.n_leaves += 1
        elif kind == REC_CHAT:
            c.u32(), c.u8(), c.s()
            info.n_chats += 1
        elif kind == REC_DEBUG_SPRITE:
            c.u32(), c.u8()
            c.skip(c.u32())  # the policy's own debug overlay; we only count it
            info.n_debug_sprites += 1
        else:
            raise ReplayFormatError(
                f"{path.name}: unknown record type 0x{kind:02x} at byte {start} of "
                f"{len(c.buf)}. Records are not length-prefixed, so nothing after this "
                "point can be read; the parse so far is a truncation, not a result."
            )

    if c.off != len(c.buf):
        raise ReplayFormatError(
            f"{path.name}: {len(c.buf) - c.off} trailing bytes after the last record"
        )

    # A join with slot < 0 never took a seat -- keep it out of the roster rather than
    # aliasing it onto a real slot (which is what folding it in by join order would do).
    for j in joins:
        if j.slot >= 0:
            info.roster[j.slot] = j.name
        else:
            info.spectators.append(j)
    if not info.roster:  # nobody joined (a lobby that never filled): fall back to the config
        for slot, player in enumerate(config.get("players") or []):
            info.roster[slot] = (player or {}).get("name", "")
    return info
