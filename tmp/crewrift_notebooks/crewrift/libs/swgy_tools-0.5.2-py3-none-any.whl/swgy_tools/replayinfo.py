"""``swgy-replay-info``: who played, what config, how long -- straight from a ``.replay``.

No game build, no re-simulation, no network. This is the only thing in the package that
reads a replay file directly, and it is deliberately limited to what is actually in
there: the roster (slot -> policy), the game config, and the length of the game. Roles,
tasks, kills and positions are **not** in a replay -- for those, see ``swgy-task-report``
and ``swgy-spatial``, which re-simulate via the game's ``expand_replay``.

    uv run swgy-replay-info game.replay
    uv run swgy-replay-info replays/ --format csv -o episodes.csv
"""

from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

from .replayfile import ReplayFormatError, read_replay

COLS = [
    "episode_id",
    "game_version",
    "seed",
    "n_players",
    "duration_ticks",
    "n_inputs",
    "n_chats",
    "n_joins",
    "n_leaves",
    "n_debug_sprites",
    "imposter_count",
    "tasks_per_player",
]


def _row(info) -> dict:
    return {
        "episode_id": info.episode_id,
        "game_version": info.game_version,
        "seed": info.seed,
        "n_players": len(info.roster),
        "duration_ticks": info.duration_ticks,
        "n_inputs": info.n_inputs,
        "n_chats": info.n_chats,
        "n_joins": info.n_joins,
        "n_leaves": info.n_leaves,
        "n_debug_sprites": info.n_debug_sprites,
        "imposter_count": info.imposter_count,
        "tasks_per_player": info.tasks_per_player,
    }


def collect(inputs: list[str], glob: str) -> list[Path]:
    out: list[Path] = []
    for item in inputs:
        p = Path(item)
        out.extend(sorted(p.glob(glob)) if p.is_dir() else [p])
    return out


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        prog="swgy-replay-info",
        description="Read a CrewRift replay offline: roster, config, duration. No game build.",
    )
    p.add_argument("inputs", nargs="+", help="replay file(s) or a directory")
    p.add_argument("--format", choices=("text", "csv"), default="text", help="output format")
    p.add_argument("-o", "--out", help="output file (default: stdout)")
    p.add_argument("--glob", default="*.replay", help="glob for files inside a directory")
    args = p.parse_args(argv)

    files = collect(args.inputs, args.glob)
    if not files:
        raise SystemExit(f"no inputs found (looked for {args.glob!r} in {args.inputs}).")

    out = Path(args.out).open("w") if args.out else sys.stdout
    writer = None
    if args.format == "csv":
        writer = csv.DictWriter(out, fieldnames=COLS)
        writer.writeheader()

    n_ok = n_err = 0
    try:
        for f in files:
            try:
                info = read_replay(f)
            except ReplayFormatError as e:
                print(f"skip {f.name}: {e}", file=sys.stderr)
                n_err += 1
                continue
            n_ok += 1
            if writer:
                writer.writerow(_row(info))
                continue
            out.write(
                f"{info.episode_id}   {info.duration_ticks} ticks   seed {info.seed}   "
                f"{len(info.roster)} players / {info.imposter_count} imposters\n"
            )
            for slot in sorted(info.roster):
                out.write(f"    slot {slot}  {info.roster[slot]}\n")
            if info.spectators:
                out.write(f"    ({len(info.spectators)} spectator join(s), no slot)\n")
            out.write("\n")
    finally:
        if out is not sys.stdout:
            out.close()

    if not n_ok:
        raise SystemExit(f"no readable replays ({n_err} failed).")
    if len(files) > 1:
        print(f"read {n_ok} replays ({n_err} failed)", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
