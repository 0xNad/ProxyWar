"""Parse ``expand_replay`` JSONL into a per-episode spatial record.

The input is the newline-delimited JSON emitted by the CrewRift game repo's
``tools/expand_replay.nim`` run in snapshot mode::

    expand_replay --format jsonl --snapshot-every N <replay.bitreplay>

Each line is an envelope ``{"ts": tick, "player": slot, "key": ..., "value": ...}``.
This module consumes only the rows the spatial analysis needs and returns an
:class:`EpisodeSpatial`; it does **not** re-simulate anything. If you have a raw
``.bitreplay`` and no JSONL, generate the JSONL with ``expand_replay`` first --
the per-tick positions/kills/bodies here come entirely from its snapshot output.

Positions are the engine's authoritative ``(x, y)`` (the sim's collision point),
so -- unlike a live ``sprite_v1`` frame -- they need no view->collision offset.
"""

from __future__ import annotations

import json
from collections.abc import Iterable, Iterator
from dataclasses import dataclass, field

PLAYING = "Playing"


class EventlogError(ValueError):
    """Raised when the JSONL is not usable expand_replay snapshot output."""


@dataclass
class Kill:
    """One kill: exact tick + killer/victim, located at the body's position."""

    tick: int
    killer_slot: int
    victim_slot: int
    x: int
    y: int
    room: str


@dataclass
class Body:
    """A corpse and how long it stayed undiscovered (a meeting clears bodies)."""

    victim_slot: int
    killer_slot: int
    x: int
    y: int
    room: str
    kill_tick: int
    cleared_tick: int  # -1 == never discovered (game ended first)
    undiscovered_ticks: int
    reported: bool  # the clearing meeting was called by reporting THIS body


@dataclass
class Sighting:
    """One interval during which ``observer`` had line of sight to ``target``.

    This is the engine's own raycast, not a reconstruction: the row carries
    ``visibility_basis: "rendered_view"`` and ``boundary_precision: "exact"``. It is
    the ground truth for "was that kill witnessed" -- and for a crew policy, for "was
    I ever alone".
    """

    observer_slot: int
    observer_role: str
    target_kind: str  # "player" | "body"
    target_slot: int
    tick_start: int
    tick_end: int
    room: str
    x: int
    y: int

    def spans(self, tick: int) -> bool:
        return self.tick_start <= tick <= self.tick_end


# Per-tick sample. The trailing fields were on the wire all along and used to be
# dropped on the floor; active_task is what lets a task leg tell travel from the
# 72-tick completion hold, and vent_cooldown is the only signal a vent was used
# (the event stream has no vent event at all).
POSITION_FIELDS = (
    "tick",
    "slot",
    "x",
    "y",
    "alive",
    "imposter",
    "active_task",
    "vel_x",
    "vel_y",
    "kill_cooldown",
    "vent_cooldown",
)


@dataclass
class EpisodeSpatial:
    """Everything the spatial builder needs from one replay's JSONL."""

    episode_id: str
    map_w: int
    map_h: int
    hash_ok: bool
    fail_tick: int
    end_tick: int
    roster: dict[int, str] = field(default_factory=dict)  # slot -> policy name
    # per-tick samples, in POSITION_FIELDS order
    positions: list[tuple] = field(default_factory=list)
    kills: list[Kill] = field(default_factory=list)
    bodies: list[Body] = field(default_factory=list)
    sightings: list[Sighting] = field(default_factory=list)
    tasks: list[tuple[int, int]] = field(default_factory=list)  # station centres
    vents: list[tuple[int, int]] = field(default_factory=list)  # vent centres


def _centres(rects: list[dict]) -> list[tuple[int, int]]:
    """Centre points of 14x14 authored rects (``x``/``y`` are the top-left)."""
    return [(int(r["x"]) + int(r["w"]) // 2, int(r["y"]) + int(r["h"]) // 2) for r in rects]


def _rows(lines: Iterable[str]) -> Iterator[dict]:
    for line in lines:
        line = line.strip()
        if not line:
            continue
        try:
            yield json.loads(line)
        except json.JSONDecodeError:
            continue


def parse_episode(
    lines: Iterable[str],
    *,
    episode_id: str,
    all_phases: bool = False,
) -> EpisodeSpatial:
    """Parse one episode's expand_replay JSONL into an :class:`EpisodeSpatial`.

    ``all_phases`` keeps position samples from every phase; by default only the
    ``Playing`` phase is kept (lobby/voting positions are off to the side).

    Raises :class:`EventlogError` if the stream has no ``map_geometry`` or no
    ``player_state`` rows -- the signal that the input was not produced by
    ``expand_replay --format jsonl --snapshot-every N``.
    """
    map_w = map_h = 0
    tasks: list[tuple[int, int]] = []
    vents: list[tuple[int, int]] = []
    roster: dict[int, str] = {}
    positions: list[tuple] = []
    sightings: list[Sighting] = []
    kill_events: dict[int, tuple[int, int]] = {}  # victim -> (tick, killer)
    body_loc: dict[int, dict] = {}  # victim -> first body_state seen
    meetings: list[tuple[int, int]] = []  # (tick, reported_victim or -1)
    last_pos: dict[int, tuple[int, int]] = {}
    end_tick = 0
    hash_ok = True
    fail_tick = -1
    saw_state = False

    for row in _rows(lines):
        key = row.get("key")
        ts = int(row.get("ts", 0))
        slot = int(row.get("player", -1))
        val = row.get("value") or {}
        if ts > end_tick:
            end_tick = ts

        if key == "map_geometry":
            map_w, map_h = int(val.get("width", 0)), int(val.get("height", 0))
            tasks = _centres(val.get("tasks", []))
            vents = _centres(val.get("vents", []))
        elif key == "player_manifest":
            # value.address is the join name = the policy/uploader label.
            roster[slot] = str(val.get("address") or val.get("label") or "")
        elif key == "player_joined":
            roster.setdefault(slot, str(val.get("label") or ""))
        elif key == "player_state":
            saw_state = True
            x, y = int(val.get("x", 0)), int(val.get("y", 0))
            last_pos[slot] = (x, y)
            if all_phases or val.get("phase") == PLAYING:
                positions.append(
                    (
                        ts,
                        slot,
                        x,
                        y,
                        bool(val.get("alive", True)),
                        val.get("role") == "imposter",
                        int(val.get("active_task", -1)),
                        int(val.get("vel_x", 0)),
                        int(val.get("vel_y", 0)),
                        int(val.get("kill_cooldown", 0)),
                        int(val.get("vent_cooldown", 0)),
                    )
                )
        elif key == "kill":
            kill_events[int(val.get("victim_slot", -1))] = (ts, slot)
        elif key == "body_state":
            victim = int(val.get("victim_slot", slot))
            body_loc.setdefault(
                victim,
                {
                    "x": int(val.get("x", 0)),
                    "y": int(val.get("y", 0)),
                    "room": str(val.get("room", "")),
                    "kill_tick": int(val.get("kill_tick", ts)),
                    "killer_slot": int(val.get("killer_slot", -1)),
                },
            )
        elif key == "vote_called_body":
            meetings.append((ts, int(val.get("body_owner_slot", -1))))
        elif key == "vote_called_button":
            meetings.append((ts, -1))
        elif key == "player_visible_interval":
            sightings.append(
                Sighting(
                    observer_slot=int(val.get("observer_slot", -1)),
                    observer_role=str(val.get("observer_role", "")),
                    target_kind=str(val.get("target_kind", "player")),
                    target_slot=int(val.get("target_slot", -1)),
                    tick_start=int(val.get("tick_start", ts)),
                    tick_end=int(val.get("tick_end", ts)),
                    room=str(val.get("room", "")),
                    x=int(val.get("x", 0)),
                    y=int(val.get("y", 0)),
                )
            )
        elif key == "trace_complete":
            hash_ok = bool(val.get("complete", True))
            fail_tick = int(val.get("fail_tick", -1))

    if map_w == 0 or not saw_state:
        raise EventlogError(
            f"{episode_id}: no per-tick snapshot rows found (map_geometry/player_state "
            "missing). This analysis consumes coworld-crewrift `expand_replay --format "
            "jsonl --snapshot-every N <replay>` output; regenerate the input with a "
            "positive --snapshot-every."
        )

    meetings.sort()
    kills, bodies = _resolve_kills_bodies(
        kill_events, body_loc, meetings, last_pos, positions, end_tick
    )
    return EpisodeSpatial(
        episode_id=episode_id,
        map_w=map_w,
        map_h=map_h,
        hash_ok=hash_ok,
        fail_tick=fail_tick,
        end_tick=end_tick,
        roster=roster,
        positions=positions,
        kills=kills,
        bodies=bodies,
        sightings=sightings,
        tasks=tasks,
        vents=vents,
    )


def _victim_pos_before(
    victim: int,
    tick: int,
    last_pos: dict[int, tuple[int, int]],
    positions: list[tuple[int, int, int, int, bool, bool]],
) -> tuple[int, int]:
    """Best-effort corpse location when no body_state was sampled (rare, stride>1)."""
    best: tuple[int, int] | None = None
    best_tick = -1
    for pt, ps, px, py, _alive, _imp in positions:
        if ps == victim and pt <= tick and pt > best_tick:
            best_tick, best = pt, (px, py)
    return best or last_pos.get(victim, (0, 0))


def _resolve_kills_bodies(
    kill_events: dict[int, tuple[int, int]],
    body_loc: dict[int, dict],
    meetings: list[tuple[int, int]],
    last_pos: dict[int, tuple[int, int]],
    positions: list[tuple[int, int, int, int, bool, bool]],
    end_tick: int,
) -> tuple[list[Kill], list[Body]]:
    kills: list[Kill] = []
    bodies: list[Body] = []
    for victim in sorted(set(kill_events) | set(body_loc)):
        loc = body_loc.get(victim)
        ev = kill_events.get(victim)
        kill_tick = loc["kill_tick"] if loc else (ev[0] if ev else 0)
        killer = loc["killer_slot"] if loc else -1
        if killer < 0 and ev:
            killer = ev[1]
        if loc:
            x, y, room = loc["x"], loc["y"], loc["room"]
        else:
            x, y = _victim_pos_before(victim, kill_tick, last_pos, positions)
            room = ""
        kills.append(Kill(kill_tick, killer, victim, x, y, room))

        cleared_tick, reported = -1, False
        for mt, reported_victim in meetings:
            if mt > kill_tick:
                cleared_tick = mt
                reported = reported_victim == victim
                break
        undiscovered = (cleared_tick if cleared_tick >= 0 else end_tick) - kill_tick
        bodies.append(
            Body(victim, killer, x, y, room, kill_tick, cleared_tick, undiscovered, reported)
        )
    return kills, bodies
