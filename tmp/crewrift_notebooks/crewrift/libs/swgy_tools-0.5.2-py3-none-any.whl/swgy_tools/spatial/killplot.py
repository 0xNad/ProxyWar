"""Trace a kill: the victim's and the killer's paths over the window before it.

The heatmaps aggregate; the swimlanes tell you *when*. This tells one kill's story on
the map -- where the killer came from, where the victim was going, and where the two
met. An arrow for each step they moved, a ``+`` where they stood still (bigger = longer),
a ring at the start of the trail, a star at the end, and a cross at the kill.

Reads a ``swgy-spatial`` build (``positions/<episode>.npz`` + ``kills.csv``). Positions
only exist there if the JSONL was produced with ``expand_replay --snapshot-every N``,
and N *is* the resolution of the trail -- use 1 for a smooth one.

:func:`plot_kill` takes and returns an ``ax`` so it can be composed into someone else's
figure (a notebook cell, a multi-panel sheet); :func:`render_kill` is the wrapper that
owns a figure and writes a PNG.
"""

from __future__ import annotations

from pathlib import Path

from ..plotstyle import (
    ALIVE,
    DEATH,
    EDGE,
    GHOST,
    INK,
    MEETING,
    MUTED,
    PAGE,
    SECONDARY,
    croatoan_axes,
)
from .build import episode_tracks, load_episode_positions, load_kills

# The engine's ReplayFps (coworld-crewrift `src/crewrift/sim.nim`: `ReplayFps* = 24`).
# Not derived from the data: inputs stop before the game does, so any ratio taken from
# the replay overestimates it.
TICKS_PER_SECOND = 24

VICTIM = ALIVE  # blue: the crew subject, as in the swimlanes
KILLER = MEETING  # amber: maximal separation from both blue and the red kill mark
KILL = DEATH  # red cross: the same glyph and colour a kill has everywhere else
WITNESS = GHOST  # aqua: a third party who had line of sight to the killer
# All four are the validated set (worst adjacent CVD dE 20.7 on the dark surface).


def witnesses(sightings: list[dict], kill: dict) -> set[int]:
    """Slots that could actually SEE the killer at the moment of the kill.

    Not inferred from distance or geometry: ``visibility.csv`` is the engine's own
    raycast (``visibility_basis: "rendered_view"``, ``boundary_precision: "exact"``).
    The killer and the victim are excluded -- the question is who *else* saw it.

    This is the imposter's most actionable number. Across 97 league kills, 48% were
    witnessed -- and 81% of the ones in the Bridge, which is also where imposters kill
    most often.
    """
    return {
        s["observer_slot"]
        for s in sightings
        if s["target_slot"] == kill["killer_slot"]
        and s["observer_slot"] not in (kill["killer_slot"], kill["victim_slot"])
        and s["tick_start"] <= kill["tick"] <= s["tick_end"]
    }


def slots_at(data_dir, episode_id: str, tick: int) -> dict[int, tuple[int, int, bool]]:
    """``{slot: (x, y, alive)}`` for every player at ``tick`` (nearest sample at or before)."""
    c = load_episode_positions(data_dir, episode_id)
    out: dict[int, tuple[int, int, bool, int]] = {}
    for t, s, x, y, a in zip(c["tick"], c["slot"], c["x"], c["y"], c["alive"], strict=True):
        t, s = int(t), int(s)
        if t <= tick and (s not in out or t > out[s][3]):
            out[s] = (int(x), int(y), bool(a), t)
    return {s: (x, y, a) for s, (x, y, a, _) in out.items()}


def sample_track(
    track: dict[int, tuple[int, int]], end_tick: int, window_ticks: int, step: int
) -> list[tuple[int, int, int]]:
    """``[(tick, x, y)]`` for one player over the window ending at ``end_tick``.

    ``step`` must be a multiple of the build's stride or every sample misses.
    """
    start = max(0, end_tick - window_ticks)
    out = []
    t = start + (end_tick - start) % step
    while t <= end_tick:
        if t in track:
            out.append((t, *track[t]))
        t += step
    return out


def draw_track(ax, samples: list[tuple[int, int, int]], color: str, step: int) -> None:
    """Draw one player's trail: arrows where they moved, ``+`` where they stood still."""
    if not samples:
        return
    n, i = len(samples), 0
    while i < n - 1:
        t, x, y = samples[i]
        nt, nx, ny = samples[i + 1]

        # A jump in ticks is not a walk. Positions are sampled during play only, so a
        # meeting (everyone teleported to the Bridge) shows up as a hole in the series.
        # Drawing an arrow across it would invent a route across the map that never
        # happened -- the same lie as joining two task stations with a straight line.
        if nt - t > step:
            i += 1
            continue

        dx, dy = nx - x, ny - y
        if dx == 0 and dy == 0:  # collapse a stationary run into one +
            run = 1
            while i + run < n - 1:
                _, rx, ry = samples[i + run]
                _, rnx, rny = samples[i + run + 1]
                if (rnx - rx, rny - ry) != (0, 0):
                    break
                run += 1
            ax.scatter(
                [x],
                [y],
                marker="P",
                c=color,
                s=min(70 + 28 * run, 460),
                zorder=4,
                edgecolors=EDGE,
                linewidths=0.5,
            )
            i += run
        else:
            norm = (dx * dx + dy * dy) ** 0.5
            length = max(9.0, 13.0 * step / TICKS_PER_SECOND)
            ax.annotate(
                "",
                xy=(x + dx / norm * length, y + dy / norm * length),
                xytext=(x, y),
                arrowprops={
                    "arrowstyle": "-|>",
                    "color": color,
                    "lw": 1.4,
                    "mutation_scale": 9,
                    "shrinkA": 0,
                    "shrinkB": 0,
                },
                zorder=5,
            )
            i += 1

    ax.scatter(
        [samples[0][1]],
        [samples[0][2]],
        marker="o",
        facecolors="none",
        edgecolors=color,
        s=170,
        linewidths=2.0,
        zorder=9,
    )
    ax.scatter(
        [samples[-1][1]],
        [samples[-1][2]],
        marker="*",
        c=color,
        s=250,
        zorder=6,
        edgecolors=EDGE,
        linewidths=0.5,
    )


def plot_kill(
    kill: dict,
    tracks: dict[int, dict[int, tuple[int, int]]],
    stride: int,
    *,
    ax,
    others: dict[int, tuple[int, int, bool]] | None = None,
    sightings: list[dict] | None = None,
    map_w: int = 1235,
    map_h: int = 659,
    window_s: float = 30.0,
    interval_s: float = 0.5,
):
    """Draw one kill onto ``ax`` and return it.

    ``kill`` is a row from ``kills.csv``; ``tracks``/``stride`` come from
    :func:`swgy_tools.spatial.build.episode_tracks`. Sampling is snapped to the build's
    stride, so a coarse build draws a coarse trail rather than an empty one.
    """
    croatoan_axes(ax, map_w, map_h)
    ax.set_xticks([])
    ax.set_yticks([])
    for s in ax.spines.values():
        s.set_visible(False)

    step = max(stride, round(interval_s * TICKS_PER_SECOND / stride) * stride)
    window = round(window_s * TICKS_PER_SECOND)

    draw_track(
        ax,
        sample_track(tracks.get(kill["victim_slot"], {}), kill["tick"], window, step),
        VICTIM,
        step,
    )
    if kill["killer_slot"] >= 0:
        draw_track(
            ax,
            sample_track(tracks.get(kill["killer_slot"], {}), kill["tick"], window, step),
            KILLER,
            step,
        )
    # Who else was on the ship, and who could actually see the killer do it.
    if others:
        saw = witnesses(sightings or [], kill)
        for slot, (x, y, alive) in others.items():
            if slot in (kill["killer_slot"], kill["victim_slot"]) or not alive:
                continue
            if slot in saw:
                ax.scatter(
                    [x],
                    [y],
                    marker="o",
                    s=150,
                    facecolors="none",
                    edgecolors=WITNESS,
                    linewidths=2.2,
                    zorder=8,
                )
                # the sightline. It existed: the engine says so.
                ax.plot([x, kill["x"]], [y, kill["y"]], color=WITNESS, lw=1.2, alpha=0.55, zorder=7)
            else:
                ax.scatter(
                    [x],
                    [y],
                    marker="o",
                    s=60,
                    facecolors="none",
                    edgecolors=MUTED,
                    linewidths=1.2,
                    alpha=0.7,
                    zorder=6,
                )

    ax.scatter([kill["x"]], [kill["y"]], marker="x", c=KILL, s=150, linewidths=2.8, zorder=10)
    return ax


def render_kill(
    kill: dict,
    tracks,
    stride: int,
    out: str | Path,
    *,
    others: dict[int, tuple[int, int, bool]] | None = None,
    sightings: list[dict] | None = None,
    window_s: float = 30.0,
    dpi: int = 160,
) -> Path:
    """Own a figure, draw the kill, write a PNG."""
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D

    saw = witnesses(sightings or [], kill) if others else set()
    fig, ax = plt.subplots(figsize=(13, 7.4), facecolor=PAGE)
    plot_kill(kill, tracks, stride, ax=ax, others=others, sightings=sightings, window_s=window_s)
    seen = (
        f"SEEN by {len(saw)} other player{'s' if len(saw) != 1 else ''}"
        if saw
        else "clean — nobody had line of sight to the killer"
    )
    ax.set_title(
        f"{kill['victim_policy']} killed by {kill['killer_policy']}  ·  "
        f"{kill['room']}  ·  tick {kill['tick']}  ·  {seen}",
        color=KILL if saw else INK,
        fontsize=12,
        loc="left",
        pad=10,
    )
    ax.legend(
        handles=[
            Line2D(
                [],
                [],
                marker="o",
                ls="",
                mfc="none",
                mec=VICTIM,
                mew=2,
                ms=9,
                label=f"victim — {kill['victim_policy']}",
            ),
            Line2D(
                [],
                [],
                marker="o",
                ls="",
                mfc="none",
                mec=KILLER,
                mew=2,
                ms=9,
                label=f"killer — {kill['killer_policy']}",
            ),
            Line2D([], [], marker="x", ls="", color=KILL, mew=2.4, ms=9, label="the kill"),
            Line2D([], [], marker="P", ls="", color=SECONDARY, ms=9, label="stood still"),
            Line2D(
                [],
                [],
                marker="o",
                ls="",
                mfc="none",
                mec=WITNESS,
                mew=2,
                ms=9,
                label="saw the killer (engine line-of-sight)",
            ),
            Line2D(
                [],
                [],
                marker="o",
                ls="",
                mfc="none",
                mec=MUTED,
                mew=1.2,
                ms=7,
                label="present, no line of sight",
            ),
        ],
        loc="lower right",
        frameon=False,
        fontsize=8.5,
        labelcolor=SECONDARY,
    )
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out, dpi=dpi, facecolor=PAGE, bbox_inches="tight", pad_inches=0.12)
    plt.close(fig)
    return out


def wander(kill: dict, tracks, stride: int, window_s: float = 30.0) -> float:
    """How far the killer travelled before the kill -- a chase reads better than a camper."""
    s = sample_track(
        tracks.get(kill["killer_slot"], {}),
        kill["tick"],
        round(window_s * TICKS_PER_SECOND),
        max(stride, TICKS_PER_SECOND),
    )
    return sum(abs(b[1] - a[1]) + abs(b[2] - a[2]) for a, b in zip(s, s[1:], strict=False))


def pick_kill(data_dir: str | Path, episode_id: str | None = None) -> tuple[dict, dict, int]:
    """The most interesting kill in the build (the killer who travelled furthest)."""
    kills = load_kills(data_dir, episode_id)
    if not kills:
        raise SystemExit(
            f"no kills in {Path(data_dir).resolve()}"
            + (f" for episode {episode_id!r}" if episode_id else "")
        )
    best = None
    for k in kills:
        try:
            tracks, stride = episode_tracks(data_dir, k["episode_id"])
        except FileNotFoundError:
            continue  # kills.csv is corpus-wide; positions may not be
        score = wander(k, tracks, stride)
        if best is None or score > best[0]:
            best = (score, k, tracks, stride)
    if best is None:
        raise SystemExit(f"no episode in {Path(data_dir).resolve()} has both kills and positions.")
    return best[1], best[2], best[3]
