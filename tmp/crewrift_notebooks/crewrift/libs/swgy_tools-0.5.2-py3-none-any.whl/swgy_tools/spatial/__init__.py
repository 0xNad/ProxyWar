"""CrewRift spatial replay analysis: per-tick positions, kills, bodies, heatmaps.

Consumes **``expand_replay --format jsonl --snapshot-every N``** output from the
CrewRift game repo (``coworld-crewrift``) -- it does not re-simulate replays. The
raw ``.bitreplay`` file alone is not enough; you must generate the snapshot JSONL
with ``expand_replay`` first, and this package turns that into datasets + heatmaps.

- :mod:`swgy_tools.spatial.eventlog` -- parse one episode's JSONL.
- :mod:`swgy_tools.spatial.build`   -- write positions / kills / bodies / heatmap grids.
- :mod:`swgy_tools.spatial.render`  -- render the heatmap grids to PNGs (imaging.py).
- console scripts: ``swgy-spatial`` (build + render), ``swgy-spatial-render``.
"""

from __future__ import annotations
