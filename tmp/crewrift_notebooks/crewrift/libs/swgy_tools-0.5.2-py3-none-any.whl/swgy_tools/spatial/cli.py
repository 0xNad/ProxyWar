"""``swgy-spatial``: build CrewRift spatial datasets + heatmaps from replays.

The input is **``expand_replay`` snapshot JSONL**, not raw ``.bitreplay`` files.
Generate it from the CrewRift game repo (``coworld-crewrift``) first::

    nim r tools/expand_replay.nim --format jsonl --snapshot-every 1 \
        game.bitreplay > game.jsonl

then build the datasets + heatmaps::

    uv run swgy-spatial game.jsonl -o out            # one episode
    uv run swgy-spatial jsonl_dir/ -o out            # a directory of *.jsonl

Outputs land in ``out/spatial/`` (positions, kills.csv, bodies.csv, heatmaps.npz,
heatmaps/*.png). ``swgy-spatial-render`` re-renders the PNGs from an existing
build. Per-tick positions/kills/bodies come entirely from expand_replay's
snapshot output -- without it there is nothing to analyse.
"""

from __future__ import annotations

import argparse
import sys

from .build import build
from .render import render


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Build CrewRift spatial datasets from expand_replay JSONL."
    )
    p.add_argument(
        "inputs",
        nargs="+",
        help="expand_replay JSONL file(s) or a directory of them (one episode per file)",
    )
    p.add_argument("-o", "--out", default="data", help="output dir (writes <out>/spatial/)")
    p.add_argument(
        "--stride",
        type=int,
        default=1,
        help="the --snapshot-every used to GENERATE the JSONL (documentation only)",
    )
    p.add_argument("--cell", type=int, default=8, help="heatmap grid cell size in px (default 8)")
    p.add_argument(
        "--all-phases",
        action="store_true",
        help="keep position samples from every phase (default: Playing only)",
    )
    p.add_argument("--no-render", action="store_true", help="skip PNG heatmap rendering")
    p.add_argument("--glob", default="*.jsonl", help="glob for JSONL files inside a directory")
    args = p.parse_args(argv)

    build(args.inputs, args.out, cell=args.cell, all_phases=args.all_phases, glob=args.glob)
    if not args.no_render:
        n = render(args.out)
        print(f"rendered {n} heatmap PNGs -> {args.out}/spatial/heatmaps", file=sys.stderr)
    return 0


def render_main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Render heatmap PNGs from an existing spatial build.")
    p.add_argument("data_dir", nargs="?", default="data", help="dir holding <data>/spatial/")
    p.add_argument("--dpi", type=int, default=130, help="output resolution (default 130)")
    args = p.parse_args(argv)
    n = render(args.data_dir, dpi=args.dpi)
    print(f"rendered {n} heatmap PNGs -> {args.data_dir}/spatial/heatmaps", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


def killplot_main(argv: list[str] | None = None) -> int:
    """``swgy-kill-plot``: trace one kill's victim/killer paths over the Croatoan map."""
    from .build import episode_tracks
    from .killplot import pick_kill, render_kill

    p = argparse.ArgumentParser(
        prog="swgy-kill-plot",
        description="Trace a kill: victim + killer paths over the window before it.",
        epilog="Needs a swgy-spatial build whose JSONL was made with "
        "`expand_replay --format jsonl --snapshot-every 1` -- that is what carries the "
        "position rows, and the snapshot stride is the resolution of the trail.",
    )
    p.add_argument("data_dir", help="a swgy-spatial build (the dir holding spatial/)")
    p.add_argument("--episode", help="episode id (default: the most interesting kill in the build)")
    p.add_argument("--slot", type=int, help="victim slot, when an episode has several kills")
    p.add_argument("-o", "--out", default="tmp/kill.png", help="output PNG")
    p.add_argument("--window", type=float, default=30.0, help="seconds of history to trace")
    p.add_argument("--dpi", type=int, default=160, help="output resolution")
    p.add_argument(
        "--no-witnesses",
        action="store_true",
        help="omit the other players and their sightlines (draw only the two trails)",
    )
    args = p.parse_args(argv)

    kill, tracks, stride = pick_kill(args.data_dir, args.episode)
    if args.slot is not None:
        from .build import load_kills

        match = [
            k for k in load_kills(args.data_dir, args.episode) if k["victim_slot"] == args.slot
        ]
        if not match:
            raise SystemExit(f"no kill of slot {args.slot} in episode {args.episode!r}.")
        kill = match[0]
        tracks, stride = episode_tracks(args.data_dir, kill["episode_id"])

    from .build import load_sightings
    from .killplot import slots_at, witnesses

    others = sights = None
    if not args.no_witnesses:
        try:
            sights = load_sightings(args.data_dir, kill["episode_id"])
            others = slots_at(args.data_dir, kill["episode_id"], kill["tick"])
        except FileNotFoundError as e:
            print(f"no witness data ({e}); drawing the kill without it", file=sys.stderr)

    out = render_kill(
        kill,
        tracks,
        stride,
        args.out,
        others=others,
        sightings=sights,
        window_s=args.window,
        dpi=args.dpi,
    )
    if sights is not None:
        saw = witnesses(sights, kill)
        print(
            f"  witnessed by {len(saw)} other player(s)"
            if saw
            else "  clean kill: nobody had line of sight to the killer",
            file=sys.stderr,
        )
    print(
        f"{kill['victim_policy']} killed by {kill['killer_policy']} in {kill['room']} "
        f"@ tick {kill['tick']} (stride {stride}) -> {out}",
        file=sys.stderr,
    )
    return 0
