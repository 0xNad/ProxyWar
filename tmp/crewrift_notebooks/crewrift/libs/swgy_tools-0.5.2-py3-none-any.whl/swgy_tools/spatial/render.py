"""Render the ``heatmaps.npz`` grids to labelled PNGs.

The layer functions (:func:`density_layer`, :func:`imposter_share_layer`,
:func:`bodyhide_layer`) are public: each returns ``(rgba, norm, cmap)`` for one grid, so
a notebook can compose its own figure over :func:`swgy_tools.plotstyle.basemap` instead
of re-deriving the colour maths -- which is how three copies of it came to exist.

Reads ``<data>/spatial/heatmaps.npz`` + ``geometry.json`` (both written by
:mod:`swgy_tools.spatial.build`) and writes ``<data>/spatial/heatmaps/*.png``:
occupancy (all / crew / imposter / per-policy), kill density, an imposter-"tell"
diverging map, and a body-undiscovered map -- each blurred, colour-mapped over a
desaturated Croatoan basemap, marked with task/vent landmarks, and carrying a title
and a **colorbar**, because a heat map with no scale is decoration.

This used to render through :mod:`swgy_tools.imaging` specifically to avoid a
matplotlib dependency, and paid for that with having no text at all -- no titles, no
colorbar numbers. The package now depends on matplotlib anyway (for the task charts),
so the trade bought nothing. ``imaging.py`` stays for the nav renders, which want exact
map-pixel output and no chrome.
"""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")  # headless: render to file, never to a window

import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from matplotlib.colors import LogNorm, Normalize, TwoSlopeNorm  # noqa: E402

from ..plotstyle import (  # noqa: E402
    INK,
    MUTED,
    PAGE,
    SECONDARY,
    TASK_MARK,
    VENT_MARK,
    basemap,
)
from .build import load_heatmaps  # noqa: E402

TASK_C = TASK_MARK
VENT_C = VENT_MARK

# Two imposters in eight players. The diverging map is centred here, so a cell reads
# hot only where imposters are over-represented *relative to that base rate* -- not
# merely where an imposter happened to walk.
IMPOSTER_BASE = 0.25


def gaussian_blur(g: np.ndarray, sigma: float) -> np.ndarray:
    """Separable Gaussian blur. No scipy -- the kernel is six lines and this is the only use."""
    if sigma <= 0:
        return g
    radius = max(1, int(3 * sigma))
    x = np.arange(-radius, radius + 1, dtype=np.float64)
    k = np.exp(-(x**2) / (2 * sigma * sigma))
    k /= k.sum()
    out = np.apply_along_axis(lambda m: np.convolve(m, k, mode="same"), 0, g.astype(np.float64))
    return np.apply_along_axis(lambda m: np.convolve(m, k, mode="same"), 1, out)


def density_layer(grid: np.ndarray):
    """Blurred log-count -> (rgba, norm, cmap); density is carried by alpha. None if empty."""
    g = gaussian_blur(grid.astype(np.float64), 1.3)
    vmax = float(g.max())
    if vmax <= 0:
        return None
    vmin = vmax / 1000.0  # a 3-decade log scale
    norm = LogNorm(vmin=vmin, vmax=vmax)
    cmap = matplotlib.colormaps["inferno"]
    rgba = cmap(norm(np.clip(g, vmin, vmax)))
    rgba[..., 3] = np.clip(g / vmax, 0, 1) ** 0.5  # fade to nothing where nothing happened
    return rgba, norm, cmap


def imposter_share_layer(crew: np.ndarray, imposter: np.ndarray):
    """Where presence is *disproportionately* imposter. Diverging about the base rate."""
    total = crew + imposter
    if not total.max():
        return None
    seen = total > total.max() / 400.0
    if not seen.any():
        return None
    share = np.zeros_like(total, dtype=np.float64)
    share[seen] = imposter[seen] / total[seen]
    norm = TwoSlopeNorm(vmin=0.0, vcenter=IMPOSTER_BASE, vmax=1.0)
    cmap = matplotlib.colormaps["RdBu_r"]
    rgba = cmap(norm(share))
    rgba[..., 3] = np.where(seen, np.clip(total / total.max(), 0, 1) ** 0.4, 0.0)
    return rgba, norm, cmap


def bodyhide_layer(sum_grid: np.ndarray, count_grid: np.ndarray):
    """Mean ticks a body went undiscovered, per cell -- where a corpse stays hidden."""
    seen = count_grid > 0
    if not seen.any():
        return None
    mean = np.zeros_like(sum_grid, dtype=np.float64)
    mean[seen] = sum_grid[seen] / count_grid[seen]
    mean = gaussian_blur(mean, 1.1)
    vmax = float(mean.max())
    if vmax <= 0:
        return None
    norm = Normalize(vmin=0.0, vmax=vmax)
    cmap = matplotlib.colormaps["inferno"]
    rgba = cmap(norm(mean))
    rgba[..., 3] = np.where(gaussian_blur(seen.astype(np.float64), 1.1) > 0.02, 0.9, 0.0)
    return rgba, norm, cmap


def _landmarks(ax, geom: dict) -> None:
    if geom.get("tasks"):
        ax.scatter(
            *zip(*geom["tasks"], strict=True),
            marker="s",
            s=15,
            facecolors="none",
            edgecolors=TASK_C,
            linewidths=0.8,
            zorder=4,
            label="task station",
        )
    if geom.get("vents"):
        ax.scatter(
            *zip(*geom["vents"], strict=True),
            marker="D",
            s=17,
            facecolors="none",
            edgecolors=VENT_C,
            linewidths=0.9,
            zorder=4,
            label="vent",
        )


def _save(layer, name: str, title: str, cbar: str, geom: dict, out: Path, dpi: int) -> None:
    rgba, norm, cmap = layer
    mw, mh = geom["map_w"], geom["map_h"]
    fig, ax = plt.subplots(figsize=(12.5, 12.5 * mh / mw + 0.8), facecolor=PAGE)

    bg = basemap(0.55)
    if bg is not None:
        ax.imshow(bg, extent=[0, mw, mh, 0], interpolation="bilinear", zorder=0)
    ax.imshow(rgba, extent=[0, mw, mh, 0], interpolation="bilinear", zorder=2)
    _landmarks(ax, geom)

    ax.set_xlim(0, mw)
    ax.set_ylim(mh, 0)  # world y is down
    ax.set_xticks([])
    ax.set_yticks([])
    for s in ax.spines.values():
        s.set_visible(False)
    ax.set_title(title, color=INK, fontsize=12, loc="left", pad=10)
    ax.legend(loc="lower right", frameon=False, fontsize=8, labelcolor=SECONDARY)

    sm = plt.cm.ScalarMappable(norm=norm, cmap=cmap)
    cb = fig.colorbar(sm, ax=ax, fraction=0.028, pad=0.012)
    cb.set_label(cbar, color=SECONDARY, fontsize=8)
    cb.ax.tick_params(colors=MUTED, labelsize=7)
    cb.outline.set_visible(False)

    fig.savefig(out / f"{name}.png", dpi=dpi, facecolor=PAGE, bbox_inches="tight", pad_inches=0.12)
    plt.close(fig)


def render(data_dir: str | Path, *, dpi: int = 130) -> int:
    """Render every grid in ``heatmaps.npz`` to a labelled PNG. Returns the number written."""
    sp = Path(data_dir) / "spatial"
    grids, meta = load_heatmaps(data_dir)
    geom = json.loads((sp / "geometry.json").read_text()) if (sp / "geometry.json").exists() else {}
    geom |= {"map_w": meta["map_w"], "map_h": meta["map_h"]}
    out = sp / "heatmaps"
    out.mkdir(parents=True, exist_ok=True)

    n = 0
    for name, grid in sorted(grids.items()):
        if name in ("bodyhide_sum", "bodyhide_count"):
            continue
        layer = density_layer(grid)
        if layer is None:
            continue
        label = name.replace("policy::", "occupancy — ")
        _save(
            layer,
            name.replace("::", "__"),
            f"CrewRift — {label}",
            "samples per cell (log)",
            geom,
            out,
            dpi,
        )
        n += 1

    if "crew" in grids and "imposter" in grids:
        layer = imposter_share_layer(grids["crew"], grids["imposter"])
        if layer is not None:
            _save(
                layer,
                "imposter_tell",
                "CrewRift — the imposter tell: where presence skews imposter",
                f"imposter share of presence (centred on the {IMPOSTER_BASE:.0%} base rate)",
                geom,
                out,
                dpi,
            )
            n += 1

    if "bodyhide_sum" in grids and "bodyhide_count" in grids:
        layer = bodyhide_layer(grids["bodyhide_sum"], grids["bodyhide_count"])
        if layer is not None:
            _save(
                layer,
                "body_undiscovered",
                "CrewRift — where a body stays hidden longest",
                "mean ticks undiscovered",
                geom,
                out,
                dpi,
            )
            n += 1
    return n
