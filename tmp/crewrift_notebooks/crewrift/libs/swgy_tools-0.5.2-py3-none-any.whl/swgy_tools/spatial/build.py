"""Build spatial datasets from ``expand_replay`` JSONL (one file per episode).

Writes, under ``<out>/spatial/``:

- ``positions/<episode>.npz`` -- per-tick player positions (columnar numpy arrays
  ``tick, slot, x, y, alive, imposter``); ``load_positions`` concatenates them.
- ``kills.csv`` / ``bodies.csv`` -- one row per kill / body (stdlib csv).
- ``heatmaps.npz`` -- pre-binned occupancy grids (all / crew / imposter /
  ``policy::<name>``) plus kill and body-undiscovered grids, with map dims + cell.
- ``roster.json`` -- episode -> {slot: policy}.
- ``spatial_summary.json`` -- kill hotspots + body-undiscovered stats by room.

Input is produced by the CrewRift game repo's ``expand_replay`` (see
:mod:`swgy_tools.spatial.eventlog`); this stage never re-simulates. numpy only --
no pandas / pyarrow.
"""

from __future__ import annotations

import csv
import json
import statistics
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

from ..tasks.eventlog import TaskLogError
from ..tasks.eventlog import parse_episode as parse_tasks
from .eventlog import POSITION_FIELDS, EpisodeSpatial, EventlogError, parse_episode

KILL_COLS = [
    "episode_id",
    "tick",
    "killer_slot",
    "killer_policy",
    "victim_slot",
    "victim_policy",
    "x",
    "y",
    "room",
]
VIS_COLS = [
    "episode_id",
    "observer_slot",
    "observer_role",
    "target_kind",
    "target_slot",
    "tick_start",
    "tick_end",
    "room",
    "x",
    "y",
]
MEETING_COLS = ["episode_id", "start", "end", "kind", "timed_out"]
TASK_COLS = ["episode_id", "slot", "policy", "task", "tick", "room", "while_dead"]
ASSIGN_COLS = ["episode_id", "slot", "policy", "task", "task_order"]
BODY_COLS = [
    "episode_id",
    "victim_slot",
    "victim_policy",
    "x",
    "y",
    "room",
    "kill_tick",
    "cleared_tick",
    "undiscovered_ticks",
    "reported",
]


def collect_inputs(inputs: list[str], glob: str = "*.jsonl") -> list[Path]:
    """Expand file/dir args into a sorted list of JSONL files."""
    out: list[Path] = []
    for item in inputs:
        p = Path(item)
        if p.is_dir():
            out.extend(sorted(p.glob(glob)))
        else:
            out.append(p)
    return out


def load_positions(data_dir: str | Path) -> dict[str, np.ndarray]:
    """Concatenate all ``positions/<episode>.npz`` into one columnar dict.

    Returns arrays keyed ``episode_id, tick, slot, x, y, alive, imposter`` -- the
    layout for "positions across all games across time" scans.
    """
    parts = sorted((Path(data_dir) / "spatial" / "positions").glob("*.npz"))
    cols: dict[str, list] = defaultdict(list)
    for part in parts:
        with np.load(part) as z:
            n = len(z["tick"])
            cols["episode_id"].append(np.array([part.stem] * n, dtype=object))
            for k in POSITION_FIELDS:
                cols[k].append(z[k])
    if not cols:
        return {}
    return {k: np.concatenate(v) for k, v in cols.items()}


def load_episode_positions(data_dir: str | Path, episode_id: str) -> dict[str, np.ndarray]:
    """One episode's ``positions/<episode>.npz`` -> columnar arrays.

    Use this, not :func:`load_positions`, to look at a single game: that one
    concatenates every episode in the build (millions of rows across a corpus) and
    would be an absurd way to draw one thirty-second window.
    """
    path = Path(data_dir) / "spatial" / "positions" / f"{episode_id}.npz"
    if not path.is_file():
        raise FileNotFoundError(
            f"no positions for episode {episode_id!r} in {Path(data_dir).resolve()}. "
            "Either the episode is not in this build, or the build was made from JSONL "
            "without `--snapshot-every N` (which is what carries the position rows)."
        )
    with np.load(path) as z:
        return {k: z[k] for k in POSITION_FIELDS}


def episode_tracks(
    data_dir: str | Path, episode_id: str
) -> tuple[dict[int, dict[int, tuple[int, int]]], int]:
    """``{slot: {tick: (x, y)}}`` for one episode, plus the build's sampling stride.

    The stride is *derived* rather than assumed: positions exist only on the ticks
    ``expand_replay`` sampled, and a caller that guesses wrong (asking for tick 1001 in
    a stride-5 build) silently gets an empty track. Returns the smallest gap between
    consecutive sampled ticks, which is 1 for a ``--snapshot-every 1`` build.
    """
    cols = load_episode_positions(data_dir, episode_id)
    tracks: dict[int, dict[int, tuple[int, int]]] = defaultdict(dict)
    for t, s, x, y in zip(cols["tick"], cols["slot"], cols["x"], cols["y"], strict=True):
        tracks[int(s)][int(t)] = (int(x), int(y))
    ticks = np.unique(cols["tick"])
    stride = int(np.diff(ticks).min()) if len(ticks) > 1 else 1
    return dict(tracks), max(1, stride)


def load_kills(data_dir: str | Path, episode_id: str | None = None) -> list[dict]:
    """Read ``kills.csv`` back, optionally for one episode. Ints are ints."""
    path = Path(data_dir) / "spatial" / "kills.csv"
    if not path.is_file():
        raise FileNotFoundError(
            f"no kills.csv in {Path(data_dir).resolve()} -- is this a build dir?"
        )
    out = []
    with path.open() as fh:
        for row in csv.DictReader(fh):
            if episode_id and row["episode_id"] != episode_id:
                continue
            for k in ("tick", "killer_slot", "victim_slot", "x", "y"):
                row[k] = int(row[k])
            out.append(row)
    return out


def _load_csv(
    data_dir: str | Path, name: str, ints: tuple[str, ...], episode_id: str | None = None
) -> list[dict]:
    path = Path(data_dir) / "spatial" / name
    if not path.is_file():
        raise FileNotFoundError(
            f"no {name} in {Path(data_dir).resolve()} -- rebuild with a current swgy-spatial."
        )
    out = []
    with path.open() as fh:
        for row in csv.DictReader(fh):
            if episode_id and row["episode_id"] != episode_id:
                continue
            for k in ints:
                row[k] = int(row[k])
            out.append(row)
    return out


def load_bodies(data_dir: str | Path, episode_id: str | None = None) -> list[dict]:
    """``bodies.csv``: where each corpse fell and how long it went undiscovered."""
    rows = _load_csv(
        data_dir,
        "bodies.csv",
        ("victim_slot", "x", "y", "kill_tick", "cleared_tick", "undiscovered_ticks"),
        episode_id,
    )
    for r in rows:
        r["reported"] = r["reported"] == "True"  # csv wrote the bool, not 0/1
    return rows


def load_sightings(data_dir: str | Path, episode_id: str | None = None) -> list[dict]:
    """``visibility.csv``: who had line of sight to whom, and when. The engine's raycast."""
    return _load_csv(
        data_dir,
        "visibility.csv",
        ("observer_slot", "target_slot", "tick_start", "tick_end", "x", "y"),
        episode_id,
    )


def load_meetings(data_dir: str | Path, episode_id: str | None = None) -> list[dict]:
    """``meetings.csv``: the spans nobody could touch a task, and whether the vote timed out."""
    return _load_csv(data_dir, "meetings.csv", ("start", "end", "timed_out"), episode_id)


def load_tasks(data_dir: str | Path, episode_id: str | None = None) -> list[dict]:
    """``tasks.csv``: one row per completed task (slot, task, tick, room, while_dead)."""
    return _load_csv(data_dir, "tasks.csv", ("slot", "task", "tick", "while_dead"), episode_id)


def load_assignments(data_dir: str | Path, episode_id: str | None = None) -> list[dict]:
    """``assignments.csv``: the stations each crew member was given, in assignment order."""
    return _load_csv(data_dir, "assignments.csv", ("slot", "task", "task_order"), episode_id)


def load_heatmaps(data_dir: str | Path) -> tuple[dict[str, np.ndarray], dict]:
    """Load ``heatmaps.npz`` -> (grids by name, meta dict). Mirrors cr-analysis."""
    z = np.load(Path(data_dir) / "spatial" / "heatmaps.npz", allow_pickle=False)
    map_w, map_h, cell, gw, gh = (int(v) for v in z["_meta"])
    grids = {k.replace("__", "::"): z[k] for k in z.files if not k.startswith("_")}
    return grids, {"map_w": map_w, "map_h": map_h, "cell": cell, "grid_w": gw, "grid_h": gh}


def _positions_arrays(ep: EpisodeSpatial) -> dict[str, np.ndarray]:
    """Columnar views of one episode's position samples, keyed by POSITION_FIELDS."""
    n = len(POSITION_FIELDS)
    if not ep.positions:
        z = np.empty(0, dtype=np.int64)
        return dict.fromkeys(POSITION_FIELDS, z)
    a = np.array(ep.positions, dtype=np.int64)  # bools coerce to 0/1
    return {name: a[:, i] for i, name in enumerate(POSITION_FIELDS[:n])}


def build(
    inputs: list[str],
    out_dir: str | Path,
    *,
    cell: int = 8,
    all_phases: bool = False,
    glob: str = "*.jsonl",
) -> dict:
    """Parse each JSONL episode and write the spatial datasets. Returns a summary."""
    files = collect_inputs(inputs, glob)
    if not files:
        raise SystemExit(f"no JSONL inputs found (looked for {glob!r} in {inputs}).")

    sp = (Path(out_dir) / "spatial").resolve()
    (sp / "positions").mkdir(parents=True, exist_ok=True)

    episodes: list[EpisodeSpatial] = []
    task_eps: dict[str, object] = {}
    n_hash_failed = n_err = 0
    for f in files:
        lines = f.read_text().splitlines()
        try:
            ep = parse_episode(lines, episode_id=f.stem, all_phases=all_phases)
        except EventlogError as e:
            print(f"skip {f.name}: {e}", file=sys.stderr)
            n_err += 1
            continue
        # The same JSONL carries the task/meeting rows. Reuse that parser rather than
        # growing a second copy of the same logic here.
        try:
            task_eps[f.stem] = parse_tasks(lines, episode_id=f.stem)
        except TaskLogError:
            task_eps[f.stem] = None
        if not ep.hash_ok:
            print(
                f"skip {ep.episode_id}: expand_replay reported a hash mismatch at tick "
                f"{ep.fail_tick} -- the game version that produced this JSONL is OUT OF SYNC "
                "with the replay's recording version; regenerate against a version-matched "
                "coworld-crewrift checkout.",
                file=sys.stderr,
            )
            n_hash_failed += 1
            continue
        episodes.append(ep)

    if not episodes:
        raise SystemExit(
            f"no usable episodes ({n_hash_failed} hash-failed, {n_err} not expand_replay output)."
        )

    map_w, map_h = episodes[0].map_w, episodes[0].map_h
    gw, gh = (map_w + cell - 1) // cell, (map_h + cell - 1) // cell
    grids: dict[str, np.ndarray] = defaultdict(lambda: np.zeros((gh, gw), dtype=np.int64))

    roster_out: dict[str, dict[int, str]] = {}
    kills_rows: list[dict] = []
    bodies_rows: list[dict] = []

    for ep in episodes:
        roster_out[ep.episode_id] = ep.roster
        _write_positions(sp / "positions" / f"{ep.episode_id}.npz", ep)
        _accumulate_occupancy(grids, ep, cell, gw, gh)
        _collect_kill_body_rows(kills_rows, bodies_rows, ep)

    for r in kills_rows:
        grids["kills"][min(r["y"] // cell, gh - 1), min(r["x"] // cell, gw - 1)] += 1
    for r in bodies_rows:
        cy, cx = min(r["y"] // cell, gh - 1), min(r["x"] // cell, gw - 1)
        grids["bodyhide_sum"][cy, cx] += int(r["undiscovered_ticks"])
        grids["bodyhide_count"][cy, cx] += 1

    _write_csv(sp / "kills.csv", KILL_COLS, kills_rows)
    _write_csv(sp / "bodies.csv", BODY_COLS, bodies_rows)

    vis_rows = [
        {
            "episode_id": ep.episode_id,
            "observer_slot": s_.observer_slot,
            "observer_role": s_.observer_role,
            "target_kind": s_.target_kind,
            "target_slot": s_.target_slot,
            "tick_start": s_.tick_start,
            "tick_end": s_.tick_end,
            "room": s_.room,
            "x": s_.x,
            "y": s_.y,
        }
        for ep in episodes
        for s_ in ep.sightings
    ]
    _write_csv(sp / "visibility.csv", VIS_COLS, vis_rows)

    meet_rows, task_rows, assign_rows = [], [], []
    for ep in episodes:
        te = task_eps.get(ep.episode_id)
        if te is None:
            continue
        for m in te.meetings:
            meet_rows.append(
                {
                    "episode_id": ep.episode_id,
                    "start": m.start,
                    "end": m.end,
                    "kind": m.kind,
                    "timed_out": int(m.timed_out),
                }
            )
        for crew in te.crew:
            for order, t in enumerate(crew.assigned):
                assign_rows.append(
                    {
                        "episode_id": ep.episode_id,
                        "slot": crew.slot,
                        "policy": crew.name,
                        "task": t,
                        "task_order": order,
                    }
                )
            for c in crew.completions:
                task_rows.append(
                    {
                        "episode_id": ep.episode_id,
                        "slot": crew.slot,
                        "policy": crew.name,
                        "task": c.task,
                        "tick": c.tick,
                        "room": c.room,
                        "while_dead": int(c.while_dead),
                    }
                )
    _write_csv(sp / "meetings.csv", MEETING_COLS, meet_rows)
    _write_csv(sp / "tasks.csv", TASK_COLS, task_rows)
    _write_csv(sp / "assignments.csv", ASSIGN_COLS, assign_rows)
    (sp / "roster.json").write_text(json.dumps(roster_out, indent=2, default=str))
    # geometry for the renderer's task/vent overlay (from the first episode).
    (sp / "geometry.json").write_text(
        json.dumps(
            {
                "map_w": map_w,
                "map_h": map_h,
                "tasks": episodes[0].tasks,
                "vents": episodes[0].vents,
            }
        )
    )
    np.savez_compressed(
        sp / "heatmaps.npz",
        _meta=np.array([map_w, map_h, cell, gw, gh]),
        _keys=np.array(list(grids.keys())),
        **{k.replace("::", "__"): v for k, v in grids.items()},
    )
    summary = _summarise(kills_rows, bodies_rows)
    (sp / "spatial_summary.json").write_text(json.dumps(summary, indent=2, default=str))

    print(
        f"spatial: {len(episodes)} episodes ok, {n_hash_failed} hash-failed, {n_err} bad; "
        f"{len(kills_rows)} kills, {len(bodies_rows)} bodies; heatmaps {gh}x{gw} @ {cell}px -> {sp}",
        file=sys.stderr,
    )
    return summary


# The dtype each per-tick column is stored as. active_task is -1..40, the cooldowns
# are ticks (kill cooldown starts at 500), velocities are the engine's fixed-point.
_POS_DTYPE = {
    "tick": np.int32,
    "slot": np.int8,
    "x": np.int16,
    "y": np.int16,
    "alive": bool,
    "imposter": bool,
    "active_task": np.int8,
    "vel_x": np.int16,
    "vel_y": np.int16,
    "kill_cooldown": np.int16,
    "vent_cooldown": np.int16,
}


def _write_positions(path: Path, ep: EpisodeSpatial) -> None:
    cols = _positions_arrays(ep)
    np.savez_compressed(path, **{k: cols[k].astype(_POS_DTYPE[k]) for k in POSITION_FIELDS})


def _accumulate_occupancy(grids, ep: EpisodeSpatial, cell: int, gw: int, gh: int) -> None:
    c = _positions_arrays(ep)
    tick, slot, x, y = c["tick"], c["slot"], c["x"], c["y"]
    alive, imposter = c["alive"].astype(bool), c["imposter"].astype(bool)
    if not len(tick):
        return
    live = alive
    cx = np.clip(x[live] // cell, 0, gw - 1)
    cy = np.clip(y[live] // cell, 0, gh - 1)
    np.add.at(grids["all"], (cy, cx), 1)
    imp = imposter[live]
    np.add.at(grids["imposter"], (cy[imp], cx[imp]), 1)
    np.add.at(grids["crew"], (cy[~imp], cx[~imp]), 1)
    live_slot = slot[live]
    by_policy: dict[str, list[int]] = defaultdict(list)
    for s, pol in ep.roster.items():
        by_policy[pol].append(s)
    for pol, slots in by_policy.items():
        if not pol:
            continue
        m = np.isin(live_slot, slots)
        np.add.at(grids[f"policy::{pol}"], (cy[m], cx[m]), 1)


def _collect_kill_body_rows(kills_rows, bodies_rows, ep: EpisodeSpatial) -> None:
    r = ep.roster
    for k in ep.kills:
        kills_rows.append(
            {
                "episode_id": ep.episode_id,
                "tick": k.tick,
                "killer_slot": k.killer_slot,
                "killer_policy": r.get(k.killer_slot, ""),
                "victim_slot": k.victim_slot,
                "victim_policy": r.get(k.victim_slot, ""),
                "x": k.x,
                "y": k.y,
                "room": k.room,
            }
        )
    for b in ep.bodies:
        bodies_rows.append(
            {
                "episode_id": ep.episode_id,
                "victim_slot": b.victim_slot,
                "victim_policy": r.get(b.victim_slot, ""),
                "x": b.x,
                "y": b.y,
                "room": b.room,
                "kill_tick": b.kill_tick,
                "cleared_tick": b.cleared_tick,
                "undiscovered_ticks": b.undiscovered_ticks,
                "reported": b.reported,
            }
        )


def _write_csv(path: Path, cols: list[str], rows: list[dict]) -> None:
    with path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        w.writerows(rows)


def _summarise(kills_rows: list[dict], bodies_rows: list[dict]) -> dict:
    by_room_kills: dict[str, int] = defaultdict(int)
    for r in kills_rows:
        by_room_kills[r["room"]] += 1
    undis = [int(b["undiscovered_ticks"]) for b in bodies_rows]
    never = sum(1 for b in bodies_rows if b["cleared_tick"] == -1)
    reported = sum(1 for b in bodies_rows if b["reported"])
    by_room_bodies: dict[str, list[int]] = defaultdict(list)
    for b in bodies_rows:
        by_room_bodies[b["room"]].append(int(b["undiscovered_ticks"]))
    body_by_room = {
        room: {
            "count": len(v),
            "mean": round(statistics.fmean(v), 1),
            "median": round(statistics.median(v), 1),
            "max": max(v),
        }
        for room, v in sorted(by_room_bodies.items(), key=lambda kv: -statistics.fmean(kv[1]))
    }
    return {
        "n_kills": len(kills_rows),
        "n_bodies": len(bodies_rows),
        "bodies_reported": reported,
        "bodies_cleared_by_other_meeting": len(bodies_rows) - reported - never,
        "bodies_never_discovered": never,
        "undiscovered_ticks": (
            {
                "mean": round(statistics.fmean(undis), 1),
                "median": statistics.median(undis),
                "max": max(undis),
            }
            if undis
            else {}
        ),
        "kill_hotspots_by_room": dict(sorted(by_room_kills.items(), key=lambda kv: -kv[1])[:15]),
        "body_undiscovered_by_room": body_by_room,
    }
