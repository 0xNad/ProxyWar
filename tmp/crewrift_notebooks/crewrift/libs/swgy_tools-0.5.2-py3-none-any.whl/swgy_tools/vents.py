"""Offline vent tooling: bake the canonical vent list into the packaged mesh, and
audit that list against real observed centres.

``mesh.vents`` (in swgy-base) is the immutable, runtime-facing data model. This module
is the *offline* counterpart, run deliberately -- never in a policy hot loop:

* ``bake`` writes :data:`CANONICAL_VENTS` into the shipped ``croatoan.graph`` (v4).
* ``audit`` reconciles the packaged prior against observed vent centres (from live
  ``WorldState.vents`` or any export) and *fails loud* on drift.

The replay parquet corpus carries no vents, so ``audit`` is source-agnostic: the caller
supplies observed ``(x, y)`` centres from whatever source has them.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from dataclasses import dataclass, field
from importlib.resources import as_file, files
from pathlib import Path

from swgy_base.nav import NavMesh, Vent
from swgy_base.nav.io import DEFAULT_MAP, load_mesh, save_graph

# Engine VentRange (px): two centres within this are the same vent. Mirrors
# ``swgy_base.world.tracker._VENT_RANGE_PX``.
VENT_EPS = 16

# Exact Croatoan vent centres (world px) + teleport-connectivity group (``vent:<n>``).
# The single, canonical source of truth baked into the packaged mesh. Centres are the
# exact rect centres the engine streams as ``WorldState.vents`` -- not the grid-snapped
# ``vent``-tagged nav nodes (which sit 2-6 px off).
CANONICAL_VENTS: list[Vent] = [
    Vent(id=0, x=229, y=345, group="vent:3"),
    Vent(id=1, x=323, y=115, group="vent:1"),
    Vent(id=2, x=354, y=571, group="vent:2"),
    Vent(id=3, x=501, y=341, group="vent:3"),
    Vent(id=4, x=510, y=521, group="vent:2"),
    Vent(id=5, x=552, y=289, group="vent:1"),
    Vent(id=6, x=552, y=385, group="vent:2"),
    Vent(id=7, x=614, y=118, group="vent:1"),
    Vent(id=8, x=740, y=341, group="vent:4"),
    Vent(id=9, x=929, y=118, group="vent:4"),
    Vent(id=10, x=929, y=486, group="vent:4"),
]


# --- audit / reconcile ----------------------------------------------------


@dataclass
class VentReport:
    """Outcome of reconciling a packaged prior against observed centres.

    ``matched`` are prior vents seen within ``eps``. The other three are drift:
    ``drifted`` (seen, but the observed centre is >``eps`` away), ``missing`` (a prior
    vent no observation supports), ``extra`` (an observed cluster with no prior nearby).
    """

    matched: list[tuple[Vent, tuple[int, int, int], float]] = field(default_factory=list)
    drifted: list[tuple[Vent, tuple[int, int, int], float]] = field(default_factory=list)
    missing: list[Vent] = field(default_factory=list)
    extra: list[tuple[int, int, int]] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        """True iff the prior fully explains the observations (no drift at all)."""
        return not (self.drifted or self.missing or self.extra)

    def summary(self) -> str:
        return (
            f"{len(self.matched)} matched, {len(self.drifted)} drifted, "
            f"{len(self.missing)} missing, {len(self.extra)} extra"
        )


def _cluster(points: list[tuple[int, int]], eps: float) -> list[tuple[int, int, int]]:
    """Collapse near-duplicate observed centres into ``(x, y, count)`` clusters.

    Single-pass greedy grouping by ``<=eps`` to a running centroid. Vents sit far
    apart (>> 2*eps), so this is robust to point order at the eps we use.
    """
    acc: list[list[float]] = []  # [sum_x, sum_y, count]
    for x, y in points:
        for c in acc:
            cx, cy = c[0] / c[2], c[1] / c[2]
            if (cx - x) ** 2 + (cy - y) ** 2 <= eps * eps:
                c[0] += x
                c[1] += y
                c[2] += 1
                break
        else:
            acc.append([float(x), float(y), 1.0])
    return [(round(c[0] / c[2]), round(c[1] / c[2]), int(c[2])) for c in acc]


def reconcile_vents(
    prior: list[Vent],
    observed: list[tuple[int, int]],
    eps: float = VENT_EPS,
) -> VentReport:
    """Match a packaged vent prior against observed centres; report matches and drift.

    ``observed`` is any bag of ``(x, y)`` centres (e.g. accumulated ``WorldState.vents``
    across games) -- it's clustered first, so duplicates across ticks/episodes are fine.
    Pairing is greedy by ascending distance, so the closest prior/observation pairs bind
    first; a pair beyond ``eps`` is drift, an unpaired prior is missing, an unpaired
    cluster is extra.
    """
    clusters = _cluster(observed, eps)
    pairs = sorted(
        (
            (math.hypot(p.x - c[0], p.y - c[1]), pi, ci)
            for pi, p in enumerate(prior)
            for ci, c in enumerate(clusters)
        ),
        key=lambda t: t[0],
    )
    used_p: set[int] = set()
    used_c: set[int] = set()
    report = VentReport()
    for dist, pi, ci in pairs:
        if pi in used_p or ci in used_c:
            continue
        used_p.add(pi)
        used_c.add(ci)
        rec = (prior[pi], clusters[ci], dist)
        (report.matched if dist <= eps else report.drifted).append(rec)
    report.missing = [p for pi, p in enumerate(prior) if pi not in used_p]
    report.extra = [c for ci, c in enumerate(clusters) if ci not in used_c]
    return report


# --- bake -----------------------------------------------------------------


def default_asset_paths(name: str = DEFAULT_MAP) -> tuple[Path, Path]:
    """Absolute ``(walk, graph)`` paths of the packaged mesh asset for ``name``.

    Resolves the same ``swgy_base/nav/data`` resource ``load_default_mesh`` reads. Under
    the editable workspace install this is the real source file, so ``bake`` rewrites it.
    """
    data = files("swgy_base.nav") / "data"
    with as_file(data / f"{name}.walk") as walk, as_file(data / f"{name}.graph") as graph:
        return Path(walk), Path(graph)


def bake_asset(
    walk_path: str | Path,
    graph_path: str | Path,
    vents: list[Vent] = CANONICAL_VENTS,
) -> NavMesh:
    """Write ``vents`` into the mesh graph at ``graph_path`` (upgrading it to v4).

    Loads the existing mesh, swaps in ``vents``, and rewrites only the ``.graph`` (the
    ``.walk`` is unchanged, so it's left untouched). Deterministic: baking twice is a
    no-op on disk. Requires the swgy-base v4 format (this package's ``save_graph``).
    """
    mesh = load_mesh(walk_path, graph_path)
    rebaked = NavMesh(
        grid=mesh.grid,
        nodes=mesh.nodes,
        edges=mesh.edges,
        meta=mesh.meta,
        tasks=mesh.tasks,
        vents=list(vents),
    )
    save_graph(rebaked, graph_path)
    return rebaked


# --- CLI ------------------------------------------------------------------


def _load_observed(path: Path) -> list[tuple[int, int]]:
    """Read observed centres from a JSON file: ``[[x, y], ...]`` or ``[{"x":,"y":}, ...]``."""
    raw = json.loads(path.read_text())
    out: list[tuple[int, int]] = []
    for item in raw:
        if isinstance(item, dict):
            out.append((int(item["x"]), int(item["y"])))
        else:
            out.append((int(item[0]), int(item[1])))
    return out


def _cmd_bake(args: argparse.Namespace) -> int:
    walk, graph = (
        (Path(args.walk), Path(args.graph))
        if args.walk and args.graph
        else default_asset_paths(args.map)
    )
    mesh = bake_asset(walk, graph)
    print(f"baked {len(mesh.vents)} vents into {graph}", file=sys.stderr)
    return 0


def _cmd_audit(args: argparse.Namespace) -> int:
    observed = _load_observed(Path(args.observed))
    report = reconcile_vents(CANONICAL_VENTS, observed, eps=args.eps)
    print(report.summary(), file=sys.stderr)
    for v, c, d in report.drifted:
        print(f"  DRIFT  vent {v.id} ({v.x},{v.y}) vs observed ({c[0]},{c[1]}) = {d:.1f}px")
    for v in report.missing:
        print(f"  MISSING vent {v.id} ({v.x},{v.y}) -- no observation within {args.eps}px")
    for c in report.extra:
        print(f"  EXTRA  observed ({c[0]},{c[1]}) x{c[2]} -- no prior vent nearby")
    if not report.ok:
        print("vent audit FAILED (prior disagrees with observations)", file=sys.stderr)
        return 1
    print("vent audit OK", file=sys.stderr)
    return 0


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        prog="swgy-vent-audit",
        description="Bake / audit the canonical vent list against the packaged mesh.",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    b = sub.add_parser("bake", help="write CANONICAL_VENTS into the packaged mesh (v4)")
    b.add_argument("--map", default=DEFAULT_MAP, help="asset name (default: croatoan)")
    b.add_argument("--walk", help="override walk path (defaults to the packaged asset)")
    b.add_argument("--graph", help="override graph path (defaults to the packaged asset)")
    b.set_defaults(func=_cmd_bake)

    a = sub.add_parser("audit", help="reconcile the prior against observed centres; fail on drift")
    a.add_argument("observed", help="JSON file of observed centres: [[x,y],...] or [{x,y},...]")
    a.add_argument(
        "--eps", type=float, default=VENT_EPS, help=f"match radius px (default {VENT_EPS})"
    )
    a.set_defaults(func=_cmd_audit)

    args = p.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
