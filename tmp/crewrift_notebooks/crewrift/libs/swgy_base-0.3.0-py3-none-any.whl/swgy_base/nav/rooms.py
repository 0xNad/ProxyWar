"""Canonical room names for the shipped Croatoan map.

``swgy_base.nav`` is otherwise map-agnostic: the rooms on *any* mesh come from
:meth:`NavMesh.rooms` (the ``room:`` tags it carries). These constants name the
rooms of the **default** map (``load_default_mesh()``) so a policy can route to a
room by a typo-safe symbol instead of a bare string, and iterate the set:

    from swgy_base.nav import CroatoanRoom, CROATOAN_ROOMS, load_default_mesh
    mesh = load_default_mesh()
    mesh.room_centroid(CroatoanRoom.REACTOR)      # -> (x, y); StrEnum member is a str
    for name in CROATOAN_ROOMS:                    # iterate every room name
        print(name, mesh.room_centroid(name))

They're a convenience layer over the mesh, kept in lockstep with the shipped
asset by a test. A mesh you rebuild without room tags still works with the
mesh-driven API (``rooms()`` / ``room_centroid``); it just won't carry these names.
"""

from __future__ import annotations

import enum


class CroatoanRoom(enum.StrEnum):
    """The rooms of the Croatoan map. Each value is the exact ``room:`` tag name,
    so a member is usable anywhere a room-name string is (equality, ``in``,
    ``mesh.room_centroid(...)``). Iterate members with ``list(CroatoanRoom)``."""

    BRIDGE = "Bridge"
    DATA_STORAGE = "Data Storage"
    ENGINEERING = "Engineering"
    ENGINEERING_NOOK = "Engineering Nook"
    HYDROPONICS = "Hydroponics"
    MED_BAY = "Med Bay"
    OBSERVATORY = "Observatory"
    PORT_ENGINE = "Port Engine"
    REACTOR = "Reactor"
    SCIENCE_BAY = "Science Bay"
    SHUTTLE_BAY = "Shuttle Bay"
    STARBOARD_ENGINE = "Starboard Engine"
    STORAGE_DECK = "Storage Deck"


# The room names as a plain tuple, in the same (sorted) order ``NavMesh.rooms()``
# returns for the default mesh -- a simple thing to iterate over.
CROATOAN_ROOMS: tuple[str, ...] = tuple(r.value for r in CroatoanRoom)
