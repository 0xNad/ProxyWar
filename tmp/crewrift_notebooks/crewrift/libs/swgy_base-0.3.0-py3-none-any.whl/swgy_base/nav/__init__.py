"""Navigation: walkability grid + tagged/weighted nav-mesh, with I/O.

The robust, ergonomic data model a policy uses to path across Croatoan:

    NavGrid   -- packed-bit walkability bitmap (is_walkable, to/from mask)
    NavNode   -- a waypoint at a map pixel, with free-form tags
    NavEdge   -- a weighted (optionally directed) connection, with tags
    NavMesh   -- grid + nodes + edges + queries (nearest_node, neighbors,
                 nodes_with_tag, is_walkable, visibility_at)

Nodes built with ``swgy-navmesh-sight`` carry baked line-of-sight coefficients
(``exposure`` 0..1 where 1 = most open, and ``witnesses``). Read them per
position with ``NavMesh.visibility_at`` / ``exposure_at`` / ``witnesses_at``
(-> ``VisReading``), filter the graph with ``nodes_by_exposure`` to route toward
cover / open ground, and gate on ``has_visibility``.

The mesh is *built* by the separate ``swgy-tools`` ``swgy-navmesh`` tool, which
emits a simple JSON interchange; this package ingests it
(``mesh_from_interchange``) and owns the canonical two-file binary format
(``save_mesh`` / ``load_mesh`` over ``<name>.walk`` + ``<name>.graph``). Compile
an interchange to canonical with ``python -m swgy_base.nav compile``.

Routing and following build on the model:

    find_path  -- A* over the mesh -> a cacheable NavPlan (or None)
    NavPlan    -- frozen ordered route; compute once, follow for many ticks
    NavParams  -- tunable knobs: heuristic weight, static-tag avoidance,
                  waypoint arrival, crew separation, stuck detection
    NavState   -- mutable follower: advance along a plan + crew-separation
                  steering + inertia-aware braking + stuck/cycle detection

Cache-and-follow: ``find_path`` once, hold the ``NavPlan`` in a ``NavState``,
then per tick ``update(me)`` + ``heading(me, others)``; map the heading to a
button mask with ``protocol.mask_from_heading``. Movement is acceleration-
integrated with steep friction, so ``heading`` steers on velocity error and
eases off near the goal to stop on target instead of coasting past. The tags/weights/directed-edge
fields accommodate vents and doors -- but a vent edge whose weight undercuts its
endpoints' euclidean gap would break A* admissibility (see ``astar``).
"""

from .astar import find_path
from .follow import NavState
from .io import (
    load_default_mesh,
    load_grid,
    load_mesh,
    mesh_from_interchange,
    save_grid,
    save_mesh,
)
from .model import (
    ROOM_TAG_PREFIX,
    NavEdge,
    NavGrid,
    NavMesh,
    NavNode,
    TaskStation,
    Vent,
    VisReading,
    points_toward,
)
from .params import NavParams
from .plan import NavPlan
from .rooms import CROATOAN_ROOMS, CroatoanRoom

__all__ = [
    "NavGrid",
    "NavNode",
    "NavEdge",
    "NavMesh",
    "TaskStation",
    "Vent",
    "VisReading",
    "points_toward",
    "ROOM_TAG_PREFIX",
    "CroatoanRoom",
    "CROATOAN_ROOMS",
    "mesh_from_interchange",
    "save_mesh",
    "load_mesh",
    "load_default_mesh",
    "save_grid",
    "load_grid",
    "find_path",
    "NavPlan",
    "NavParams",
    "NavState",
]
