"""swgy-base: the base layer for building CrewRift (sprite_v1) policies.

Subpackages:
    protocol  -- sprite_v1 wire parser + packet builders
    world     -- scene -> world model (roster, bodies, tasks, phase, votes)
    nav       -- walkability + graph + A* + steering (world coordinates)
    runtime   -- websocket loop, env wiring, tick loop, policy interface

A policy depends only on swgy-base. Capture/analysis tooling lives in the
separate ``swgy-tools`` distribution; knob/GA tuning support in ``swgy-tune``.
See CLAUDE.md for the build plan and reference sources.
"""

__version__ = "0.3.0"
