"""Runtime: the websocket player loop, env wiring, and the policy interface.

Lifecycle (the Coworld player contract): read the websocket URL from env
(``COWORLD_PLAYER_WS_URL``, with ``COGAMES_ENGINE_WS_URL`` as a mirror),
connect, play the episode, exit when the socket closes. Each inbound binary
message is exactly one sprite_v1 packet (confirmed against ``swgy-capture``);
we feed it to a ``SceneGraph``, derive a ``WorldState``, ask the policy for an
``Action``, and emit a 0x84 input (plus optional 0x81 chat).

A policy implements:

    class Policy(Protocol):
        def reset(self) -> None: ...
        def act(self, world: WorldState) -> Action: ...

Run one with ``run_player(MyPolicy())``. The per-message loop is factored into
``run_session(ws, policy)`` so it can be driven with a fake socket in tests.
The transport mirrors ``swgy_tools.capture`` (sync client, no pings, no size
cap, connect-with-retry while the server boots).
"""

from __future__ import annotations

import os
import time
from dataclasses import dataclass
from typing import Protocol, runtime_checkable

from websockets.exceptions import ConnectionClosed
from websockets.sync.client import connect

from ..protocol import SceneGraph, pack_chat_packet, pack_input_packet
from ..world import GameTracker, Phase, WorldState, read_world

# Re-emit the held input at least this often (in messages) even when unchanged,
# as cheap insurance against a dropped packet. The server holds the last mask,
# so change-only sending is correct; this is belt-and-suspenders.
_KEEPALIVE_MESSAGES = 60

# Episode-exit guards. The Coworld runner gives a player only ~10s to exit after
# the game container stops, and with pings disabled a dead connection isn't
# noticed promptly -- so we exit on sustained silence (no frames) or a settled
# game-over screen, in addition to a clean socket close.
_RECV_TIMEOUT = 1.0  # seconds per recv
_MAX_IDLE = 4  # consecutive recv timeouts (~4s silent) => connection is dead
_GAME_OVER_EXIT = 60  # consecutive GAME_OVER frames => episode is over


@dataclass
class Action:
    """What a policy wants this tick: a 7-bit button mask + optional chat."""

    buttons: int = 0
    chat: str | None = None


@runtime_checkable
class Policy(Protocol):
    """The interface a CrewRift policy implements."""

    def reset(self) -> None:
        """Reset per-episode state before the first frame."""
        ...

    def act(self, world: WorldState) -> Action:
        """Decide this tick's action from the current world snapshot."""
        ...


def resolve_url(url: str | None = None) -> str:
    """Resolve the player websocket URL (arg first, then env), or raise."""
    if url:
        return url
    env = os.environ.get("COWORLD_PLAYER_WS_URL") or os.environ.get("COGAMES_ENGINE_WS_URL")
    if not env:
        raise RuntimeError(
            "no websocket URL: pass url= or set COWORLD_PLAYER_WS_URL "
            "(mirror COGAMES_ENGINE_WS_URL)"
        )
    return env


def connect_with_retry(url: str, timeout: float):
    """Connect, retrying briefly while the game server finishes booting."""
    deadline = time.monotonic() + timeout
    last_error: Exception | None = None
    while time.monotonic() < deadline:
        try:
            return connect(url, open_timeout=1.0, ping_interval=None, max_size=None)
        except Exception as exc:  # noqa: BLE001 -- retry on any connect failure
            last_error = exc
            time.sleep(0.05)
    raise RuntimeError(f"failed to connect to {url}") from last_error


def run_session(ws, policy: Policy) -> None:
    """Drive ``policy`` over an open socket until the episode ends.

    ``ws`` exposes ``recv(timeout=...)`` (raising ``TimeoutError`` on silence,
    ``ConnectionClosed`` on close) and ``send``; tests pass a fake. Non-bytes
    (text) frames are skipped. An input packet is sent on mask change (with a
    periodic keepalive resend); chat is sent on non-empty text. Returns when the
    socket closes, the stream goes silent (dead connection), or the game-over
    screen settles -- so the container exits within the runner's grace window.
    """
    policy.reset()
    scene = SceneGraph()
    tracker = GameTracker()  # carries elapsed_ticks + button_calls_remaining across frames
    last_mask: int | None = None
    since_input = 0
    idle = 0
    over = 0
    while True:
        try:
            raw = ws.recv(timeout=_RECV_TIMEOUT)
        except TimeoutError:
            idle += 1
            if idle >= _MAX_IDLE:
                return  # no frames for a while: game container gone
            continue
        except ConnectionClosed:
            return  # clean end-of-episode
        idle = 0
        if not isinstance(raw, (bytes, bytearray)):
            continue  # text frame: not sprite_v1
        scene.apply_packet(bytes(raw))
        world = read_world(scene)
        tracker.observe(world)  # stamp elapsed_ticks + button_calls_remaining onto the snapshot
        if world.phase is Phase.GAME_OVER:
            over += 1
            if over >= _GAME_OVER_EXIT:
                return  # result screen has settled: episode is over
        else:
            over = 0
        action = policy.act(world)
        tracker.note_action(world, action)  # a fresh A-press on the button rect spends a call
        mask = action.buttons & 0x7F
        since_input += 1
        if mask != last_mask or since_input >= _KEEPALIVE_MESSAGES:
            ws.send(pack_input_packet(mask))
            last_mask = mask
            since_input = 0
        if action.chat:
            ws.send(pack_chat_packet(action.chat))


def run_player(policy: Policy, url: str | None = None, *, connect_timeout: float = 15.0) -> None:
    """Connect to the resolved player URL and run ``policy`` to episode end."""
    target = resolve_url(url)
    ws = connect_with_retry(target, connect_timeout)
    try:
        run_session(ws, policy)
    except ConnectionClosed:
        pass  # normal end-of-episode
    finally:
        try:
            ws.close()
        except Exception:  # noqa: BLE001
            pass


__all__ = [
    "Action",
    "Policy",
    "resolve_url",
    "connect_with_retry",
    "run_session",
    "run_player",
]
