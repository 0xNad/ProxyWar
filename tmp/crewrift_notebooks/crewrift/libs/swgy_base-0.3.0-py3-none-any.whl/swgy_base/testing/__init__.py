"""Offline policy validation: fuzz a policy with synthetic world snapshots.

A submitted policy runs unattended for a whole episode; one uncaught exception
on an odd frame (a meeting with no cursor yet, a frame with no map object, a
ghost self) forfeits the round. ``fuzz_policy`` drives ``policy.act()`` across
hundreds of randomized ``WorldState``s spanning every phase and the awkward
corners of the model (``me_collision is None``, empty rosters, ghost self,
half-populated ballots), and reports every crash and every non-``Action``
return. It needs no server, no mesh, and no game data, so it belongs at the
end of any policy-editing loop:

    from swgy_base.testing import fuzz_policy
    report = fuzz_policy(MyPolicy())
    assert report.ok, report

The generator is seeded (``random.Random(seed)``); the same seed always
produces the same worlds, so a failure is reproducible.
"""

from __future__ import annotations

import random
import traceback
from dataclasses import dataclass, field

from ..runtime import Action
from ..world.model import COLOURS, Actor, Phase, WorldState

# Reset cadence: the fuzzer cycles phases in batches, calling ``policy.reset()``
# at each batch start, so repeated resets are exercised too (the runtime resets
# once per episode; a policy must tolerate more).
_BATCH = 25

# Croatoan-ish coordinate ranges for plausible positions (world px).
_MAP_W, _MAP_H = 1235, 659


def _maybe(rng: random.Random, p: float) -> bool:
    return rng.random() < p


def _pos(rng: random.Random) -> tuple[int, int]:
    return (rng.randrange(0, _MAP_W), rng.randrange(0, _MAP_H))


def _random_world(rng: random.Random, phase: Phase) -> WorldState:
    """One plausible-but-adversarial snapshot for ``phase``.

    Field combinations mirror what the reader can actually emit: no map object
    means no self position (``me_collision`` comes back ``None``); ROLE_REVEAL
    streams no map; ballots start with no cursor shown (``None``).
    """
    w = WorldState(phase=phase)

    # Localization: usually present while PLAYING, absent otherwise ~half the
    # time (and always absent during ROLE_REVEAL, like the real stream).
    localized = phase is Phase.PLAYING and _maybe(rng, 0.85)
    if phase is not Phase.ROLE_REVEAL and (localized or _maybe(rng, 0.5)):
        w.map_origin = (-rng.randrange(0, 600), -rng.randrange(0, 300))
        w.me_screen = (rng.randrange(0, 320), rng.randrange(0, 200))

    # Roster: 0..4 visible others, mixed alive/dead, real engine colours.
    colours = rng.sample(COLOURS, k=rng.randrange(0, 5))
    w.others = [Actor(c, *_pos(rng), _maybe(rng, 0.8)) for c in colours]
    w.bodies = [_pos(rng) for _ in range(rng.randrange(0, 3))]
    w.vents = [_pos(rng) for _ in range(rng.randrange(0, 3))]

    # Tasks: a few markers, a subset assigned to me; arrows omitted (screen-frame
    # clues; ``remaining_task_ks`` is what target selection reads).
    for k in range(rng.randrange(0, 4)):
        w.task_markers[k] = _pos(rng)
        w.task_marker_dims[k] = (14, 14)
    w.remaining_task_ks = tuple(k for k in w.task_markers if _maybe(rng, 0.7))
    w.tasks_remaining = len(w.remaining_task_ks)

    # Role and cross-frame state.
    w.me_is_imposter = _maybe(rng, 0.4)
    w.kill_ready = w.me_is_imposter and _maybe(rng, 0.5)
    w.me_alive = _maybe(rng, 0.85)
    if w.me_is_imposter and colours and _maybe(rng, 0.7):
        w.teammates = {rng.choice(colours)}
    w.button_calls_remaining = rng.randrange(0, 2)
    w.witnessed_kill = _maybe(rng, 0.1)
    w.witnessed_vent = _maybe(rng, 0.1)
    if colours and _maybe(rng, 0.2):
        w.suspicious = {rng.choice(colours)}
    w.elapsed_ticks = rng.randrange(0, 20_000)
    w.ticks_since_meeting = rng.randrange(0, 5_000)

    # Ballot: only VOTING shows one, and even then the cursor may not be up yet.
    if phase is Phase.VOTING:
        living = [c for c in colours if _maybe(rng, 0.8)]
        w.vote_order = tuple(living)
        w.vote_tally = {c: rng.randrange(0, 4) for c in living if _maybe(rng, 0.6)}
        w.vote_skip_count = rng.randrange(0, 4)
        w.vote_cursor_on_skip = rng.choice([None, True, False])

    return w


def _summary(world: WorldState) -> str:
    """A one-line reproduction hint for a failing world."""
    return (
        f"phase={world.phase.value} me_collision={world.me_collision} "
        f"others={len(world.others)} bodies={len(world.bodies)} "
        f"imposter={world.me_is_imposter} alive={world.me_alive} "
        f"cursor_on_skip={world.vote_cursor_on_skip} "
        f"vote_order={world.vote_order}"
    )


@dataclass
class FuzzReport:
    """What ``fuzz_policy`` found. ``ok`` means safe to package."""

    n: int = 0
    seed: int = 0
    crashes: list[tuple[str, str]] = field(default_factory=list)  # (world summary, traceback)
    bad_returns: list[str] = field(default_factory=list)  # world summaries with non-Action returns

    @property
    def ok(self) -> bool:
        return not self.crashes and not self.bad_returns

    def __str__(self) -> str:
        if self.ok:
            return f"OK: {self.n} synthetic worlds, no crashes, every act() returned an Action."
        lines = [
            f"FAILED over {self.n} worlds (seed={self.seed}): "
            f"{len(self.crashes)} crash(es), {len(self.bad_returns)} non-Action return(s)."
        ]
        for summary, tb in self.crashes[:3]:
            lines.append(f"\ncrash on {summary}\n{tb.rstrip()}")
        if len(self.crashes) > 3:
            lines.append(f"... and {len(self.crashes) - 3} more crash(es)")
        for summary in self.bad_returns[:3]:
            lines.append(f"non-Action return on {summary}")
        return "\n".join(lines)


def fuzz_policy(policy, n: int = 500, seed: int = 0) -> FuzzReport:
    """Drive ``policy.act()`` over ``n`` seeded synthetic worlds; report failures.

    Phases are cycled in batches with ``policy.reset()`` at each batch start.
    A ``reset()`` crash is recorded and aborts the run (nothing after it is
    trustworthy); ``act()`` crashes are recorded per-world and the run
    continues, so one bad corner doesn't hide another.
    """
    rng = random.Random(seed)
    report = FuzzReport(seed=seed)
    phases = list(Phase)
    i = 0
    while i < n:
        phase = phases[(i // _BATCH) % len(phases)]
        try:
            policy.reset()
        except Exception:
            report.crashes.append(("policy.reset()", traceback.format_exc()))
            report.n = i
            return report
        for _ in range(min(_BATCH, n - i)):
            world = _random_world(rng, phase)
            i += 1
            try:
                action = policy.act(world)
            except Exception:
                report.crashes.append((_summary(world), traceback.format_exc()))
                continue
            if not isinstance(action, Action):
                report.bad_returns.append(f"{_summary(world)} -> {action!r}")
    report.n = n
    return report


__all__ = ["FuzzReport", "fuzz_policy"]
