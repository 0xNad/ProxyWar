"""Little-endian integer readers for the sprite_v1 wire format.

Ported verbatim from the reference parser
``sprite_player_protocol.py``. All multi-byte fields in sprite_v1 are
little-endian (see the ``sprite_v1`` spec).
"""

from __future__ import annotations

import struct


def read_u16(data: bytes, offset: int) -> int:
    return data[offset] | (data[offset + 1] << 8)


def read_i16(data: bytes, offset: int) -> int:
    return struct.unpack_from("<h", data, offset)[0]


def read_u32(data: bytes, offset: int) -> int:
    return struct.unpack_from("<I", data, offset)[0]
