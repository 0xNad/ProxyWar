"""Stateful sprite_v1 scene-graph: the sprites + objects + viewport tables.

``SceneGraph`` is the wire-only core of the reference parser's
``SpritePlayerObservationAdapter`` (``apply_packet`` ported faithfully --
same offsets, truncation guards, and message handling). It deliberately
stops at the raw scene graph: it keeps sprite labels and decompressed RGBA
pixels but does NOT classify labels, map colors to palette indices, or build
RL observations -- that is the ``world`` package's job.
"""

from __future__ import annotations

from . import snappy
from ._io import read_i16, read_u16, read_u32
from .messages import ObjectPlacement, SpriteDef

# Viewport defaults until the server sends a 0x05 Set Viewport for layer 0.
DEFAULT_VIEWPORT = 128


class SceneGraph:
    def __init__(self) -> None:
        self.sprites: dict[int, SpriteDef] = {}
        self.objects: dict[int, ObjectPlacement] = {}
        self.viewport_width = DEFAULT_VIEWPORT
        self.viewport_height = DEFAULT_VIEWPORT
        self.frame_count = 0

    def apply_packet(self, packet: bytes) -> bool:
        """Apply one wire packet (which may carry several messages).

        Returns True if any sprite/object state changed. On a truncated
        message it stops and returns what it has so far (matching the
        reference); an unknown message type also stops parsing.
        """
        offset = 0
        changed = False
        while offset < len(packet):
            message_type = packet[offset]
            offset += 1
            if message_type == 0x01:
                if offset + 10 > len(packet):
                    return changed
                sprite_id = read_u16(packet, offset)
                width = read_u16(packet, offset + 2)
                height = read_u16(packet, offset + 4)
                compressed_len = read_u32(packet, offset + 6)
                offset += 10
                if offset + compressed_len + 2 > len(packet):
                    return changed
                compressed = packet[offset : offset + compressed_len]
                offset += compressed_len
                label_len = read_u16(packet, offset)
                offset += 2
                if offset + label_len > len(packet):
                    return changed
                label = packet[offset : offset + label_len].decode("utf-8", errors="replace")
                offset += label_len
                self.sprites[sprite_id] = SpriteDef(
                    width=width,
                    height=height,
                    label=label,
                    pixels=snappy.decompress(compressed) if compressed_len else None,
                )
                changed = True
            elif message_type == 0x02:
                if offset + 11 > len(packet):
                    return changed
                object_id = read_u16(packet, offset)
                self.objects[object_id] = ObjectPlacement(
                    x=read_i16(packet, offset + 2),
                    y=read_i16(packet, offset + 4),
                    z=read_i16(packet, offset + 6),
                    layer=packet[offset + 8],
                    sprite_id=read_u16(packet, offset + 9),
                )
                offset += 11
                changed = True
            elif message_type == 0x03:
                if offset + 2 > len(packet):
                    return changed
                self.objects.pop(read_u16(packet, offset), None)
                offset += 2
                changed = True
            elif message_type == 0x04:
                self.objects.clear()
                changed = True
            elif message_type == 0x05:
                if offset + 5 > len(packet):
                    return changed
                layer_id = packet[offset]
                width = read_u16(packet, offset + 1)
                height = read_u16(packet, offset + 3)
                if layer_id == 0:
                    self.viewport_width = width
                    self.viewport_height = height
                offset += 5
            elif message_type == 0x06:
                offset += 3
            else:
                return changed
        if changed:
            self.frame_count += 1
        return changed
