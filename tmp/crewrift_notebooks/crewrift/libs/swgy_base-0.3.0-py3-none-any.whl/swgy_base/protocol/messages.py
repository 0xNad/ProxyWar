"""sprite_v1 opcodes, scene-graph records, and packet builders.

Wire-level only: no CrewRift semantics. Opcode + button constants and the
client->server packet builders are ported from the reference parser
``sprite_player_protocol.py`` and cross-checked against the ``sprite_v1`` spec.
"""

from __future__ import annotations

from dataclasses import dataclass

# Server -> client message types (docs/sprite_v1.md "Server to Client Messages").
MSG_DEFINE_SPRITE = 0x01
MSG_DEFINE_OBJECT = 0x02
MSG_DELETE_OBJECT = 0x03
MSG_CLEAR_OBJECTS = 0x04
MSG_SET_VIEWPORT = 0x05
MSG_DEFINE_LAYER = 0x06

# Client -> server message types we build here.
PACKET_CHAT = 0x81  # Input Text
PACKET_INPUT = 0x84  # Player Input
INPUT_PACKET_BYTES = 2

# Player Input button bitmask (matches Bitscreen v1; bit 7 reserved).
BTN_UP = 0x01
BTN_DOWN = 0x02
BTN_LEFT = 0x04
BTN_RIGHT = 0x08
BTN_SELECT = 0x10
BTN_A = 0x20
BTN_B = 0x40


@dataclass
class SpriteDef:
    """A sprite definition (0x01). ``pixels`` is decompressed raw RGBA bytes."""

    width: int
    height: int
    label: str
    pixels: bytes | None = None


@dataclass
class ObjectPlacement:
    """An object instance placement (0x02), in world/layer coordinates."""

    x: int
    y: int
    z: int
    layer: int
    sprite_id: int


def mask_from_heading(dx: int, dy: int) -> int:
    """Map a desired travel direction to a Player Input button mask.

    ``dx``/``dy`` are sign-like: negative => left/up, positive => right/down,
    zero => no movement on that axis (y increases downward, matching grid rows).
    A diagonal ORs two bits. Returns a 7-bit mask suitable for
    :func:`pack_input_packet`.
    """
    mask = 0
    if dx < 0:
        mask |= BTN_LEFT
    elif dx > 0:
        mask |= BTN_RIGHT
    if dy < 0:
        mask |= BTN_UP
    elif dy > 0:
        mask |= BTN_DOWN
    return mask


def pack_input_packet(mask: int) -> bytes:
    """Build a 0x84 Player Input packet from a 7-bit button mask."""
    if not 0 <= mask <= 0x7F:
        raise ValueError(f"sprite_v1 input mask must be in [0, 127], got {mask}")
    return bytes([PACKET_INPUT, mask])


def unpack_input_packet(packet: bytes | bytearray | memoryview) -> int:
    """Parse a 0x84 Player Input packet, returning the 7-bit button mask."""
    raw = bytes(packet)
    if len(raw) != INPUT_PACKET_BYTES or raw[0] != PACKET_INPUT:
        raise ValueError(
            "sprite_v1 input packets must be two bytes: kind 0x84 followed by a button mask"
        )
    return raw[1] & 0x7F


def pack_chat_packet(text: str) -> bytes:
    """Build a 0x81 Input Text packet from non-empty printable-ASCII text."""
    clean_text = text.strip()
    if not clean_text:
        raise ValueError("sprite_v1 chat packets require non-empty text")
    if any(ord(ch) < 0x20 or ord(ch) >= 0x7F for ch in clean_text):
        raise ValueError("sprite_v1 chat text must be printable ASCII")
    payload = clean_text.encode("ascii")
    if len(payload) > 0xFFFF:
        raise ValueError("sprite_v1 chat text is too long")
    return bytes([PACKET_CHAT]) + len(payload).to_bytes(2, "little") + payload
