"""Pure-Python Snappy decompression for sprite_v1 pixel payloads.

sprite_v1 ``Define Sprite`` (0x01) messages carry RGBA pixels as a Snappy
stream (``sprite_v1`` spec -> "Compressed pixels"). This is a faithful,
dependency-free port of ``snappy_decompress`` from the reference parser
``sprite_player_protocol.py`` -- a varint uncompressed-length prefix followed
by tag-based literal/copy elements.

Kept pure-Python on purpose: zero native deps, readable, and a byte-exact
match for the reference (Python throughout).
"""

from __future__ import annotations

from ._io import read_u16, read_u32


def decompress(data: bytes) -> bytes:
    """Decompress a Snappy stream. Raises ``ValueError`` on malformed input."""
    index = 0
    expected = 0
    shift = 0
    while True:
        if index >= len(data):
            raise ValueError("truncated snappy length")
        byte = data[index]
        index += 1
        expected |= (byte & 0x7F) << shift
        if byte < 128:
            break
        shift += 7

    output = bytearray()
    while index < len(data):
        tag = data[index]
        index += 1
        tag_type = tag & 0x03
        if tag_type == 0:
            length_code = tag >> 2
            if length_code < 60:
                length = length_code + 1
            else:
                extra = length_code - 59
                if index + extra > len(data):
                    raise ValueError("truncated snappy literal length")
                length = int.from_bytes(data[index : index + extra], "little") + 1
                index += extra
            if index + length > len(data):
                raise ValueError("truncated snappy literal")
            output.extend(data[index : index + length])
            index += length
            continue

        if tag_type == 1:
            if index >= len(data):
                raise ValueError("truncated snappy copy1")
            length = ((tag >> 2) & 0x07) + 4
            offset = ((tag & 0xE0) << 3) | data[index]
            index += 1
        elif tag_type == 2:
            if index + 2 > len(data):
                raise ValueError("truncated snappy copy2")
            length = (tag >> 2) + 1
            offset = read_u16(data, index)
            index += 2
        else:
            if index + 4 > len(data):
                raise ValueError("truncated snappy copy4")
            length = (tag >> 2) + 1
            offset = read_u32(data, index)
            index += 4

        if offset <= 0 or offset > len(output):
            raise ValueError("invalid snappy copy offset")
        for _ in range(length):
            output.append(output[-offset])

    if len(output) != expected:
        raise ValueError(f"snappy length mismatch: expected {expected}, got {len(output)}")
    return bytes(output)
