"""sprite_v1 wire protocol: binary parser + packet builders.

Server->client (0x01..0x06): Define Sprite / Object / Delete / Clear /
Viewport / Layer. Maintain layers/sprites/objects tables.
Client->server: 0x84 Player Input (1-byte button mask, same bits as
bitscreen v1: UP=0x01..B=0x40); 0x81 Chat (length-prefixed ASCII).

Ported from the authoritative reference parser (hand-rolled Snappy
decompressor + wire framing), ``sprite_player_protocol.py``, against the
``sprite_v1`` protocol spec (``sprite_v1.md``).

This package is wire-only. Label *meaning* (the CrewRift vocabulary,
object-ID bases, roster/phase/camera, palette/observation) lives in the
``world`` package; here we keep raw labels and raw decompressed RGBA pixels.
"""

from . import snappy
from ._io import read_i16, read_u16, read_u32
from .messages import (
    BTN_A,
    BTN_B,
    BTN_DOWN,
    BTN_LEFT,
    BTN_RIGHT,
    BTN_SELECT,
    BTN_UP,
    MSG_CLEAR_OBJECTS,
    MSG_DEFINE_LAYER,
    MSG_DEFINE_OBJECT,
    MSG_DEFINE_SPRITE,
    MSG_DELETE_OBJECT,
    MSG_SET_VIEWPORT,
    PACKET_CHAT,
    PACKET_INPUT,
    ObjectPlacement,
    SpriteDef,
    mask_from_heading,
    pack_chat_packet,
    pack_input_packet,
    unpack_input_packet,
)
from .scene import SceneGraph

__all__ = [
    "snappy",
    "read_i16",
    "read_u16",
    "read_u32",
    "SpriteDef",
    "ObjectPlacement",
    "SceneGraph",
    "pack_input_packet",
    "unpack_input_packet",
    "pack_chat_packet",
    "mask_from_heading",
    "PACKET_INPUT",
    "PACKET_CHAT",
    "MSG_DEFINE_SPRITE",
    "MSG_DEFINE_OBJECT",
    "MSG_DELETE_OBJECT",
    "MSG_CLEAR_OBJECTS",
    "MSG_SET_VIEWPORT",
    "MSG_DEFINE_LAYER",
    "BTN_UP",
    "BTN_DOWN",
    "BTN_LEFT",
    "BTN_RIGHT",
    "BTN_SELECT",
    "BTN_A",
    "BTN_B",
]
