"""Cross-frame game state the engine doesn't stream, maintained across frames.

``read_world()`` is a per-frame snapshot; the engine never streams how many emergency
button calls I have left, how long the game has run, who my fellow imposters are, how much
kill cooldown remains (only a binary ready/not HUD), or kill/vent *events*. ``GameTracker``
carries all of that across frames and writes it onto each ``WorldState`` before the policy
sees it, so any swgy-base policy gets it for free (``run_session`` wires it in automatically).

Per tick:
    tracker.observe(world)        # before policy.act(): reset on new game, tick the clock,
                                  #   latch teammates, advance the kill-cooldown countdown,
                                  #   detect witnessed kill/vent, stamp everything on `world`
    action = policy.act(world)
    tracker.note_action(world, action)   # after: a fresh A-press on the button rect spends
                                  #   one of my calls (mirrors sim.nim tryCallButton)
"""

from __future__ import annotations

from collections import deque

from ..protocol.messages import BTN_A, BTN_DOWN, BTN_LEFT, BTN_RIGHT, BTN_UP
from .model import BUTTON_CALLS, BUTTON_RECT, KILL_COOLDOWN_TICKS, TASKS_PER_CREW, Phase, WorldState

# Any d-pad bit: the engine resets task progress on movement, so a hold tick counts only when A
# is pressed with NO direction (mirrors the gym's stationary A_TASK hold).
_MOVE_MASK = BTN_UP | BTN_DOWN | BTN_LEFT | BTN_RIGHT

# Crowd histogram: depth of the self-position trail (sim-ticks) and how many prior count-samples
# the obs carries. Mirrors the gym's node_hist (10) / crowd_hist (2). _TICKS_PER_EDGE is the gym's
# Croatoan grid-14 ticks_per_edge -- the history sampling cadence (engine frames per sim-tick).
_TRAIL_SIMTICKS = 10
_CROWD_HIST = 2
_TICKS_PER_EDGE = 7

_MESH = None


def _mesh():
    """The unified nav mesh -- now the SAME 908-node graph the gym trained on (incl. the 40 task
    stations). Counting crowd on it is exact: nearest_node + BFS<=2 == the gym's M.dist<=2."""
    global _MESH
    if _MESH is None:
        from ..nav import load_default_mesh

        _MESH = load_default_mesh()
    return _MESH


# A live game is any non-lobby, non-result phase; the clock runs through meetings too,
# matching the engine's MaxTicks (which counts every tick of the game).
_LIVE = (Phase.PLAYING, Phase.VOTING, Phase.VOTE_RESULT)
# A fresh game has just started when we enter PLAYING from one of these.
_PREGAME = (None, Phase.LOBBY, Phase.ROLE_REVEAL, Phase.GAME_OVER)
# Meeting phases; leaving one for PLAYING resets the kill cooldown (sim.nim, meeting end).
_MEETING = (Phase.VOTING, Phase.VOTE_RESULT)

# Witnessed-event heuristic thresholds (px). Conservative: a body counts as "fresh" only if
# it is not near a previously-seen body, and a kill is "witnessed" only when a player who was
# visible last frame vanished right where the fresh body appeared.
_BODY_SAME_PX = 8  # a body within this of a prior body is the same corpse, not a new one
_KILL_CORRELATE_PX = 40  # a vanished player this close to a fresh body == I saw them killed
_VENT_RANGE_PX = 16  # within this of a vent when they vanished == they vented (engine VentRange)


def _in_rect(p: tuple[int, int] | None, rect: tuple[int, int, int, int]) -> bool:
    if p is None:
        return False
    x, y, w, h = rect
    return x <= p[0] < x + w and y <= p[1] < y + h


def _d2(a: tuple[int, int], b: tuple[int, int]) -> int:
    return (a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2


class GameTracker:
    """Maintains the cross-frame fields on ``WorldState`` the engine never streams."""

    def __init__(self) -> None:
        self.reset()

    def reset(self) -> None:
        self.elapsed_ticks = 0
        self.ticks_since_meeting = 0
        self.button_calls_remaining = BUTTON_CALLS
        self.kill_cd = 0
        self.teammates: set[str] = set()
        self.suspicious: set[str] = set()
        self._prev_phase: Phase | None = None
        self._prev_a = False
        self._prev_kill_ready = False
        self._prev_others: dict[str, tuple[int, int]] = {}  # colour -> last living world pos
        self._prev_bodies: list[tuple[int, int]] = []  # last frame's visible body positions
        # Crew task progress (the engine streams neither remaining count nor mid-task). Accumulate
        # the tasks ever shown as mine; a task completes when its on-screen icon disappears while
        # I am still standing on its station holding A -- the engine removes a task's bubble the
        # instant it completes (global.nim), so we read that real signal rather than re-count ticks.
        self._assigned_tasks: set[int] = set()  # task k's ever shown assigned to me
        self._done_tasks: set[int] = set()  # task k's held to completion
        self._task_hold_k: int | None = None  # task k I'm currently holding
        self._task_hold_icon_seen = False  # its bubble was up during this hold
        # Crowd histogram: sim-tick-grained rings sampled every ticks_per_edge engine frames.
        self._crowd_subtick = 0  # engine frames since the last sim-tick sample
        self._crowd_ring: deque = deque(
            maxlen=_CROWD_HIST
        )  # last _CROWD_HIST count-samples (t-1, t-2)
        self._pos_ring: deque = deque(maxlen=_TRAIL_SIMTICKS)  # last _TRAIL_SIMTICKS self positions

    def observe(self, world: WorldState) -> WorldState:
        """Update all cross-frame state and stamp it onto ``world``. Call before act()."""
        phase = world.phase
        entering_play = phase is Phase.PLAYING and self._prev_phase in _PREGAME

        # New game: zero the clock/button and arm the start-of-game kill cooldown. Suspicions
        # are per-game; teammates are NOT cleared here -- they were latched at the preceding
        # ROLE_REVEAL (which is itself a _PREGAME phase, so it precedes this edge).
        if entering_play:
            self.elapsed_ticks = 0
            self.ticks_since_meeting = 0
            self.button_calls_remaining = BUTTON_CALLS
            self.kill_cd = KILL_COOLDOWN_TICKS
            self.suspicious = set()
            self._prev_a = False
            self._assigned_tasks = set()
            self._done_tasks = set()
            self._task_hold_k = None
            self._task_hold_icon_seen = False
            self._crowd_subtick = 0
            self._crowd_ring.clear()
            self._pos_ring.clear()

        # Fresh ROLE_REVEAL: a new game's reveal -- clear last game's team, then accumulate the
        # fellow-imposter colours streamed this phase (icons persist across the ~120-tick reveal).
        if phase is Phase.ROLE_REVEAL and self._prev_phase is not Phase.ROLE_REVEAL:
            self.teammates = set()
        if phase is Phase.ROLE_REVEAL:
            self.teammates |= world.role_reveal_colors

        if phase in _LIVE:
            self.elapsed_ticks += 1

        # danger clock: PLAYING ticks since the cooldown last refilled. Zero it on meeting end
        # (the kill cooldown re-arms there, same edge as _update_kill_cd); advance it only while
        # PLAYING (frozen through meetings); the game-start zero is handled by entering_play above.
        # Mirrors the gym's EnvState.ticks_since_meeting (advances in MOVE, reset at meeting END).
        if self._prev_phase in _MEETING and phase is Phase.PLAYING:
            self.ticks_since_meeting = 0
        elif phase is Phase.PLAYING and not entering_play:
            self.ticks_since_meeting += 1

        self._update_kill_cd(world)
        self._update_events(world)

        # Crew tasks: accumulate the tasks shown as mine this frame (arrows/bubbles vanish once a
        # task is on-screen, so we must remember). Completion is counted in note_action (it needs
        # the A-press); here we just stamp the carried remaining-count + mid-task flag.
        if phase is Phase.PLAYING:
            self._assigned_tasks |= world.visible_assigned_task_ks()
            self._update_crowd(world)

        self._prev_phase = phase
        world.elapsed_ticks = self.elapsed_ticks
        world.ticks_since_meeting = self.ticks_since_meeting
        world.button_calls_remaining = self.button_calls_remaining
        world.tasks_remaining = max(0, TASKS_PER_CREW - len(self._done_tasks))
        world.task_active = self._task_hold_k is not None
        world.remaining_task_ks = tuple(sorted(self._assigned_tasks - self._done_tasks))
        world.teammates = self.teammates
        world.kill_cd = self.kill_cd
        world.suspicious = self.suspicious
        return world

    def _update_kill_cd(self, world: WorldState) -> None:
        """Reconstruct the graded kill cooldown (engine ticks remaining) from the binary HUD.

        Reset to full on meeting end and after a kill (HUD ready->not edge); decrement each
        PLAYING tick; resync to the HUD so it can't drift past the real ready boundary.
        """
        if self._prev_phase in _MEETING and world.phase is Phase.PLAYING:
            self.kill_cd = KILL_COOLDOWN_TICKS  # meeting end re-arms cooldown
        if self._prev_kill_ready and not world.kill_ready and world.phase is Phase.PLAYING:
            self.kill_cd = KILL_COOLDOWN_TICKS  # ready->not == I just killed
        if world.phase is Phase.PLAYING and self.kill_cd > 0:
            self.kill_cd -= 1
        if world.kill_ready:
            self.kill_cd = 0  # HUD is ground truth at the 0 boundary
        elif self.kill_cd <= 0:
            self.kill_cd = 1  # not-ready yet: hold just above 0
        self._prev_kill_ready = world.kill_ready

    def _update_events(self, world: WorldState) -> None:
        """Conservative, high-confidence kill/vent witnessing (only while PLAYING with a map).

        A *fresh* body (not near a prior body) where a player who was visible last frame has now
        vanished == a witnessed kill. A player who vanished from right beside a vent (and not at a
        fresh body) == a witnessed vent -> mark that colour suspicious. Outside PLAYING the world
        teleports/clears, so we reset the prior-frame memory to avoid false events on return.
        """
        world.witnessed_kill = False
        world.witnessed_vent = False
        if world.phase is not Phase.PLAYING or world.me_world is None:
            self._prev_others = {}
            self._prev_bodies = []
            return

        living = {a.color: (a.x, a.y) for a in world.living_others()}
        fresh = [
            b
            for b in world.bodies
            if all(_d2(b, pb) > _BODY_SAME_PX**2 for pb in self._prev_bodies)
        ]
        vanished = {c: p for c, p in self._prev_others.items() if c not in living}

        for color, last in vanished.items():
            near_fresh = any(_d2(last, b) <= _KILL_CORRELATE_PX**2 for b in fresh)
            if near_fresh:
                world.witnessed_kill = True  # saw them drop where a body appeared
            elif world.vents and min(_d2(last, v) for v in world.vents) <= _VENT_RANGE_PX**2:
                world.witnessed_vent = True  # vanished from on a vent -> vented
                self.suspicious.add(color)

        self._prev_others = living
        self._prev_bodies = list(world.bodies)

    def _update_crowd(self, world: WorldState) -> None:
        """Count visible living others by nav-graph hop (0/1/2) + maintain the sim-tick rings.

        Counts on the unified mesh (== the gym's 908-node graph): my collision point and each
        visible living other -> nearest node -> hop bucket via BFS<=2 (same/1-hop/2-hop sets).
        Exact vs the gym's M.dist. The obs history (t-1/t-2 counts; my position ~10 sim-ticks ago)
        is sampled every _TICKS_PER_EDGE engine frames so it lands on the gym's sim-tick grid;
        between samples the rings hold. Mirrors the gym's observe(): stamp from the carried rings,
        THEN push this frame at a sim-tick boundary.
        """
        mesh = _mesh()
        me = world.me_collision
        if me is None:
            return
        my_node = mesh.nearest_node(*me)
        hop1 = {nid for nid, _, _ in mesh.neighbors(my_node)}
        hop2 = set()
        for nid in hop1:
            hop2 |= {n for n, _, _ in mesh.neighbors(nid)}
        hop2 -= hop1
        hop2.discard(my_node)
        counts = [0, 0, 0]
        for a in world.living_others():
            onode = mesh.nearest_node(a.x, a.y)
            if onode == my_node:
                counts[0] += 1
            elif onode in hop1:
                counts[1] += 1
            elif onode in hop2:
                counts[2] += 1
        world.crowd_counts = (counts[0], counts[1], counts[2])
        # history from the rings (newest sample == t-1); pad with zeros while warming up
        ring = list(self._crowd_ring)
        t1 = ring[-1] if len(ring) >= 1 else (0, 0, 0)
        t2 = ring[-2] if len(ring) >= 2 else (0, 0, 0)
        world.crowd_hist = (*t1, *t2)
        world.self_xy_10ago = self._pos_ring[0] if len(self._pos_ring) == _TRAIL_SIMTICKS else me
        # sim-tick boundary: push this frame's count + position for future ticks
        self._crowd_subtick += 1
        if self._crowd_subtick >= _TICKS_PER_EDGE:
            self._crowd_subtick = 0
            self._crowd_ring.append((counts[0], counts[1], counts[2]))
            self._pos_ring.append(me)

    def note_action(self, world: WorldState, action) -> None:
        """Spend a button call on a fresh A-press on the button rect. Call after act().

        Mirrors ``sim.nim::tryCallButton``: only counts while PLAYING, on a rising A edge,
        with my collision point inside the button rect and a call still available -- so a
        press on a spent button (the no-op) does not double-decrement.
        """
        a_now = bool(action.buttons & BTN_A)
        fresh_a = a_now and not self._prev_a
        if (
            world.phase is Phase.PLAYING
            and fresh_a
            and self.button_calls_remaining > 0
            and _in_rect(world.me_collision, BUTTON_RECT)
        ):
            self.button_calls_remaining -= 1
            world.button_calls_remaining = self.button_calls_remaining
        self._prev_a = a_now
        self._update_tasks(world, action)

    def _update_tasks(self, world: WorldState, action) -> None:
        """Mark a task done off the engine's real completion signal -- the task icon vanishing --
        not a tick count. The engine drops a task's on-screen bubble the instant it completes
        (global.nim) while the always-streamed marker rect stays, so: a task I was holding (its
        bubble had been up) is done the moment its icon is gone *while I'm still standing in its
        rect*. The in-rect guard distinguishes completion from simply walking away (bubble also
        gone, but I've left the station). The policy latches A on the station until this fires."""
        mc = world.me_collision
        iconed = world.visible_assigned_task_ks()  # tasks currently showing an arrow/bubble

        # Completion: my held task's icon disappeared while I'm still on its station.
        hk = self._task_hold_k
        if (
            hk is not None
            and hk not in self._done_tasks
            and self._task_hold_icon_seen
            and hk not in iconed
            and mc is not None
            and _in_rect(mc, world.task_rect(hk) or (0, 0, 0, 0))
        ):
            self._done_tasks.add(hk)
            self._task_hold_k, self._task_hold_icon_seen = None, False
            world.tasks_remaining = max(0, TASKS_PER_CREW - len(self._done_tasks))
            world.task_active = False
            return

        # Otherwise, track the current hold: A pressed with no d-pad (the engine zeros progress on
        # movement) while my collision point is inside an assigned, not-yet-done task rect.
        holding = (
            world.phase is Phase.PLAYING
            and bool(action.buttons & BTN_A)
            and not (action.buttons & _MOVE_MASK)
        )
        k = None
        if holding and mc is not None:
            for cand in self._assigned_tasks:
                if cand not in self._done_tasks and _in_rect(
                    mc, world.task_rect(cand) or (0, 0, 0, 0)
                ):
                    k = cand
                    break
        if k is None:
            self._task_hold_k, self._task_hold_icon_seen = None, False
            return
        if self._task_hold_k != k:
            self._task_hold_k, self._task_hold_icon_seen = k, False
        if k in iconed:
            self._task_hold_icon_seen = True
