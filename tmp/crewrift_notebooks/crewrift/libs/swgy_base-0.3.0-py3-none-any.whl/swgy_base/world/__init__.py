"""Scene -> world model.

Turn the sprite/object tables from `protocol` into a semantic snapshot:
    - camera = (-map_obj.x, -map_obj.y)  (drift-free; no localization)
    - roster: per-color/slot player position, alive/ghost (labels
      "player <color>", "ghost <color>", "selected ..."; flip via "... left")
    - bodies: "body <color>"
    - tasks: "task bubble" / "task arrow"
    - kill availability: "imposter icon" / "imposter icon cooldown"
    - progress: "task counter N" / "progress bar N%"
    - phase: map present => Playing; else text screens (SKIP, CREW WINS,
      IMPS WIN, CREWMATE, ...)
    - vote ballot: vote-icon objects (id base 9300 + slot)

Object-ID bases (recover slot): players 1000, chat 9200, vote 9300, etc.
Crib classification + bases from sprite_player_protocol.py.

`read_world(scene)` returns a `WorldState` carrying the phase (`phase_of`), the
camera, the controlled avatar position, the roster (per-colour players,
alive/ghost), bodies, vents, the on-screen `task arrow` clues / `task bubble`
markers, and the decoded vote tally. `WorldState.candidate_tasks(mesh)` bridges
arrows to `NavMesh.tasks_toward`, turning the UI direction clue into routable
task candidates. `GameTracker` layers on the cross-tick state a single snapshot
can't hold (teammate, kill cooldown, witnessed events).
"""

from .model import BUTTON_CALLS, BUTTON_RECT, VIEW_TO_COLLISION, Actor, Phase, TaskArrow, WorldState
from .reader import phase_of, read_world
from .tracker import GameTracker

__all__ = [
    "WorldState",
    "TaskArrow",
    "Actor",
    "Phase",
    "VIEW_TO_COLLISION",
    "BUTTON_CALLS",
    "BUTTON_RECT",
    "GameTracker",
    "read_world",
    "phase_of",
]
