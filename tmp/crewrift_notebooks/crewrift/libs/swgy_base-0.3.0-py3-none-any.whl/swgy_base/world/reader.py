"""Read a WorldState slice from a parsed sprite_v1 SceneGraph.

In the per-player view the camera centers on the controlled player with no
clamping (CrewRift ``sim.nim:playerView``), so **the viewport center IS my
position** -- no need to identify my own avatar by label (the in-world avatar is
just ``player <color>`` here; the ``selected`` sprites are only the global
spectator viewer). Objects are identified by sprite label (global.nim):
  - ``map``         -> camera / world origin (the map sprite sits at ``-camera``)
  - ``task arrow``  -> off-screen assigned-task direction clue
  - ``task bubble`` -> on-screen assigned-task marker (we're near it)

Phase is recovered exactly like the reference parser
(``sprite_player_protocol.py:_phase``): the ``map`` sprite streams only while
playing, so its presence => PLAYING; otherwise the active screen carries a text
label we keyword-match.
"""

from __future__ import annotations

from .model import (
    COLOURS,
    MARKER_BASE,
    MAX_PLAYERS,
    VOTE_DOT_BASE,
    VOTE_ICON_BASE,
    VOTE_SKIP_DOT_BASE,
    Actor,
    Phase,
    TaskArrow,
    WorldState,
)

_ACTOR_PREFIXES = ("player ", "ghost ", "body ")
_COLOURS_SET = set(COLOURS)


def _colour_of_label(label: str) -> str:
    """Colour from a "player/ghost/body <colour> [<dir>]" label -- the LONGEST known colour after the
    role word (so "light blue" / "dark navy" aren't truncated to "light" / "dark", which collides)."""
    rest = label.lower().split()[1:]
    if len(rest) >= 2 and " ".join(rest[:2]) in _COLOURS_SET:
        return " ".join(rest[:2])
    return rest[0] if rest else ""


def _decode_vote_tally(scene) -> tuple[dict[str, int], int, tuple[str, ...]]:
    """Recover the live vote tally + the cursor's candidate order from the voting-screen objects.

    Candidate avatars (VOTE_ICON_BASE+idx) carry the player's "player/ghost/body <colour>" sprite,
    giving idx->colour and alive (alive == "player ..."). Vote dots (VOTE_DOT_BASE +
    target*MAX_PLAYERS + voter) say voter voted for target; skip dots (VOTE_SKIP_DOT_BASE + voter)
    say voter skipped. Returns (votes-by-colour, skip count, vote_order) where vote_order is the
    LIVING candidates in index order -- the cursor cycle (then SKIP) a follower steps to reach a
    target. Colour keyed like the roster (``_colour_of_label(label)``) so it joins to perceive()'s slots.
    """
    idx_colour: dict[int, str] = {}
    idx_alive: dict[int, bool] = {}
    for oid, obj in scene.objects.items():
        if VOTE_ICON_BASE <= oid < VOTE_ICON_BASE + MAX_PLAYERS:
            sprite = scene.sprites.get(obj.sprite_id)
            if sprite is None:
                continue
            label = sprite.label.lower()
            if any(label.startswith(p) for p in _ACTOR_PREFIXES):
                idx_colour[oid - VOTE_ICON_BASE] = _colour_of_label(label)
                idx_alive[oid - VOTE_ICON_BASE] = label.startswith("player ")
    votes: dict[str, int] = {}
    skip = 0
    for oid in scene.objects:
        if VOTE_DOT_BASE <= oid < VOTE_DOT_BASE + MAX_PLAYERS * MAX_PLAYERS:
            colour = idx_colour.get((oid - VOTE_DOT_BASE) // MAX_PLAYERS)
            if colour is not None:
                votes[colour] = votes.get(colour, 0) + 1
        elif VOTE_SKIP_DOT_BASE <= oid < VOTE_SKIP_DOT_BASE + MAX_PLAYERS:
            skip += 1
    order = tuple(idx_colour[i] for i in sorted(idx_colour) if idx_alive.get(i))
    return votes, skip, order


# A streamed "player <colour>" object within this many px of my own world
# position is MY avatar (the camera centers on me), not another player.
_SELF_RADIUS_PX = 24

# The engine streams an other player's sprite at ``other.x - SpriteDrawOffX - 1`` /
# ``other.y - SpriteDrawOffY - 1`` (global.nim), i.e. the sprite-draw position, NOT the
# 1x1 collision point the sim tests against the kill range. Add it back so an other's
# world coords ARE its collision point -- matching ``me_collision`` and the engine, so
# kill-range/proximity distances are exact (SpriteDrawOffX=2, SpriteDrawOffY=8).
_OTHER_TO_COLLISION = (3, 9)  # (SpriteDrawOffX + 1, SpriteDrawOffY + 1)


def phase_of(scene) -> Phase:
    """Classify the coarse game phase from the scene's sprites/objects."""
    labels = []
    map_present = False
    for obj in scene.objects.values():
        sprite = scene.sprites.get(obj.sprite_id)
        if sprite is None:
            continue
        if sprite.label.lower() == "map":
            map_present = True
        labels.append(sprite.label)
    if map_present:
        return Phase.PLAYING
    text = " ".join(labels).upper()
    if "SKIP" in text:
        return Phase.VOTING
    if "WAS KILLED" in text or "NO ONE" in text or "DIED" in text:
        return Phase.VOTE_RESULT
    if "CREW WINS" in text or "IMPS WIN" in text or "DRAW" in text:
        return Phase.GAME_OVER
    if "CREWMATE" in text or "IMPS" in text:
        return Phase.ROLE_REVEAL
    return Phase.LOBBY


def read_world(scene) -> WorldState:
    """Extract phase, camera, my (centered) position, and task markers."""
    state = WorldState()
    state.phase = phase_of(scene)
    if state.phase is Phase.VOTING:  # decode the live vote tally from the voting-screen dot objects
        state.vote_tally, state.vote_skip_count, state.vote_order = _decode_vote_tally(scene)
    # The camera centers on us, so screen center == my position.
    state.me_screen = (scene.viewport_width // 2, scene.viewport_height // 2)
    actors_screen: list[Actor] = []  # roster in SCREEN coords; -> world below
    bodies_screen: list[tuple[int, int]] = []
    for object_id, obj in scene.objects.items():
        sprite = scene.sprites.get(obj.sprite_id)
        if sprite is None:
            continue
        label = sprite.label.lower()
        if label == "map":
            state.map_origin = (obj.x, obj.y)
        elif label == "task arrow":
            state.arrows.append(TaskArrow(object_id=object_id, x=obj.x, y=obj.y))
        elif label == "task bubble":
            state.task_bubbles.append((obj.x, obj.y))
        elif label == "task" and object_id >= MARKER_BASE:
            # Invisible exact task marker (id MARKER_BASE+k): top-left + rect size
            # (the marker sprite's w/h equals the sim's task rect), world-frame.
            k = object_id - MARKER_BASE
            state.task_markers[k] = (obj.x, obj.y)
            state.task_marker_dims[k] = (sprite.width, sprite.height)
        elif label.startswith("vent") and object_id >= MARKER_BASE:
            # "vent*" map marker (world-frame rect): store its centre for on_vent().
            state.vents.append((obj.x + sprite.width // 2, obj.y + sprite.height // 2))
        elif label == "vote skip cursor":
            state.vote_cursor_on_skip = True
        elif label == "vote cursor" and state.vote_cursor_on_skip is None:
            state.vote_cursor_on_skip = False
        elif label.startswith("imposter icon"):  # my kill button -> I'm the imposter
            state.me_is_imposter = True
            state.kill_ready = state.kill_ready or label == "imposter icon"  # vs "... cooldown"
        elif label.startswith("player "):  # "player <colour> <dir>" -> living other
            actors_screen.append(Actor(_colour_of_label(label), obj.x, obj.y, True))
        elif label.startswith("ghost ") and label != "ghost icon":  # dead other
            actors_screen.append(Actor(_colour_of_label(label), obj.x, obj.y, False))
        elif label.startswith("body "):
            bodies_screen.append((obj.x, obj.y))
    # Without a map object we can't place ourselves -- or anyone -- in world coords.
    if state.map_origin is None:
        # ROLE_REVEAL streams no map, but the "player <colour>" icons present this phase
        # are the reveal itself -- for an imposter viewer, exactly my team (incl. me).
        # GameTracker latches these into world.teammates and carries them into PLAYING.
        if state.phase is Phase.ROLE_REVEAL:
            state.role_reveal_colors = {a.color for a in actors_screen}
        state.me_screen = None
        return state
    ox, oy = state.map_origin  # world = screen - map_origin (camera back-out)
    cx, cy = _OTHER_TO_COLLISION  # sprite-draw -> collision point
    me = state.me_collision  # compare in the collision frame (self -> ~0px)
    others: list[Actor] = []
    dropped_self = False
    for a in sorted(
        actors_screen,
        key=lambda a: (a.x - state.me_screen[0]) ** 2 + (a.y - state.me_screen[1]) ** 2,
    ):
        wx, wy = a.x - ox + cx, a.y - oy + cy  # other's collision point in world coords
        if (
            not dropped_self
            and me is not None
            and (wx - me[0]) ** 2 + (wy - me[1]) ** 2 <= _SELF_RADIUS_PX**2
        ):
            # The camera centers on my avatar, so the nearest actor at my position is me --
            # alive ("player <colour>") or, once I die, a ghost ("ghost <colour>"). Drop it
            # from ``others`` either way and latch my own liveness (a ghost self leaked into
            # ``others`` before, and me_alive stayed True -> the net never knew it was dead).
            dropped_self = True
            state.me_alive = a.alive
            continue
        others.append(Actor(a.color, wx, wy, a.alive))
    state.others = others
    state.bodies = [(bx - ox + cx, by - oy + cy) for bx, by in bodies_screen]
    return state
