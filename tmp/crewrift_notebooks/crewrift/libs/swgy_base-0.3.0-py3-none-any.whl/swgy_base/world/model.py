"""World-model types for the live task-arrow wiring.

A minimal first slice of the scene -> world model: enough to turn the on-screen
``task arrow`` UI clue into a nav query. The arrow and the controlled avatar are
both on the camera-baked map layer, so the arrow direction
(``arrow_pos - my_screen_pos``) is the exact world-direction to the task; the
avatar's world position is ``my_screen_pos - map_origin`` (the map sprite sits at
``-camera``). Feed those to ``NavMesh.tasks_toward`` to recover candidate tasks.
"""

from __future__ import annotations

import enum
from dataclasses import dataclass, field


class Phase(enum.Enum):
    """Coarse game phase, recovered from which screens/objects are on stream.

    Mirrors the reference parser's phase split (``sprite_player_protocol.py``):
    the **map** sprite is only streamed while playing, so its presence is the
    PLAYING tell; every other phase shows a text/screen sprite we keyword-match.
    """

    LOBBY = "lobby"
    ROLE_REVEAL = "role_reveal"
    PLAYING = "playing"
    VOTING = "voting"
    VOTE_RESULT = "vote_result"
    GAME_OVER = "game_over"


# Object-id bases (global.nim / addMapMarkers): an assigned off-screen task's
# arrow is ARROW_BASE+k; the always-streamed exact marker for task k is
# MARKER_BASE+k. Same k indexes ``sim.tasks``.
ARROW_BASE = 7000
MARKER_BASE = 20000

# Voting-screen object-id bases (global.nim). The candidate avatar for player index `idx` is
# VOTE_ICON_BASE+idx (its sprite is the normal "player/ghost/body <colour>" avatar, so idx->colour
# is readable). A vote dot is VOTE_DOT_BASE + target*MAX_PLAYERS + voter (voter voted for target);
# a skip dot is VOTE_SKIP_DOT_BASE + voter. Decoding these recovers the full live vote tally.
MAX_PLAYERS = 16
# Engine player colours (sim.nim PlayerColorNames). Several are TWO words ("light blue", "dark
# navy"); a sprite label is "player/ghost/body <colour> [<dir>]", so the colour must be matched as
# the longest known colour after the role word -- a naive split()[1] both truncates ("light blue"
# -> "light") AND collides ("dark brown/teal/navy" -> "dark"), misattributing roster + votes.
COLOURS = (
    "red",
    "orange",
    "yellow",
    "light blue",
    "pink",
    "lime",
    "blue",
    "pale blue",
    "gray",
    "white",
    "dark brown",
    "brown",
    "dark teal",
    "green",
    "dark navy",
    "black",
)
VOTE_ICON_BASE = 9300
VOTE_DOT_BASE = 10100
VOTE_SKIP_DOT_BASE = 10400

# The viewport centers on the player *sprite*, which sits at a fixed offset from
# the 1x1 collision point the sim tests against task/kill rects. From
# ``sim.nim:playerView``, ``me_world == (player.x + 4, player.y - 2)``, so the
# true collision point is ``me_world + VIEW_TO_COLLISION``. Standing the
# collision point inside a task rect (with A held, no d-pad) completes the task.
VIEW_TO_COLLISION = (-4, 2)

# Emergency meeting button (engine ``sim.nim``): ONE call per player per game
# (``ButtonCalls = 1``); pressing a spent button is a silent no-op. The engine never
# streams calls-remaining, so the runtime tracks it (``GameTracker``). The button is a
# 28x34 rect centered on the home room (Bridge) center -- ``centeredMapRect(home, 28, 34)``
# in sim.nim; the croatoan Bridge center is ~(181, 346) from the nav-mesh build.
BUTTON_CALLS = 1
BUTTON_RECT = (167, 329, 28, 34)  # (x, y, w, h) world coords, top-left

# Engine kill cooldown (``sim.nim`` KillCooldownTicks): set at game start, after every
# kill, and on meeting end; decremented one tick at a time. The engine streams only the
# binary ready/not HUD, so GameTracker reconstructs the graded countdown from it.
KILL_COOLDOWN_TICKS = 500

# Crew task load (CrewRift Croatoan: ``tasksPerPlayer``) and the engine ticks of stationary
# in-rect A-holding that complete one task (``sim.nim`` TaskTicks). The engine streams neither
# my remaining-task count nor whether I'm mid-task, so GameTracker reconstructs both from the
# assigned-task arrows + my A-holds (mirrors the gym's EnvState.task_remaining / task_active).
TASKS_PER_CREW = 8
TASK_TICKS = 72


@dataclass(frozen=True)
class TaskArrow:
    """An on-screen ``task arrow`` object (screen-frame position + object id)."""

    object_id: int
    x: int
    y: int

    @property
    def task_index(self) -> int:
        """Task index ``k`` (``object_id - ARROW_BASE``); pairs with marker k."""
        return self.object_id - ARROW_BASE


@dataclass(frozen=True)
class Actor:
    """Another player seen this frame, in world/map-pixel coords.

    The engine only streams a player object when it is visible to me
    (``global.nim`` gates on ``screenPointVisible``), so an Actor's presence ==
    I can currently see them -- this *is* the on-screen vision model. Identity is
    the player's colour name (stable across frames); ``alive`` is False for a
    ``ghost``. Position carries the small sprite draw-offset, negligible vs the
    ~1235x659 map.
    """

    color: str
    x: int
    y: int
    alive: bool


@dataclass
class WorldState:
    """The slice we read for task-finding: phase, camera, controlled avatar, tasks."""

    phase: Phase = Phase.LOBBY
    map_origin: tuple[int, int] | None = None  # the "map" object's (x, y) = -camera
    me_screen: tuple[int, int] | None = None  # camera center == my position, screen frame
    arrows: list[TaskArrow] = field(default_factory=list)
    # On-screen "task bubble" markers (our own assigned tasks), screen-frame.
    # Their presence means a task is in view -- walk to it and hold A.
    task_bubbles: list[tuple[int, int]] = field(default_factory=list)
    # Exact task rects in WORLD coords, keyed by task index k -- from the
    # invisible "task" map markers (object id 20000+k) streamed for every task.
    # ``task_markers[k]`` is the rect's top-left (the marker object position, in
    # world coords -- map-layer objects carry no camera offset) and
    # ``task_marker_dims[k]`` its (w, h) (the marker sprite size = sim task rect).
    # An assigned off-screen task's arrow has id 7000+k (same k), so the arrow
    # names *which* tasks are ours and the marker gives the exact rect to stand in.
    task_markers: dict[int, tuple[int, int]] = field(default_factory=dict)
    task_marker_dims: dict[int, tuple[int, int]] = field(default_factory=dict)
    # Voting-screen cursor: True when it rests on SKIP ("vote skip cursor"),
    # False when on a player cell ("vote cursor"), None when no cursor is shown.
    # The engine steps the cursor one cell per LEFT/RIGHT press *edge*; confirm
    # the highlighted choice with A. (Labels per the reference reader.)
    vote_cursor_on_skip: bool | None = None
    # Live vote tally decoded from the voting-screen dot objects (read_world): how many have voted
    # for each candidate (by colour) and how many skipped, this frame. The FOLLOW signal -- a single
    # seat can't lead an ejection but can tip one already forming.
    vote_tally: dict[str, int] = field(default_factory=dict)  # colour -> votes received so far
    vote_skip_count: int = 0  # how many have voted SKIP so far
    vote_order: tuple[str, ...] = ()  # living candidate colours in cursor order
    # Roster + role, recovered from the actor/HUD sprites (global.nim):
    #   "player <colour> <dir>" -> a living other; "ghost <colour> <dir>" -> dead;
    #   "body <colour>" -> a corpse; "imposter icon"[ " cooldown"] -> MY kill button
    #   (present only for imposters; "cooldown" variant => kill not ready).
    # Only *visible* others are streamed, so ``others`` is exactly who I can see.
    me_is_imposter: bool = False
    # Am I (the focal/camera player) still alive? The camera centers on my avatar, drawn
    # "player <colour>" while alive and "ghost <colour>" once I die (a ghost viewer sees
    # ghosts; global.nim draws the self avatar unculled). read_world sets this from the
    # self avatar's sprite; a crew ghost (me_alive False, not imposter) still tasks but
    # cannot report -- the legal mask gates REPORT on alive.
    me_alive: bool = True
    kill_ready: bool = False
    others: list[Actor] = field(default_factory=list)  # visible other players, world coords
    bodies: list[tuple[int, int]] = field(default_factory=list)  # visible bodies, world coords
    # Vent rect centers (world coords), from the always-streamed "vent*" map markers.
    # Static map geometry; an imposter within ~16px (center-to-center) can vent.
    vents: list[tuple[int, int]] = field(default_factory=list)
    # During ROLE_REVEAL the engine streams an imposter viewer ONLY the fellow-imposter
    # player icons ("player <colour> <dir>", ids 9500+; global.nim addProtocolRoleRevealActorSprites),
    # so this frame's colours ARE my imposter team (incl. me). read_world fills it that phase
    # only; GameTracker latches it into ``teammates`` and carries it through PLAYING.
    role_reveal_colors: set[str] = field(default_factory=set)
    # Cross-frame state the engine does NOT stream -- maintained by GameTracker (runtime)
    # and overwritten onto each snapshot before the policy sees it. read_world() leaves
    # these at the defaults.
    elapsed_ticks: int = 0  # engine ticks since this game started
    # PLAYING engine ticks since the imposter kill cooldown last refilled (game start / meeting
    # end) -- the "danger clock" the crew net reads to time a proactive emergency button. Shares
    # its reset points with ``kill_cd`` (a recoverable lower bound on imposter kill readiness).
    ticks_since_meeting: int = 0
    button_calls_remaining: int = BUTTON_CALLS  # my emergency-button calls left this game
    # Crew task progress (GameTracker; the engine streams neither). ``tasks_remaining`` counts my
    # assigned tasks not yet held to completion (starts at TASKS_PER_CREW); ``task_active`` is True
    # while I'm mid-hold on a task this frame. Both feed the crew net's obs (== gym task_remaining /
    # task_active). For an imposter they stay at the defaults (no task arrows -> nothing to track).
    tasks_remaining: int = TASKS_PER_CREW
    task_active: bool = False
    # My assigned tasks not yet completed (accumulated arrows minus done), for target selection --
    # a task stays here even when its arrow/bubble is off-screen, until GameTracker counts it done.
    remaining_task_ks: tuple[int, ...] = ()
    # Crowd histogram (GameTracker, on the gym hop-graph): # of visible living others at graph hop
    # 0/1/2 -- now (crowd_counts), and at the two prior sim-ticks (crowd_hist = t-1 triple then t-2
    # triple). self_xy_10ago: my world position ~10 sim-ticks ago (the self-trace base; None at game
    # start -> zero displacement). Feed the net's crowd obs block (== gym crowd_now/crowd_hist/xy10).
    crowd_counts: tuple[int, int, int] = (0, 0, 0)
    crowd_hist: tuple[int, ...] = (0, 0, 0, 0, 0, 0)
    self_xy_10ago: tuple[int, int] | None = None
    teammates: set[str] = field(default_factory=set)  # fellow-imposter colours (latched at reveal)
    # Graded kill cooldown in ENGINE TICKS remaining (0 == ready), reconstructed by GameTracker
    # from the binary HUD ``kill_ready`` (engine streams only ready/not). 0..KILL_COOLDOWN_TICKS.
    kill_cd: int = 0
    # High-confidence event flags for THIS frame (GameTracker, conservative heuristics): a kill
    # / a vent happened in my view this tick. ``suspicious`` persists: colours I saw vent.
    witnessed_kill: bool = False
    witnessed_vent: bool = False
    suspicious: set[str] = field(default_factory=set)

    @property
    def camera(self) -> tuple[int, int] | None:
        if self.map_origin is None:
            return None
        return (-self.map_origin[0], -self.map_origin[1])

    @property
    def me_world(self) -> tuple[int, int] | None:
        """Controlled avatar position in world/map-pixel coords (sprite center)."""
        if self.me_screen is None or self.map_origin is None:
            return None
        return (self.me_screen[0] - self.map_origin[0], self.me_screen[1] - self.map_origin[1])

    @property
    def me_collision(self) -> tuple[int, int] | None:
        """My true 1x1 collision point in world coords -- what the sim tests
        against task/kill/button rects (``me_world`` is the sprite center, offset).
        Verified vs sim.nim: CollisionW==CollisionH==1, so the sim tests
        ``(p.x + CollisionW div 2, p.y + ...)`` == ``(p.x, p.y)``, and
        ``me_world + VIEW_TO_COLLISION`` recovers exactly that point."""
        if self.me_world is None:
            return None
        return (self.me_world[0] + VIEW_TO_COLLISION[0], self.me_world[1] + VIEW_TO_COLLISION[1])

    def arrow_bearings(self) -> list[tuple[int, int]]:
        """Direction vector to each arrow's task (``arrow - me``), screen frame."""
        if self.me_screen is None:
            return []
        mx, my = self.me_screen
        return [(a.x - mx, a.y - my) for a in self.arrows]

    def nearest_task_bubble(self) -> tuple[int, int] | None:
        """Offset ``(dx, dy)`` to the closest on-screen task bubble, or ``None``.

        Screen pixels are 1:1 with world pixels, so the returned offset doubles
        as both a steer direction and a distance (``hypot``) to gate ``hold A``.
        """
        if self.me_screen is None or not self.task_bubbles:
            return None
        mx, my = self.me_screen
        best = min(self.task_bubbles, key=lambda b: (b[0] - mx) ** 2 + (b[1] - my) ** 2)
        return (best[0] - mx, best[1] - my)

    def task_rect(self, k: int) -> tuple[int, int, int, int] | None:
        """World-coord rect ``(x, y, w, h)`` for task ``k`` from its marker.

        Markers (id ``20000+k``) are streamed for *every* task on/off screen, so
        this resolves a task's exact rect regardless of visibility. Stand the
        collision point (``me_collision``) inside it and hold A to complete it.
        """
        if k not in self.task_markers:
            return None
        x, y = self.task_markers[k]
        w, h = self.task_marker_dims.get(k, (0, 0))
        return (x, y, w, h)

    def visible_assigned_task_ks(self) -> set[int]:
        """Task indices currently shown as mine-and-incomplete.

        A task is mine while it shows an arrow (off-screen, id ``7000+k``) or a
        ``task bubble`` (on-screen). Bubbles carry no ``k``, so each is matched
        to its nearest marker. A *completing* policy should accumulate these
        across ticks (a task vanishes from this set the moment it goes on-screen
        with bubbles off, or completes) and only drop a task once actually done.
        """
        ks: set[int] = {a.task_index for a in self.arrows if a.task_index in self.task_markers}
        for bx, by in self.task_bubbles:
            best, best_d2 = None, None
            for k, (mx, my) in self.task_markers.items():
                d2 = (mx - bx) ** 2 + (my - by) ** 2
                if best_d2 is None or d2 < best_d2:
                    best, best_d2 = k, d2
            if best is not None and best_d2 is not None and best_d2 <= 24 * 24:
                ks.add(best)
        return ks

    def candidate_tasks(self, mesh, half_angle_deg: float = 20.0, max_dist: float | None = None):
        """Per task arrow, the candidate task stations it could point to.

        Bridges the live UI clue to the static nav-mesh: returns
        ``[(arrow, [TaskStation ranked]), ...]``. Empty if the avatar or map
        origin is unknown (can't place the bearing in world coords).
        """
        if self.me_world is None or self.me_screen is None:
            return []
        mx, my = self.me_screen
        out = []
        for a in self.arrows:
            bearing = (a.x - mx, a.y - my)
            out.append((a, mesh.tasks_toward(self.me_world, bearing, half_angle_deg, max_dist)))
        return out

    def living_others(self) -> list[Actor]:
        """Visible, still-alive other players."""
        return [a for a in self.others if a.alive]

    def nearest_living_other(self) -> tuple[Actor, float] | None:
        """Closest living visible other and its distance (px), or None."""
        me = self.me_world
        if me is None:
            return None
        best, best_d2 = None, None
        for a in self.living_others():
            d2 = (a.x - me[0]) ** 2 + (a.y - me[1]) ** 2
            if best_d2 is None or d2 < best_d2:
                best, best_d2 = a, d2
        return (best, best_d2**0.5) if best is not None else None

    def on_vent(self, within: float = 16.0) -> bool:
        """Am I within vent range (center-to-center) of any vent? (engine: 16px)."""
        me = self.me_world
        if me is None or not self.vents:
            return False
        return min((v[0] - me[0]) ** 2 + (v[1] - me[1]) ** 2 for v in self.vents) <= within * within
