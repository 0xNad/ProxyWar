"""Knob declaration framework.

The model: a policy declares a :class:`KnobSpec` of :class:`Knob` entries. The
spec maps the knobs to and from a flat float vector (the GA *genome*) in a
stable order, and validates candidate values against each knob's bounds. A
genetic-algorithm harness consumes only this vector view, so it stays decoupled
from the policy internals.

The vector order is the declaration order of ``KnobSpec.knobs`` and is the sole
genome contract: index ``i`` is always ``knobs[i]``.
"""

from __future__ import annotations

import random
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field


@dataclass(frozen=True)
class Knob:
    """One tunable parameter: a name, inclusive ``[low, high]`` bounds, a default.

    ``default`` must lie within the bounds; :class:`KnobSpec` validates this.
    """

    name: str
    low: float
    high: float
    default: float

    def clamp(self, value: float) -> float:
        """Return ``value`` clamped into the inclusive ``[low, high]`` range."""
        return min(self.high, max(self.low, value))


@dataclass
class KnobSpec:
    """An ordered set of knobs <-> a flat parameter vector for a GA harness.

    The order of :attr:`knobs` defines the genome layout and never changes for a
    given spec, so vectors produced by :meth:`to_vector` / :meth:`sample` /
    :meth:`default_vector` are all mutually compatible.
    """

    knobs: list[Knob] = field(default_factory=list)

    def __post_init__(self) -> None:
        if not self.knobs:
            raise ValueError("KnobSpec needs at least one knob")
        names = [k.name for k in self.knobs]
        if len(set(names)) != len(names):
            dupes = sorted({n for n in names if names.count(n) > 1})
            raise ValueError(f"duplicate knob names: {dupes}")
        for k in self.knobs:
            if k.low > k.high:
                raise ValueError(f"knob {k.name!r}: low {k.low} > high {k.high}")
            if not (k.low <= k.default <= k.high):
                raise ValueError(
                    f"knob {k.name!r}: default {k.default} outside [{k.low}, {k.high}]"
                )

    def names(self) -> list[str]:
        """Knob names in genome order."""
        return [k.name for k in self.knobs]

    def bounds(self) -> list[tuple[float, float]]:
        """``(low, high)`` per knob, in genome order."""
        return [(k.low, k.high) for k in self.knobs]

    def default_vector(self) -> list[float]:
        """Each knob's default, in genome order."""
        return [k.default for k in self.knobs]

    def to_vector(self, values: Mapping[str, float]) -> list[float]:
        """Project a ``{name: value}`` mapping onto the genome vector.

        Missing names fall back to the knob's ``default``; keys that match no
        knob are ignored. Values are taken as-is (not clamped) so callers can
        detect out-of-range candidates via :meth:`clamp`.
        """
        return [float(values.get(k.name, k.default)) for k in self.knobs]

    def from_vector(self, vec: Sequence[float]) -> dict[str, float]:
        """Inverse of :meth:`to_vector`: a genome vector -> ``{name: value}``."""
        self._check_len(vec)
        return {k.name: float(v) for k, v in zip(self.knobs, vec)}

    def clamp(self, vec: Sequence[float]) -> list[float]:
        """Clamp each genome element into its knob's bounds."""
        self._check_len(vec)
        return [k.clamp(float(v)) for k, v in zip(self.knobs, vec)]

    def sample(self, rng: random.Random) -> list[float]:
        """Draw a genome uniformly at random within the bounds.

        Takes an explicit :class:`random.Random` so sampling is seedable and
        reproducible.
        """
        return [rng.uniform(k.low, k.high) for k in self.knobs]

    def _check_len(self, vec: Sequence[float]) -> None:
        if len(vec) != len(self.knobs):
            raise ValueError(f"vector length {len(vec)} != knob count {len(self.knobs)}")
