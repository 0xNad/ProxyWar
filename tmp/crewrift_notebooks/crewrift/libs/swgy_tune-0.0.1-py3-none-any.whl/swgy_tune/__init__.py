"""swgy-tune: reusable support for exposing tunable knobs in policies.

A policy declares its tunable parameters as *knobs* (named, typed, bounded).
``swgy-tune`` turns a set of knobs into a flat parameter vector and back, so a
genetic-algorithm harness (built later) can search the space without knowing
anything about the policy internals.

Standalone by design: it does NOT depend on ``swgy-base``. A policy wires the
two together -- it builds on ``swgy-base`` and declares its knobs with
``swgy-tune``. Keeping them separate means neither distribution drags in the
other's dependencies.

Public surface (see ``knob``):
    Knob        -- one tunable parameter (name, bounds, default)
    KnobSpec    -- an ordered collection of knobs <-> parameter vector
                   (to_vector / from_vector / bounds / clamp / sample)
"""

from .knob import Knob, KnobSpec

__all__ = ["Knob", "KnobSpec"]
__version__ = "0.0.1"
